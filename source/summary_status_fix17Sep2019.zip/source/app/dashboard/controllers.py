"""

    File 		    : 	controllers
    App / Module    : 	
    Description     : 	
    Project Name    :   EverestIMSPortal
    Created by Roopesh on 11/6/2017
    Copyright (c) 2017 Everest IMS. All rights reserved.

"""
# Python file imports
import collections
import json
# Django file imports
from django.utils import timezone
# Third party library file imports
from rest_framework_jwt.settings import api_settings
from rest_framework import status
from rest_framework.response import Response
# Module file imports
from everest.sitepackage.basecontroller import BaseController
from .datasourcehandler import *
from everest.sitepackage.utils.utility import *
from everest.sitepackage.basepagination import StandardResultsSetPagination
from app.everest_common import everest_utility
from everest.config import SUPER_ADMIN_USER_NAME
from everest.sitepackage.database_queries_mapper import database_query_instance
from .serializers import *
from .models import *
from .configuration import *
from django.contrib.auth.models import User
from app.dashboard.datasource.basedatasource import BaseDataSource
from app.sdinterfaces.sd_interface import BaseRestClient
from app.everest_common.everest_utility import *

__author__ = 'Roopesh'

logger = logging.getLogger(__name__)


class DashboardController(BaseController, object):

    datasource_class_instances_map, datasource_info = DatasourceHandler().get_data_sources()
    basedatasource = BaseDataSource()
    service_mngr_info = BaseRestClient()

    def convert(self, data):
        if isinstance(data, basestring):
            return str(data)
        elif isinstance(data, collections.Mapping):
            return dict(map(self.convert, data.iteritems()))
        elif isinstance(data, collections.Iterable):
            return type(data)(map(self.convert, data))
        else:
            return data

    def get_datasource_info(self, request):
        # print "get_datasource_info", self.datasource_info
        return self.datasource_info

    def get_data_info(self, request):
        try:
            # print "\nInside get_data_info"
            request_get_params = request.GET
            # print("request_get_params: %s" % request_get_params)
            data_source_param = request_get_params.get("datasource", None)
            data_options_param = request_get_params.get("dataOptions", None)
            data_source = json.loads(data_source_param)
            data_param = data_source.get("param", {})
            if data_param in ["", "{}", "None", "-1", None, -1]:
                data_param = {}

            type_info = data_source.get("type", "")
            source_info = data_source.get("source", "")
            param_info = data_source.get("param", "")
            # print("type_info: %s" % type_info)
            # print("source_info: %s" % source_info)
            # print("data_param: %s" % data_param)
            data_options = json.loads(data_options_param)
            # print("data_options: %s" % data_options)
            # filters = request_get_params.get("filters", None)
            # filters = self.convert(filters)
            # print("request_get_params: %s" % request_get_params)
            # print("type: %s" % type)
            # print("source: %s" % source)
            # print("filters: %s" % filters)
            resolution = data_options.get("resolution", None)
            timescale = int(data_options.get("timescale", "-1"))
            group_by = data_options.get("groupBy", None)
            topn = data_options.get("topN", None)
            filters = data_options.get("filters", {})
            stats = data_options.get("stats", [])
            # data_options = json.loads(data_options)
            for key, value in data_options.items():
                # print "key==>", key
                # print "value==>",value
                # if isinstance(key, unicode):
                #     print "inside unicode conv."
                #     key = key.encode('utf8')
                # if type(key) == str:
                #     key = json.loads(key)
                # key = key.encode('ascii', 'ignore')
                param_key = str(key)
                if isinstance(value, unicode):
                    param_value = value.encode('utf8')
                else:
                    param_value = value
                # print "param_value==>", type(param_value), param_value
                if str(key) not in ["resolution", "timescale", "groupBy", "topN", "filters", "stats"]:
                    data_param[param_key] = param_value
            # print("data_param: %s" % data_param)
            # print("datasource_class_instances_map: %s" % self.datasource_class_instances_map)
            # print("type_info: %s" % type_info)
            class_instance = self.datasource_class_instances_map.get(type_info, None)
            # print("class_instance: %s" % class_instance)
            function_to_call = getattr(class_instance, source_info)
            # function_to_call = datasource_function_map.get(type, {}).get(source, None)
            # print("function_to_call: %s" % function_to_call)
            # print("class_instance: %s" % class_instance)
            # print("function_to_call: %s" % function_to_call)
            # fetched_data = function_to_call(filters)
            fetched_data = function_to_call(request, resolution=resolution, timescale=timescale,
                                            group_by=group_by, topn=topn, filters=filters, stats=stats,
                                            extra_params=data_param)
            # print("fetched_data: %s" % fetched_data)
            return fetched_data
        except Exception, err:
            logger.error("Error in get_data_info function of Dashboard Controller:%s (%s)" % (err.message, type(err)))
            # print("Error in get_data_info function of Dashboard Controller:%s (%s)" % (err.message, type(err)))
            return {}

    def get_widgets_info(self, request):
        try:
            # print "\nInside get_data_info"
            sql_stmt = "Select * from tblwidget order by id;"
            # resource_availability_info_query = database_query_instance.get("Q001007")
            # print("resource_availability_info_query: %s" % resource_availability_info_query)
            query_data = execute_raw_query(sql_stmt)
            # print("query_data -- ", query_data)
            # print("Widget -- ", Widget.WIDGET_CHOICES_REVERSE_DICT)

            widget_info_link = []
            widget_info_site = []
            widget_info_views = []
            widget_info_metric = []
            widget_info_service_manager = []
            widget_info_alarms = []
            widget_info_stats = []
            for data in query_data:
                graph_options_str = data.get("graphoptions", "{}")
                # print "linkoptions: ", data.get("linkoptions", "{}")
                link_options_str = data.get("linkoptions", None)
                if link_options_str in ["", "None", "Null", None, {}]:
                    link_options = "{}"
                else:
                    link_options = link_options_str
                graph_options_rendered_str = graph_options_str
                widget_type = data.get("type", "")
                edited_dataoptions = json.loads(data.get("dataoptions", "{}"))
                edited_dataoptions.update({'crossLaunchUrl': ''})
                # print "\ndataOptions==>>>",json.loads(data.get("dataoptions", "{}"))
                widgets_data_info = dict(
                    widgetId=data.get("id", ""),
                    autoReload=5,
                    name=data.get("name", ""),
                    directive=data.get("directive", ""),
                    description=data.get("description", ""),
                    sizeX=data.get("width", ""),
                    sizeY=data.get("height", ""),
                    minSizeX=data.get("minwidth", ""),
                    minSizeY=data.get("minheight", ""),
                    users=data.get("users", ""),
                    groups=data.get("groups", ""),
                    type=Widget.WIDGET_CHOICES_REVERSE_DICT.get(widget_type, ""),
                    datasource=json.loads(data.get("datasource", "{}")),
                    displayOptions=json.loads(data.get("displayoptions", "{}")),
                    dataOptions=edited_dataoptions,
                    graphOptions=json.loads(graph_options_rendered_str),
                    linkOptions=json.loads(link_options),
                )

                if widgets_data_info.get("type", "") == "link":
                    widget_info_link.append(widgets_data_info)
                elif widgets_data_info.get("type", "") == "site":
                    widget_info_site.append(widgets_data_info)
                elif widgets_data_info.get("type", "") == "views":
                    widget_info_views.append(widgets_data_info)
                elif widgets_data_info.get("type", "") == "metric":
                    widget_info_metric.append(widgets_data_info)
                elif widgets_data_info.get("type", "") == "servicemanager":
                    widget_info_service_manager.append(widgets_data_info)
                elif widgets_data_info.get("type", "") == "alarms":
                    widget_info_alarms.append(widgets_data_info)
                elif widgets_data_info.get("type", "") == "stats":
                    widget_info_stats.append(widgets_data_info)
                else:
                    # print("Data not found for: %s" % widgets_data_info)
                    pass

            widget_info = [
                dict(type="all", name="All", icon="fa fa-certificate", action=""),
                dict(type="alarms", name="Alarms Based", icon="fa fa-bell", action="", widgets=widget_info_alarms),
                dict(type="stats", name="Stats Based", icon="fa fa-line-chart", action="", widgets=widget_info_stats),
                dict(type="link", name="Link", icon="fa fa-external-link", action="", widgets=widget_info_link),
                dict(type="site", name="Site", icon="fa fa-hdd-o", action="", widgets=widget_info_site),
                dict(type="views", name="Views", icon="fa fa-picture-o", action="", widgets=widget_info_views),
                dict(type="servicemanager", name="Service Manager", icon="fa fa-ticket", action="", widgets=widget_info_service_manager),
            ]

            # print("widget_info: %s" % widget_info)
            return widget_info
        except Exception, err:
            logger.error("Error in get_widgets_info function of Dashboard Controller:%s (%s)" % (err.message, type(err)))
            return []

    # *******************************************************************
    # Get Dashboard Information
    # *******************************************************************
    def get_filtered_dashboard(self, request, all_dashboard_obj):
        try:
            function_start_time = time.time()
            logger.info("Enter into get_filtered_dashboard function of DashboardController.")
            # print("Enter into get_filtered_dashboard function of DashboardController.")

            # Filtering dashboard configured for the user or group
            filtered_dashboard = []
            # User Filter
            # print "request: ", request.user.id, request.user.username, dir(request.user)
            try:
                everest_user_obj = Accounts.objects.get(name=request.user.username, isdeleted=False)
            except:
                logger.error("Error in getting everest user information")
                # print("Error in getting everest user information")
                everest_user_obj = None
            try:
                django_user_obj = User.objects.get(username=request.user.username)
            except:
                logger.error("Error in getting django user information")
                # print("Error in getting django user information")
                django_user_obj = None

            # print "everest_user_obj: ", everest_user_obj, everest_user_obj.accountid
            all_dashboard_ids = []
            if everest_user_obj not in [None, "", [], "None"]:
                # print "222222222"
                # everest_user_id = everest_user_obj.accountid
                everest_user_name = everest_user_obj.name
                # print "everest_user_name: ", everest_user_name
                # print "all_dashboard_obj: ", all_dashboard_obj
                for dashboard_obj in all_dashboard_obj:
                    # print "dashboard_obj: ", dashboard_obj, dashboard_obj.get("users", "uuu")
                    dashboard_id = dashboard_obj.get("id", "")
                    # print "dashboard_id 111: ", dashboard_id
                    dashboard_users = dashboard_obj.get("users", "").split(",")
                    dashboard_users_list = [str(u.strip()) for u in dashboard_users]
                    # print "dashboard_users_list: ", dashboard_users_list
                    if everest_user_name in dashboard_users_list:
                        filtered_dashboard.append(dashboard_obj)
                        all_dashboard_ids.append(dashboard_id)
                    # Check if dashboard is created by logged in user or not.
                    # print "django_user_obj.id : ", django_user_obj.id
                    # print "creator : ", dashboard_obj.get("creator", "")
                    elif django_user_obj.id == dashboard_obj.get("creator", ""):
                        filtered_dashboard.append(dashboard_obj)
                        all_dashboard_ids.append(dashboard_id)
            # print "filtered_dashboard: ", filtered_dashboard

            # Group Filter
            if everest_user_obj not in [None, "", [], "None"]:
                group_id = everest_user_obj.groupid
                # print "group_id: ", group_id
                try:
                    everest_group_obj = Groups.objects.get(groupid=group_id, isdeleted=False)
                except:
                    logger.error("Error in getting everest group information")
                    # print("Error in getting everest group information")
                    everest_group_obj = None
                # print "everest_group_obj: ", everest_group_obj
                if everest_group_obj:
                    everest_group_name = everest_group_obj.name
                    # print "everest_group_name: ", everest_group_name
                    for dashboard_obj in all_dashboard_obj:
                        dashboard_id = dashboard_obj.get("id", "")
                        # print "dashboard_id 222: ", dashboard_id
                        # print "dashboard_obj: ", dashboard_obj, dashboard_obj.get("groups", "uuu")
                        dashboard_group = dashboard_obj.get("groups", "").split(",")
                        dashboard_group_list = [str(u.strip()) for u in dashboard_group]
                        # print "dashboard_group_list: ", dashboard_group_list
                        if everest_group_name in dashboard_group_list:
                            # Check if dashboard is already in the list. If dashboard is not in list then only add it.
                            if dashboard_obj not in filtered_dashboard:
                                if dashboard_id not in all_dashboard_ids:
                                    filtered_dashboard.append(dashboard_obj)
            # print "filtered_dashboard: ", filtered_dashboard
            # print "all_dashboard_ids: ", all_dashboard_ids

            # print("Overall time taken by get_filtered_dashboard function to complete: %f" %
            #       (time.time() - function_start_time))
            logger.debug("Overall time taken by get_filtered_dashboard function to complete: %f" %
                         (time.time() - function_start_time))
            logger.info("Exiting get_filtered_dashboard function of DashboardController.")
            return filtered_dashboard, everest_user_name, everest_group_name
        except Exception, err:
            logger.error("Error in get_filtered_dashboard function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_filtered_dashboard function of DashboardController:%s (%s)" % (err.message, type(err)))
            return [], "", ""

    def get_dashboard_list(self, request):
        try:
            function_start_time = time.time()
            logger.info("Enter into get_dashboard_list function of DashboardController.")
            # print("Enter into get_dashboard_list function of DashboardController.")

            user_name = str(request.user.username)
            # print "user_name: ", user_name, request.user, type(request.user), request.user.id
            # print "request: ", request.GET.get("page", None), request.GET.get("items_per_page", None), request.GET

            # user_obj = User.get()

            paginator = StandardResultsSetPagination()
            init_filter_condition = Q(is_deleted=False)
            result_page = paginator.paginate_queryset(
                self.get_model_filter(request, Dashboard, init_filter_condition), request)
            serializer = DashboardListSerializer(result_page, many=True)
            # print "result_page: ", len(result_page), result_page
            all_dashboard = self.get_model_filter(request, Dashboard, init_filter_condition)
            # print "all_dashboard: ", len(all_dashboard), all_dashboard
            serializer_all = DashboardListSerializer(all_dashboard, many=True)
            # print "serializer_all: ", len(serializer_all.data), serializer_all.data
            # print "serializer: ", serializer

            filtered_dashboard, user_name, group_name = self.get_filtered_dashboard(request, serializer_all.data)
            # print "filtered_dashboard: ", len(filtered_dashboard), filtered_dashboard

            if group_name != "Default":
                page = safe_int(request.GET.get("page", 0))
                items_per_page = safe_int(request.GET.get("items_per_page", 0))
                response_data = paginator.get_paginated_response(filtered_dashboard)
                start_page = (page - 1) * items_per_page
                end_page = page * items_per_page
                response_data.data['results'] = filtered_dashboard[start_page: end_page]
                response_data.data['count'] = len(filtered_dashboard)
            else:
                response_data = paginator.get_paginated_response(serializer.data)
            # print "response_data 111 : ", response_data
            # print("Overall time taken by get_dashboard_list function to complete: %f" %
            #       (time.time() - function_start_time))
            logger.debug("Overall time taken by get_dashboard_list function to complete: %f" %
                         (time.time() - function_start_time))
            logger.info("Exiting get_dashboard_list function of DashboardController.")
            return response_data
        except Exception, err:
            logger.error("Error in get_dashboard_list function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_dashboard_list function of DashboardController:%s (%s)" % (err.message, type(err)))
            return Response({'results': [], 'count': 0, 'next': None,  'previous': None}, status=status.HTTP_200_OK)

    def get_dashboard(self, request, dashboard_id, for_copy=False):
        try:
            function_start_time = time.time()
            logger.info("Enter into get_dashboard function of DashboardController.")
            # print("Enter into get_dashboard function of DashboardController.")

            # print("id: %s request: %s, %s" % (dashboard_id, request, request.user.username))
            dashboard_info = dict()
            dashboard_widget_list = []
            user_name = str(request.user.username)
            user_obj = Accounts.objects.filter(name=user_name, isdeleted=0).values('groupid')
            # print "user_obj: ", user_obj
            if user_obj:
                group_id = user_obj[0].get("groupid", "")
            # print "group_id: ", group_id
            dashboard = Dashboard.objects.filter(id=dashboard_id, is_deleted=False).values()
            # print("dashboard: %s" % dashboard)
            if dashboard:
                dashboard_data = dashboard[0]
                # print("dashboard_data: %s" % dashboard_data)
                dashboard_id = dashboard_data.get("id", "")
                dashboard_name = dashboard_data.get("name", "")
                dashboard_description = dashboard_data.get("description", "")
                dashboard_groups = json.loads(dashboard_data.get("groups", "[]"))
                dashboard_groups = [str(group) for group in dashboard_groups]
                dashboard_users = json.loads(dashboard_data.get("users", "[]"))
                dashboard_users = [str(user) for user in dashboard_users]

                if not((user_name in dashboard_users) or (str(group_id) in dashboard_groups) or (user_name == SUPER_ADMIN_USER_NAME)):
                    return "Unauthorized"

                # dashboard_widget = DashboardOptions.objects.filter(id=dashboard_id, is_deleted=False).values()
                # print("dashboard_widget: %s" % dashboard_widget)
                # Todo: Have to check performance and no of queries fired
                dashboard_options = DashboardOptions.objects.select_related('dashboard_widget',
                                                                            'widget').filter(dashboard=dashboard_id)
                # print("dashboard_options: %s" % dashboard_options)
                for dashboard_options_info in dashboard_options:
                    # print("dashboard_options_info: %s" % dashboard_options_info)
                    # print("dashboard_options_info all: %s" % dashboard_options_info.widget.graph_options)
                    dashboard_widget_info = dict(
                        dashboardWidgetId=dashboard_options_info.dashboard_widget.id,
                        # chartIdentity=dashboard_options_info.dashboard_widget.id,
                        sizeX=dashboard_options_info.dashboard_widget.width,
                        sizeY=dashboard_options_info.dashboard_widget.height,
                        row=dashboard_options_info.dashboard_widget.row,
                        col=dashboard_options_info.dashboard_widget.column,
                        autoReload=dashboard_options_info.dashboard_widget.auto_reload,
                        widgetId=dashboard_options_info.widget.id,
                        name=dashboard_options_info.widget.name,
                        description=dashboard_options_info.widget.description,
                        directive=dashboard_options_info.widget.directive,
                        type=dashboard_options_info.widget.type,
                        datasource=json.loads(dashboard_options_info.widget.datasource),
                        graphOptions=json.loads(dashboard_options_info.widget.graph_options),
                        minSizeX=dashboard_options_info.widget.min_width,
                        minSizeY=dashboard_options_info.widget.min_height,
                        groups=dashboard_options_info.widget.groups,
                        users=dashboard_options_info.widget.users,
                        dashboardOptionsId=dashboard_options_info.id,
                        displayOptions=json.loads(dashboard_options_info.display_options),
                        dataOptions=json.loads(dashboard_options_info.data_options),
                        linkOptions=json.loads(dashboard_options_info.link_options)
                    )
                    if for_copy:
                        del dashboard_widget_info["dashboardWidgetId"]
                        del dashboard_widget_info["dashboardOptionsId"]
                    # print("dashboard_widget_info: %s" % dashboard_widget_info)
                    dashboard_widget_list.append(dashboard_widget_info)

                dashboard_info = dict(
                    id=dashboard_id,
                    name=dashboard_name,
                    description=dashboard_description,
                    # groups=json.loads(dashboard_groups),
                    # users=json.loads(dashboard_users),
                    groups=dashboard_groups,
                    users=dashboard_users,
                    widgets=dashboard_widget_list
                )

            # print("dashboard_info: %s" % dashboard_info)

            # print("Overall time taken by get_dashboard function to complete: %f" %
            #       (time.time() - function_start_time))
            logger.debug("Overall time taken by get_dashboard function to complete: %f" %
                         (time.time() - function_start_time))
            logger.info("Exiting get_dashboard function of DashboardController.")
            # print "dashboard_info==",dashboard_info
            return dashboard_info
        except Exception, err:
            logger.error("Error in get_dashboard function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_dashboard function of DashboardController:%s (%s)" % (err.message, type(err)))
            return {}

    # *******************************************************************
    # Save Dashboard Information
    # *******************************************************************
    def save_dashboard_options(self, dashboard, dashboard_widget, widgets_info):
        try:
            function_start_time = time.time()
            logger.info("Enter into save_dashboard_options function of DashboardController.")
            # print("Enter into save_dashboard_options function of DashboardController.")

            # print("dashboard: %s" % dashboard)
            # print("dashboard_widget: %s" % dashboard_widget)
            # print("widgets_info: %s" % widgets_info)
            display_options_obj = json.dumps(widgets_info.get("displayOptions", None))
            data_options_obj = json.dumps(widgets_info.get("dataOptions", None))
            link_options_obj = json.dumps(widgets_info.get("linkOptions", {}))
            # print "dashboardOptionsId: ", widgets_info.get("dashboardOptionsId", "")

            try:
                if "dashboardOptionsId" in widgets_info:
                    dashboard_options = DashboardOptions.objects.get(id=widgets_info.get("dashboardOptionsId"))
                else:
                    dashboard_options = DashboardOptions()
                    dashboard_options.creation_time = timezone.now()
            except Exception, err:
                logger.error("Error in DashboardOptions Model object creation:%s (%s)" % (err.message, type(err)))
                dashboard_options = DashboardOptions()
                dashboard_options.creation_time = timezone.now()

            dashboard_options.dashboard_id = dashboard.id
            dashboard_options.dashboard_widget_id = dashboard_widget.id
            dashboard_options.widget_id = widgets_info.get("widgetId", "")
            dashboard_options.display_options = display_options_obj
            dashboard_options.data_options = data_options_obj
            dashboard_options.link_options = link_options_obj
            dashboard_options.save()

            # print("dashboard_options id: %s" % dashboard_options.id)

            # print("Overall time taken by save_dashboard_options function to complete: %f" %
            #       (time.time() - function_start_time))
            logger.debug("Overall time taken by save_dashboard_options function to complete: %f" %
                         (time.time() - function_start_time))
            logger.info("Exiting save_dashboard_options function of DashboardController.")
        except Exception, err:
            logger.error("Error in save_dashboard_options function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in save_dashboard_options function of DashboardController:%s (%s)" % (err.message, type(err)))
            raise Exception

    def save_dashboard_widget(self, dashboard, dashboard_widgets_info, dashboard_info):
        try:
            # print "inside save widget########################3333333333"
            function_start_time = time.time()
            logger.info("Enter into save_dashboard_widget function of DashboardController.")
            # print("Enter into save_dashboard_widget function of DashboardController.")

            # print("dashboard: %s" % dashboard)
            # print("dashboard_widgets_info: %s" % dashboard_widgets_info)

            # Delete the DashboardOptions for the widgets which are removed
            # print "\n\n ***** dashboard_info -- ", dashboard_info
            delete_dashboard_options = dashboard_info.get("deletedDashboardOptions", [])
            # print("delete_dashboard_options -- ", delete_dashboard_options)
            if delete_dashboard_options:
                delete_dashboard_options_obj = DashboardOptions.objects.filter(id__in=delete_dashboard_options)
                # print("delete_dashboard_options_obj: ", delete_dashboard_options_obj)
                delete_dashboard_options_obj.delete()

            # Delete the DashboardWidget for the widgets which are removed
            delete_dashboard_widget = dashboard_info.get("deletedDashboardWidgets", [])
            # print("delete_dashboard_widget -- ", delete_dashboard_widget)
            if delete_dashboard_widget:
                delete_dashboard_widget_obj = DashboardWidget.objects.filter(id__in=delete_dashboard_widget)
                # print("delete_dashboard_widget_obj: ", delete_dashboard_widget_obj)
                delete_dashboard_widget_obj.delete()

            for widgets_info in dashboard_widgets_info:
                # print "dashboardWidgetId: ", widgets_info.get("dashboardWidgetId", "")
                try:
                    if "dashboardWidgetId" in widgets_info:
                        dashboard_widget = DashboardWidget.objects.get(id=widgets_info.get("dashboardWidgetId"))
                    else:
                        dashboard_widget = DashboardWidget()
                        dashboard_widget.creation_time = timezone.now()
                except Exception, err:
                    logger.error("Error in DashboardWidget Model object creation:%s (%s)" % (err.message, type(err)))
                    dashboard_widget = DashboardWidget()
                    dashboard_widget.creation_time = timezone.now()

                dashboard_widget.dashboard_id = dashboard.id
                dashboard_widget.widget_id = widgets_info.get("widgetId", "")
                dashboard_widget.width = int(widgets_info.get("sizeX", ""))
                dashboard_widget.height = int(widgets_info.get("sizeY", ""))
                dashboard_widget.row = int(widgets_info.get("row", ""))
                dashboard_widget.column = int(widgets_info.get("col", ""))
                dashboard_widget.auto_reload = widgets_info.get("autoReload", None)
                if dashboard_widget.auto_reload == None:
                    dashboard_widget.auto_reload = 5
                # print "dashboard_widget.auto_reload==>",dashboard_widget.auto_reload
                dashboard_widget.save()
                # print("dashboard_widget id: %s" % dashboard_widget.id)

                self.save_dashboard_options(dashboard, dashboard_widget, widgets_info)

            # print("Overall time taken by save_dashboard_widget function to complete: %f" %
            #       (time.time() - function_start_time))
            logger.debug("Overall time taken by save_dashboard_widget function to complete: %f" %
                         (time.time() - function_start_time))
            logger.info("Exiting save_dashboard_widget function of DashboardController.")
        except Exception, err:
            logger.error("Error in save_dashboard_widget function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in save_dashboard_widget function of DashboardController:%s (%s)" % (err.message, type(err)))
            raise Exception

    def save_dashboard(self, request):
        try:
            function_start_time = time.time()
            logger.info("Enter into save_dashboard function of DashboardController.")
            # print("Enter into save_dashboard function of DashboardController.")

            data = self.get_post_data(request)
            event = 'Added'
            logger.debug("Request data:%s" % data)
            # print("Request data:%s" % data)

            dashboard_info = data.get("dashboardInfo", {})
            dashboard_widgets_info = data.get("dashboardWidgetsInfo", {})
            # print("dashboard_info: %s" % dashboard_info)
            # print("dashboard_widgets_info: %s" % dashboard_widgets_info)
            try:
                if "id" in dashboard_info:
                    dashboard = Dashboard.objects.get(id=dashboard_info.get("id"))
                    event = 'Edited'
                else:
                    dashboard = Dashboard()
                    dashboard.creator = request.user
                    dashboard.creation_time = timezone.now()
            except Exception, err:
                logger.error("Error in Dashboard Model object creation:%s (%s)" % (err.message, type(err)))
                dashboard = Dashboard()
                dashboard.creation_time = timezone.now()
            users = json.dumps(dashboard_info.get('users', []))
            groups = json.dumps(dashboard_info.get('groups', []))
            dashboard.name = dashboard_info.get('name', '')
            dashboard.description = dashboard_info.get('description', '')
            dashboard.users = users
            dashboard.groups = groups
            dashboard.updator = request.user
            dashboard.save()

            self.save_dashboard_widget(dashboard, dashboard_widgets_info, dashboard_info)

            # print("dashboard id: %s" % dashboard.id)
            # logging audit message
            message = "%s dashboard: %s" % (event, dashboard_info.get('name', ''))
            everest_utility.log_audit_information(request, message=message, event_type=12)

            # print("Overall time taken by save_dashboard function to complete: %f" %
            #       (time.time() - function_start_time))
            logger.debug("Overall time taken by save_dashboard function to complete: %f" %
                         (time.time() - function_start_time))
            logger.info("Exiting save_dashboard function of DashboardController.")
            return {'Status': "success", 'message': "Saved Dashboard data successfully."}
        except Exception, err:
            logger.error("Error in save_dashboard function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in save_dashboard function of DashboardController:%s (%s)" % (err.message, type(err)))
            return {'Status': "error", 'message': "Error in saving Dashboard data."}

    # *******************************************************************
    # Delete Dashboard Information
    # *******************************************************************
    def delete_dashboard(self, request, id):
        try:
            function_start_time = time.time()
            logger.info("Enter into delete_dashboard function of DashboardController.")
            # print("Enter into delete_dashboard function of DashboardController.")

            # print("dashboard id: %s" % id)
            if id not in [None, "None", "-1", "Null", ""]:
                # Delete DashboardOptions entries
                delete_dashboard_options_obj = DashboardOptions.objects.filter(dashboard=id)
                # print("delete_dashboard_options_obj: ", delete_dashboard_options_obj)
                delete_dashboard_options_obj.delete()

                # Delete DashboardWidget entries
                delete_dashboard_widget_obj = DashboardWidget.objects.filter(dashboard=id)
                # print("delete_dashboard_widget_obj: ", delete_dashboard_widget_obj)
                delete_dashboard_widget_obj.delete()

                # Delete Dashboard entries
                delete_dashboard_obj = Dashboard.objects.filter(id=id)
                # print("delete_dashboard_obj: ", delete_dashboard_obj)
                # logging audit message
                try:
                    dashboard_name = ""
                    if delete_dashboard_obj:
                        dashboard_name = delete_dashboard_obj[0].name
                except Exception, err:
                    logger.error("Error in getting dashboard name.")
                except:
                    logger.error("Error in getting dashboard name.")
                delete_dashboard_obj.delete()
                msg = {'Status': "success", 'message': "Deleted Dashboard successfully."}
                # logging audit message
                message = "Deleted dashboard: %s" % dashboard_name
                everest_utility.log_audit_information(request, message=message, event_type=12)
            else:
                msg = {'Status': "error", 'message': "Error in deleting Dashboard."}

            # print("Overall time taken by delete_dashboard function to complete: %f" %
            #       (time.time() - function_start_time))
            logger.debug("Overall time taken by delete_dashboard function to complete: %f" %
                         (time.time() - function_start_time))
            logger.info("Exiting delete_dashboard function of DashboardController.")
            return msg
        except Exception, err:
            logger.error("Error in delete_dashboard function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in delete_dashboard function of DashboardController:%s (%s)" % (err.message, type(err)))
            return {'Status': "error", 'message': "Error in deleting Dashboard."}

    # *******************************************************************
    # Copy Dashboard Information
    # *******************************************************************
    def copy_dashboard_info(self, request):
        try:
            function_start_time = time.time()
            logger.info("Enter into copy_dashboard_info function of DashboardController.")
            # print("Enter into copy_dashboard_info function of DashboardController.")

            data = self.get_post_data(request)
            # print("POST data: %s" % data)
            dashboard_to_copy_id = data.get("referenceDashboardId", None)
            if dashboard_to_copy_id:
                dashboard_info_obj = self.get_dashboard(request, dashboard_to_copy_id, for_copy=True)
                # print("dashboard_info_obj: %s" % dashboard_info_obj)
                dashboard_widgets_info = dashboard_info_obj.get("widgets", [])
                event = 'Copied'
                logger.debug("Request data:%s" % data)
                # print("Request data:%s" % data)

                dashboard_info = dict(
                    name=data.get("name", ""),
                    description=data.get("description", ""),
                    groups=data.get("groups", ""),
                    users=data.get("users", ""),
                )
                # dashboard_widgets_info = data.get("dashboardWidgetsInfo", {})
                # print("dashboard_info: %s" % dashboard_info)
                # print("dashboard_widgets_info: %s" % dashboard_widgets_info)
                dashboard = Dashboard()
                dashboard.creation_time = timezone.now()
                users = json.dumps(dashboard_info.get('users', []))
                groups = json.dumps(dashboard_info.get('groups', []))
                dashboard.name = dashboard_info.get('name', '')
                dashboard.description = dashboard_info.get('description', '')
                dashboard.users = users
                dashboard.groups = groups
                dashboard.save()

                self.save_dashboard_widget(dashboard, dashboard_widgets_info, dashboard_info)

                # print("dashboard id: %s" % dashboard.id)
                # logging audit message
                message = "%s dashboard %s from %s" % (event, dashboard_info.get('name', ''),
                                                       dashboard_info_obj.get('name', ''))
                everest_utility.log_audit_information(request, message=message, event_type=12)

            # print("Overall time taken by copy_dashboard_info function to complete: %f" %
            #       (time.time() - function_start_time))
            logger.debug("Overall time taken by copy_dashboard_info function to complete: %f" %
                         (time.time() - function_start_time))
            logger.info("Exiting copy_dashboard_info function of DashboardController.")
            return {'Status': "success", 'message': "Copied dashboard successfully."}
        except Exception, err:
            logger.error("Error in copy_dashboard_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in copy_dashboard_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return {'Status': "error", 'message': "Error in copying dashboard."}

    def get_node_inventory_info(self, request):
        """
        Description: Function is used to fetch the column names from tblnodeschema for the multiselect dropdown for Node Status Summary Widget.
        :param None.
        :return: Returning fetched data on to the UI using list.
        """
        try:
            # print "Inside get_node_inventory_info"
            sql_query = database_query_instance.get("Q_DASHBOARD_0000037")
            objs = execute_raw_query(sql_query)
            # print "objs==>",objs
            return objs

        except Exception, err:
            logger.error("Error in get_node_inventory_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_node_inventory_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_alarm_inventory_info(self, request):
        """
        Description: Function is used to fetch the column names from tblnodeschema for the multiselect dropdown for Node Status Summary Widget.
        :param None.
        :return: Returning fetched data on to the UI using list.
        """
        try:
            # print "Inside get_alarm_inventory_info"
            sql_query = "select attr as value, name_to_display as display_name from (SELECT *, " \
                        "CASE WHEN coalesce(TRIM(display_name),'') = '' THEN actual_name ELSE " \
                        "display_name END as name_to_display FROM tblNodeSchema) as tb1 where attr " \
                        "in ('region','state','city','location','res_type','make','model'" \
                        ") order by attr;"
            objs = execute_raw_query(sql_query)
            extra_objs = [
                {'display_name': 'Type', 'value': 'type'},
                {'display_name': 'Reset Value', 'value': 'resetpoint'},
                {'display_name': 'Alarm Number', 'value': 'alarmno'},
            ]
            objs = extra_objs + objs
            # print "objs==>",objs
            return objs

        except Exception, err:
            logger.error("Error in get_node_inventory_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_node_inventory_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_node_res_inventory_info(self, request):
        """
        Description: Function is used to fetch the column names from tblnodeschema for the multiselect dropdown for Node Status Summary Widget.
        :param None.
        :return: Returning fetched data on to the UI using list.
        """
        try:
            sql_query = database_query_instance.get("Q_DASHBOARD_0000057")
            objs = execute_raw_query(sql_query)
            return objs

        except Exception, err:
            logger.error("Error in get_node_res_inventory_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_group_by_fields(self, request):
        """
        Description: Function is used to fetch the column names from tblnodeschema for the multiselect dropdown for Node Status Summary Widget.
        :param None.
        :return: Returning fetched data on to the UI using list.
        """
        try:
            sql_query = database_query_instance.get("Q_DASHBOARD_0000118")
            objs = execute_raw_query(sql_query)
            return objs

        except Exception, err:
            logger.error("Error in get_group_by_fields function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_setmsg_list(self, request):
        try:
            final_objs = []
            default_objs = [{'name' : 'Select Alarm Message', 'value': ''}]
            sql_query = database_query_instance.get("Q_DASHBOARD_0000123")
            objs = execute_raw_query(sql_query)
            final_objs = default_objs + objs
            # msg_list = []
            # new_msg_list = []
            # statid_list = []
            # rawdn_list = []
            # final_objs = []
            # for val in objs:
            #     msg_list.append(val.get('name', ''))
            # msg_list = [x.encode('UTF8') for x in msg_list]
            # statid_qry = 'select distinct statid from tblthresholds where setmsg in (%s);' % str(msg_list)[1:-1]
            # statid_objs = execute_raw_query(statid_qry)
            # for val in statid_objs:
            #     statid_list.append(val.get('statid', None))
            #
            # rawdn_qry = 'select rawdn from tblstatmap where statid in (%s);' % str(statid_list)[1:-1]
            # rawdn_objs = execute_raw_query(rawdn_qry)
            # for val in rawdn_objs:
            #     rawdn_list.append(val.get('rawdn',''))
            # rawdn_list = [x.encode('UTF8') for x in rawdn_list]
            # threshold_dict = {}
            # for rawdn in rawdn_list:
            #     rawdn_info = {}
            #     rawdn_info = AGGREGATE_STATS_INFO.get(rawdn, {})
            #     threshold_dict.update({rawdn: rawdn_info.get('threshold', {})})
            # print 'threshold_dict==>>',threshold_dict
            # print 'objs==>>',objs
            # # for i in range(0, len(threshold_list)):
            # #     objs[i].update({'threshold': threshold_list[i]})
            # #     final_objs.append(objs[i])
            # msg_threhold_map = {}
            # # for val in final_objs:
            # #     msg_threhold_map.update({val.get('name', ''): val.get('threshold', {})})
            # # final_dict = dict(msgList=final_objs, msgThresholdMap=msg_threhold_map)
            return final_objs

        except Exception, err:
            logger.error("Error in get_group_by_fields function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_incident_list(self, request):
        try:
            final_obj = [{"name":"Select Incident ID", "value":""}]
            sql_query = database_query_instance.get("Q_DASHBOARD_0000124")
            objs = execute_raw_query(sql_query)
            final_obj = final_obj + objs
            return objs

        except Exception, err:
            logger.error("Error in get_group_by_fields function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_node_status_list(self, request):
        try:
            # print "get_node_status_list,request==>>",request.GET
            ret = {}
            table_data = {}
            node_status = request.GET.get('node_status','')
            filters = request.GET.get('filters','')

            if filters:
                if isinstance(filters, unicode) or isinstance(filters, str):
                    filters = json.loads(filters)
                    filters = filters.get('custom_filters', {})

            params = request.GET.get('params', {})
            if params:
                if isinstance(params, unicode) or isinstance(params, str):
                    params = json.loads(params)
                params = params.get('downloadParams', {})
                if params:
                    node_status = params.get('node_status', '')
                    filters = params.get('filters', '')
                    filters = filters.get('custom_filters', {})
                    # print type(filters), '2232456678776543'

            # print "params==>>",params
            if request:
                if not request.GET._mutable:
                    request.GET._mutable = True
                request.GET.update(params)

            count = None
            if isinstance(request.GET.get('count',None), unicode):
                count = json.loads(request.GET.get('count',None))

            limit = ''
            popup_header = False
            if count >= 100:
                popup_header = True
                limit = 'limit 100'

            # print "filters==>>",filters
            if node_status == 'Total':
                qry_str = ''
            elif node_status == 'Up':
                qry_str = 'where nd_status != 0 and if_disabled != -1'
            elif node_status == 'Down':
                qry_str = 'where nd_status = 0'
            else:
                qry_str = 'where if_disabled = -1'

            node_list, resource_list, node_stat_list, node_query, resource_info_query = self.basedatasource.get_filter_info(request, filters=filters, show_only_interfaces=False)

            sql_query = database_query_instance.get("Q_DASHBOARD_0000128") % (node_query, qry_str, limit)
            logger.info(
                "sql_query, get_node_status_list, Dashboard Controller:: %s" % sql_query)
            # print 'sql_query==>',sql_query
            objs = execute_raw_query(sql_query)
            for obj in objs:
                if obj.get('nd_status') != 0 and obj.get('if_disabled') != -1:
                    obj.update({'status':'Up'})
                elif obj.get('nd_status') == 0:
                    obj.update({'status':'Down'})
                elif obj.get('if_disabled') == -1:
                    obj.update({'status':'Disabled'})

            table_data['data'] = objs
            table_data['popupHeader'] = popup_header
            ret['tableData'] = table_data
            # print ret, "###################"
            return ret

        except Exception, err:
            # print_traceback()
            logger.error("Error in get_node_status_list function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_link_status_list(self, request):
        try:
            # print "get_node_status_list,request==>>",request.GET
            ret = {}
            table_data = {}
            link_status = request.GET.get('link_status','')
            filters = request.GET.get('filters','')
            statlist = get_statid_dic(['Network Availability'])
            inv_statlist = {v: k for k, v in statlist.iteritems()}
            NETWORK_AVAIL = inv_statlist.get('Network Availability')

            if filters:
                if isinstance(filters, unicode) or isinstance(filters, str):
                    filters = json.loads(filters)
                    filters = filters.get('custom_filters', {})

            params = request.GET.get('params', {})
            if params:
                if isinstance(params, unicode) or isinstance(params, str):
                    params = json.loads(params)
                params = params.get('downloadParams', {})
                if params:
                    node_status = params.get('node_status', '')
                    filters = params.get('filters', '')
                    filters = filters.get('custom_filters', {})
                    # print type(filters), '2232456678776543'

            # print "params==>>",params
            if request:
                if not request.GET._mutable:
                    request.GET._mutable = True
                request.GET.update(params)

            count = None
            if isinstance(request.GET.get('count',None), unicode):
                count = json.loads(request.GET.get('count',None))

            limit = ''
            popup_header = False
            if count >= 100:
                popup_header = True
                limit = 'limit 100'

            # print "filters==>>",filters
            if link_status == 'Total':
                qry_str = ''
            elif link_status == 'Up':
                qry_str = 'where link_status = 1'
            else:
                qry_str = 'where link_status = 0'

            node_list, resource_list, node_stat_list, node_query, resource_info_query = self.basedatasource.get_filter_info(request, filters=filters, show_only_interfaces=False)

            sql_query = database_query_instance.get("Q_DASHBOARD_0000115") % (resource_info_query, NETWORK_AVAIL, qry_str, limit)
            # print "sql_query==>>",sql_query
            logger.info(
                "sql_query, get_link_status_list, Dashboard Controller:: %s" % sql_query)
            objs = execute_raw_query(sql_query)
            for obj in objs:
                obj['bw_configured'] = formatValue(obj.get('bw_configured', 0), 'bps')
                time_data = safe_int(time.time()) - obj.get('downtime', 0)
                edited_time = formatValue(time_data, 'timetick')
                obj.update({'downsince': edited_time})
                obj.update({'downtime': time.ctime(obj.get('downtime', None))})
                if obj.get('link_status') == 1:
                    obj.update({'status':'Up'})
                elif obj.get('link_status') == 0:
                    obj.update({'status':'Down'})
                else:
                    obj.update({'status':'Disabled'})

            table_data['data'] = objs
            table_data['popupHeader'] = popup_header
            ret['tableData'] = table_data
            # print "ret==>>", ret
            return ret

        except Exception, err:
            # print_traceback()
            logger.error("Error in get_link_status_list function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_vendor_inventory(self, request):
        """
        Description: Function is used to fetch the column names from tblnodeschema for the multiselect dropdown for Node Status Summary Widget.
        :param None.
        :return: Returning fetched data on to the UI using list.
        """
        try:
            # query_dash_widget = "select * from tbldashboardwidget;"
            # res_dash_widget = utility.execute_raw_query(query_dash_widget)

            ## Code for generating Insert query for dashboard

            # dashboard_dict = {}
            # query_dashboard = "select * from tbldashboard;"
            # res_dashboard = utility.execute_raw_query(query_dashboard)
            # query_all_db = "select d.name as db_name, w.name as widget, dw.width, dw.height, dw.row, dw.column, dw.autoreload from tbldashboardwidget dw, tblwidget w, tbldashboard d where dw.widget = w.id and d.id = dw.dashboard;"
            # res_all_db = utility.execute_raw_query(query_all_db)
            # widget_dict = classify_objs(res_all_db, lambda x: x.get('db_name'))
            #
            # for k, v in widget_dict.iteritems():
            #     for data in v:
            #         del data['db_name']
            #
            # for val in res_dashboard:
            #     del val['id']
            #     del val['groups']
            #     del val['users']
            #     del val['lastupdatetime']
            #     del val['creationtime']
            #     dashboard_dict.update({val.get('name',''):val})
            #
            # final_dashboard_qry = ''
            # final_dw_qry = ''
            # for k, v in dashboard_dict.iteritems():
            #     dash_col_list = v.keys()
            #     dash_col_str = str(dash_col_list)[1:-1]
            #     dash_col_str = dash_col_str.replace("'","")
            #     dash_val_list = v.values()
            #     dash_val_str = str(dash_val_list)[1:-1]
            #     dash_val_str = dash_val_str.replace("None","NULL")
            #     dash_val_str = dash_val_str.replace("u'","'")
            #     dashboard_qry = 'INSERT INTO tbldashboard (%s) VALUES (%s);' % (dash_col_str, dash_val_str)
            #     final_dashboard_qry = final_dashboard_qry + dashboard_qry + '\n'
            #
            #
            # for k, v in dashboard_dict.iteritems():
            #     v.update({'widgets':widget_dict.get(k,[])})
            #
            # for k, v in dashboard_dict.iteritems():
            #     dw_col_list = v['widgets']
            #     for w in dw_col_list:
            #         qry_widget_id = "select id from tblwidget where name = '%s';" % w.get('widget','')
            #         res_widget_id = utility.execute_raw_query(qry_widget_id)
            #         w.update({'widget':res_widget_id[0].get('id',None)})
            #         qry_dash_id = "select id from tbldashboard where name = '%s';" % k
            #         res_dash_id = utility.execute_raw_query(qry_dash_id)
            #         w.update({'dashboard':res_dash_id[0].get('id',None)})
            #         dw_col_list = w.keys()
            #         dw_col_str = str(dw_col_list)[1:-1]
            #         dw_col_str = dw_col_str.replace("'","")
            #         dw_val_list = w.values()
            #         dw_val_str = str(dw_val_list)[1:-1]
            #         dw_val_str = dw_val_str.replace("None","NULL")
            #         dw_val_str = dw_val_str.replace("u'","'")
            #         dw_qry = 'INSERT INTO tbldashboardwidget (%s) VALUES (%s);' % (dw_col_str, dw_val_str)
            #         final_dw_qry = final_dw_qry + dw_qry + '\n'
            #
            # print "final_dashboard_qry==>>\n",final_dashboard_qry
            # print "final_dw_qry==>>\n",final_dw_qry
            # print "dashboard_dict,A==>>>", dashboard_dict

            ## End of code for generating Insert query for dashboard

            params = request.GET.get('params', {})
            if params:
                if isinstance(params, unicode) or isinstance(params, str):
                    params = json.loads(params)
                params = params.get('downloadParams', {})

            if request:
                if not request.GET._mutable:
                    request.GET._mutable = True
                request.GET.update(params)

            # print "\n\nrequest11111111===>",request.GET
            data_src = request.GET.get('datasource','')
            data_opt = request.GET.get('dataOptions','')
            # download = request.GET.get('download',False)

            if data_src:
                if isinstance(data_src, unicode) or isinstance(data_src, str):
                    data_src = json.loads(data_src)

            if data_opt:
                if isinstance(data_opt, unicode) or isinstance(data_opt, str):
                    data_opt = json.loads(data_opt)

            # print "\n\ndata_opt===>",data_opt
            # print "\n\ndata_src===>",data_src
            extra_params = data_src.get('param',{})
            ret = {}
            table_data = {}
            # profiles = str(INTERFACE_CFGS)[1:-1]
            rawdn_list = []
            statid_list = []
            new_table_header = []
            rawdn_thres_mapping = {}
            stat_info = data_opt.get('statInfo',[])
            filters = data_opt.get('filters',[])


            if stat_info:
                for data in stat_info:
                    new_table_header.append(data.get('name',''))

            node_list, resource_list, node_stat_list, node_query, resource_info_query = self.basedatasource.get_filter_info(request, filters=filters, show_only_interfaces=False)
            # print "node_list, resource_list, node_stat_list, node_query, resource_info_query===>",node_list, resource_list, node_stat_list, node_query, resource_info_query
            for val in stat_info:
                rawdn_list.append(val.get('raw_dn',''))
                rawdn_thres_dict = {}
                rawdn_thres_dict.update({val.get('raw_dn',''):val.get('threshold', {})})
                if rawdn_thres_dict.get(val.get('raw_dn',''),{}) != {}:
                    threshold_data = rawdn_thres_dict.get(val.get('raw_dn',''),{})
                    threshold_range = self.basedatasource.get_threshold_range_info(threshold_data)
                    rawdn_thres_mapping.update({val.get('raw_dn',''):threshold_range})

            rawdn_list = [str(x) for x in rawdn_list]
            query_str_for_rawdn = str(rawdn_list)[1:-1]
            objs_for_rawdn = []
            if query_str_for_rawdn:
                sql_query_for_rawdn = database_query_instance.get("Q_DASHBOARD_0000046")%query_str_for_rawdn
                objs_for_rawdn = utility.execute_raw_query(sql_query_for_rawdn)

            for data in objs_for_rawdn:
                statid_list.append(data.get('statid',None))
            query_str_for_statid = str(statid_list)[1:-1]

            current_time = safe_int(time.time())
            startTime = current_time - 3600
            endTime = current_time
            raw_tables = getTables('tblraw', startTime, endTime)

            name_value_mapping = {'Vendor':'make_inventory'}
            parent_level_name = name_value_mapping.get(extra_params.get('parentLevelName',''),'')
            parent_level_value = extra_params.get('parentLevelValue','')


            sql_query_for_data = database_query_instance.get("Q_DASHBOARD_0000058") % (
            node_query, parent_level_name, parent_level_value)
            # print "sql_query_for_data==>",sql_query_for_data
            logger.info("sql_query_for_data, get_vendor_inventory, Dashboard Controller:: %s" % sql_query_for_data)
            objs_for_data = utility.execute_raw_query(sql_query_for_data)
            for obj in objs_for_data:
                if obj.get('status') == 0:
                    obj.update({'status_msg':'Down'})
                else:
                    obj.update({'status_msg': 'Up'})
            objs_keys_list = []

            if objs_for_data[0]:
                objs_keys_list = objs_for_data[0].keys()
            query_str_for_mapping = str(objs_keys_list)[1:-1]

            sql_query_for_mapping = database_query_instance.get("Q_DASHBOARD_0000033") % query_str_for_mapping
            logger.info("sql_query_for_mapping, get_vendor_inventory, Dashboard Controller:: %s" % sql_query_for_mapping)
            objs_for_mapping = utility.execute_raw_query(sql_query_for_mapping)

            display_name_attr_mapping = {}
            display_name_list = []
            raw_html_dict = {}
            vendor_header_list = DEVICE_HEADER_LIST
            for data in objs_for_mapping:
                if data.get('attr', '') in vendor_header_list:
                    display_name_attr_mapping.update({data.get('name_to_display', ''): data.get('attr', '')})
                    display_name_list.append(data.get('name_to_display', ''))
                    raw_html_dict.update({data.get('name_to_display', ''): ''})

            # print "display_name_attr_mapping==>>",display_name_attr_mapping
            # print "display_name_list==>>",display_name_list
            # print "raw_html_dict==>>",raw_html_dict

            table_data['data'] = objs_for_data
            table_data['displayNameValue'] = display_name_attr_mapping
            table_data['displayNameList'] = display_name_list
            table_data['rawHtmlDict'] = raw_html_dict
            table_data['title'] = extra_params.get('parentLevelValue', '')
            ret['tableData'] = table_data

            # if download:
            #     return objs_for_data
            # else:
            return ret

        except Exception, err:
            logger.error("Error in get_vendor_inventory function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_device_inventory(self, request):
        """
        Description: Function is used to fetch the column names from tblnodeschema for the multiselect dropdown for Node Status Summary Widget.
        :param None.
        :return: Returning fetched data on to the UI using list.
        """
        try:
            params = request.GET.get('params', {})
            if params:
                if isinstance(params, unicode) or isinstance(params, str):
                    params = json.loads(params)
                params = params.get('downloadParams', {})

            if request:
                if not request.GET._mutable:
                    request.GET._mutable = True
                request.GET.update(params)

            data_src = request.GET.get('datasource','')
            data_opt = request.GET.get('dataOptions','')

            if data_src:
                if isinstance(data_src, unicode) or isinstance(data_src, str):
                    data_src = json.loads(data_src)

            if data_opt:
                if isinstance(data_opt, unicode) or isinstance(data_opt, str):
                    data_opt = json.loads(data_opt)

            extra_params = data_src.get('param',{})
            ret = {}
            table_data = {}
            # profiles = str(INTERFACE_CFGS)[1:-1]
            rawdn_list = []
            statid_list = []
            new_table_header = []
            rawdn_thres_mapping = {}
            stat_info = data_opt.get('statInfo',[])
            filters = data_opt.get('filters',[])

            if stat_info:
                for data in stat_info:
                    new_table_header.append(data.get('name',''))

            node_list, resource_list, node_stat_list, node_query, resource_info_query = self.basedatasource.get_filter_info(request, filters=filters, show_only_interfaces=False)

            for val in stat_info:
                rawdn_list.append(val.get('raw_dn',''))
                rawdn_thres_dict = {}
                rawdn_thres_dict.update({val.get('raw_dn',''):val.get('threshold', {})})
                if rawdn_thres_dict.get(val.get('raw_dn',''),{}) != {}:
                    threshold_data = rawdn_thres_dict.get(val.get('raw_dn',''),{})
                    threshold_range = self.basedatasource.get_threshold_range_info(threshold_data)
                    rawdn_thres_mapping.update({val.get('raw_dn',''):threshold_range})

            rawdn_list = [str(x) for x in rawdn_list]
            query_str_for_rawdn = str(rawdn_list)[1:-1]
            objs_for_rawdn = []
            if query_str_for_rawdn:
                sql_query_for_rawdn = database_query_instance.get("Q_DASHBOARD_0000046")%query_str_for_rawdn
                objs_for_rawdn = utility.execute_raw_query(sql_query_for_rawdn)

            for data in objs_for_rawdn:
                statid_list.append(data.get('statid',None))
            query_str_for_statid = str(statid_list)[1:-1]

            current_time = safe_int(time.time())
            startTime = current_time - 3600
            endTime = current_time
            raw_tables = getTables('tblraw', startTime, endTime)

            name_value_mapping = {'Device Type':'device_type_inventory'}
            parent_level_name = name_value_mapping.get(extra_params.get('parentLevelName',''),'')
            parent_level_value = extra_params.get('parentLevelValue','')

            sql_query_for_data = database_query_instance.get("Q_DASHBOARD_0000051") %(node_query, parent_level_name,parent_level_value)
            # print "sql_query_for_data==>",sql_query_for_data
            logger.info("sql_query_for_data, get_device_inventory, Dashboard Controller:: %s" % sql_query_for_data)
            objs_for_data = utility.execute_raw_query(sql_query_for_data)
            for obj in objs_for_data:
                if obj.get('status') == 0:
                    obj.update({'status_msg':'Down'})
                else:
                    obj.update({'status_msg': 'Up'})
            objs_keys_list = []

            if objs_for_data[0]:
                objs_keys_list = objs_for_data[0].keys()

            query_str_for_mapping = str(objs_keys_list)[1:-1]

            sql_query_for_mapping = database_query_instance.get("Q_DASHBOARD_0000033") %query_str_for_mapping
            logger.info("sql_query_for_mapping, get_device_inventory, Dashboard Controller:: %s" % sql_query_for_mapping)
            objs_for_mapping = utility.execute_raw_query(sql_query_for_mapping)

            display_name_attr_mapping = {}
            display_name_list = []
            raw_html_dict = {}
            # print "objs_for_mapping==>",objs_for_mapping
            # device_header_list = ['hostname', 'poll_addr', 'device_type', 'model', 'location']
            device_header_list = DEVICE_HEADER_LIST
            # device_header_list = device_header_list.append('nodeid')
            # device_header_list = device_header_list.append('resid')
            for data in objs_for_mapping:
                if data.get('attr','') in device_header_list:
                    display_name_attr_mapping.update({data.get('name_to_display',''):data.get('attr','')})
                    display_name_list.append(data.get('name_to_display',''))
                    raw_html_dict.update({data.get('name_to_display',''):''})

            table_data['data'] = objs_for_data
            table_data['displayNameValue'] = display_name_attr_mapping
            table_data['displayNameList'] = display_name_list
            table_data['rawHtmlDict'] = raw_html_dict
            table_data['title'] = extra_params.get('parentLevelValue','')
            ret['tableData'] = table_data

            return ret

        except Exception, err:
            logger.error("Error in get_vendor_inventory function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_software_inventory(self, request):
        """
        Description: Function is used to fetch the column names from tblnodeschema for the multiselect dropdown for Node Status Summary Widget.
        :param None.
        :return: Returning fetched data on to the UI using list.
        """
        try:
            # print "Inside get_software_inventory==>>",request.GET
            params = request.GET.get('params', {})
            if params:
                if isinstance(params, unicode) or isinstance(params, str):
                    params = json.loads(params)
                params = params.get('downloadParams', {})

            if request:
                if not request.GET._mutable:
                    request.GET._mutable = True
                request.GET.update(params)

            data_src = request.GET.get('datasource','')
            data_opt = request.GET.get('dataOptions','')

            if data_src:
                if isinstance(data_src, unicode) or isinstance(data_src, str):
                    data_src = json.loads(data_src)

            # print "data_src==>>",data_src
            if data_opt:
                if isinstance(data_opt, unicode) or isinstance(data_opt, str):
                    data_opt = json.loads(data_opt)
            # print "data_opt==>>", data_opt

            filters = data_opt.get('filters', {})
            extra_params = data_src.get('param', {})
            ret = {}
            table_data = {}

            node_list, resource_list, node_stat_list, node_query, resource_info_query = self.basedatasource.get_filter_info(request, filters=filters, show_only_interfaces=False)

            name_value_mapping = {'Software': 'sw_name'}
            parent_level_name = name_value_mapping.get(extra_params.get('parentLevelName', ''), '')
            parent_level_value = extra_params.get('parentLevelValue', '')

            sql_query_for_data = database_query_instance.get("Q_DASHBOARD_0000113") % (node_query, parent_level_name,
                                                                                       parent_level_value)
            # print "sql_query_for_data==>>",sql_query_for_data
            objs_for_data = utility.execute_raw_query(sql_query_for_data)

            table_data['data'] = objs_for_data
            table_data['title'] = extra_params.get('parentLevelValue', '')
            ret['tableData'] = table_data

            return ret

        except Exception, err:
            logger.error("Error in get_vendor_inventory function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []


    def breach_stat_info(self, request):
        try:
            # print "#####Inside breach_stat_info function#####"
            ret = {}
            table_data = {}
            name_value_mapping = {}
            raw_html_data_mapping = {}
            new_table_header = []

            count = None
            if isinstance(request.GET.get('containerStyle',{}), unicode):
                data = json.loads(request.GET.get('containerStyle',None))
                count = data.get('count',None)

            popup_header = False
            if count >= 100:
                popup_header = True

            limit = 'limit 100'
            if request.GET.has_key('from_download'):
                limit = ''

            params = request.GET.get('params', {})
            if params:
                if isinstance(params, unicode) or isinstance(params, str):
                    params = json.loads(params)
                params = params.get('downloadParams', {})

            if request:
                if not request.GET._mutable:
                    request.GET._mutable = True
                request.GET.update(params)

            unit = ''
            boundary_value = request.GET.get('boundaryValue',[])
            filters = request.GET.get('filters',[])
            value_type = request.GET.get('valueType',[])
            # print "filters,ctrl==>",filters
            stats = "'" + request.GET.get('statRawdn',[]) + "'"
            node_id_list, res_id_list, node_stat_list, node_query, resource_query = self.basedatasource.get_filter_info(
                request, filters=filters)
            # print "resource_query1==>",resource_query1
            # print "resource_query,ctrl==>",resource_query

            if boundary_value not in ['None',None, '', -1, '-1']:
                boundary_value_condition = 'where avg ' + str(value_type) + ' ' + str(boundary_value) + ' '
            else:
                boundary_value_condition = ''

            if stats:
                sql_query_for_stats = database_query_instance.get("Q_DASHBOARD_0000046") % (stats)
                logger.info(
                    "sql_query_for_stats for breach_stat_info function :: %s" % sql_query_for_stats)
                dataset_for_stats = utility.execute_raw_query(sql_query_for_stats)

            for data in dataset_for_stats:
                stat_id = data.get('statid',None)
                name_value_mapping.update({data.get('name',''):'avg'})
                new_table_header.append(data.get('name',''))
                raw_html_data_mapping.update({data.get('name',''):''})
                unit = data.get('unit','')

            current_time = safe_int(time.time())
            start_time = current_time - 3600
            end_time = current_time
            query_tables = getTables('tblraw', start_time, end_time)

            start_timestamp = current_time - 1800
            end_timestamp = current_time
            sub_query_str_list = [database_query_instance.get("Q001024") % (query_str, start_timestamp, end_timestamp
                                                                            ) for query_str in query_tables]
            logger.info(
                "sub_query_str_list for breach_stat_info function :: %s" % sub_query_str_list)
            union_query_for_timescale = ''
            for query_str in sub_query_str_list:
                union_query_for_timescale = union_query_for_timescale + query_str + ' union all '

            union_query_for_timescale = '(' + str(union_query_for_timescale[:-11]) + ')'
            raw_tables = []
            raw_tables.insert(0, str(union_query_for_timescale))

            sql_query_for_stats_in_popup = database_query_instance.get("Q_DASHBOARD_0000088") % \
                                           (raw_tables[0],stat_id,resource_query,boundary_value_condition, limit)
            # print "sql_query_for_stats_in_popup==>",sql_query_for_stats_in_popup
            logger.info(
                "sql_query_for_stats_in_popup for breach_stat_info function :: %s" % sql_query_for_stats_in_popup)
            dataset_for_stats_popup = utility.execute_raw_query(sql_query_for_stats_in_popup)

            for data in dataset_for_stats_popup:
                data.update({'avg':round(data.get('avg',None), 2)})
                data.update({'avg':formatValue(data.get('avg',None), unit)})

            table_data['data'] = dataset_for_stats_popup
            table_data['nameValueMapping'] = name_value_mapping
            table_data['rawHtmlDataMapping'] = raw_html_data_mapping
            table_data['newTableHeader'] = new_table_header
            table_data['boundaryValue'] = formatValue(boundary_value, unit)
            table_data['valueType'] = str(value_type)
            table_data['popupHeader'] = popup_header
            ret['tableData'] = table_data
            # print "ret==>>",ret
            return ret


        except Exception, err:
            logger.error("Error in breach_stat_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def breach_alarm_based_stat_info(self, request):
        try:
            print '\n\nInside\n\n'
            ret = {}
            table_data = {}
            name_value_mapping = {}
            raw_html_data_mapping = {}
            new_table_header = []

            count = None
            if isinstance(request.GET.get('containerStyle',{}), unicode):
                data = json.loads(request.GET.get('containerStyle',None))
                count = data.get('count',None)

            popup_header = False
            if count >= 100:
                popup_header = True

            limit = 'limit 100'
            if request.GET.has_key('from_download'):
                limit = ''

            params = request.GET.get('params', {})
            if params:
                if isinstance(params, unicode) or isinstance(params, str):
                    params = json.loads(params)
                params = params.get('downloadParams', {})

            if request:
                if not request.GET._mutable:
                    request.GET._mutable = True
                request.GET.update(params)

            unit = ''
            filters = request.GET.get('filters',[])
            alarm_msg = request.GET.get('alarmMsg',[])
            node_id_list, res_id_list, node_stat_list, node_query, resource_query = self.basedatasource.get_filter_info(
                request, filters=filters)

            stat_id_query = "select statid from tblthresholds where setmsg = '%s';" % alarm_msg
            stat_id_obj = utility.execute_raw_query(stat_id_query)

            stat_name_query = "select rawdn from tblstatmap where statid = %s;" % \
                            stat_id_obj[0].get('statid', None)
            stat_name_obj = utility.execute_raw_query(stat_name_query)

            sql_query_for_stats = database_query_instance.get("Q_DASHBOARD_0000046") % ("'" + stat_name_obj[0].get('rawdn','') + "'")
            logger.info(
                "sql_query_for_stats for breach_alarm_based_stat_info function :: %s" % sql_query_for_stats)
            dataset_for_stats = utility.execute_raw_query(sql_query_for_stats)

            for data in dataset_for_stats:
                name_value_mapping.update({data.get('name',''):'avg'})
                new_table_header.append(data.get('name',''))
                raw_html_data_mapping.update({data.get('name',''):''})
                unit = data.get('unit','')

            sql_query_for_stats_in_popup = database_query_instance.get("Q_DASHBOARD_0000133") % \
                                           (resource_query, alarm_msg, limit)
            logger.info(
                "sql_query_for_stats_in_popup for breach_alarm_based_stat_info function :: %s" % sql_query_for_stats_in_popup)
            dataset_for_stats_popup = utility.execute_raw_query(sql_query_for_stats_in_popup)

            for data in dataset_for_stats_popup:
                data.update({'avg':formatValue(data.get('avg',None), unit)})

            table_data['data'] = dataset_for_stats_popup
            table_data['nameValueMapping'] = name_value_mapping
            table_data['rawHtmlDataMapping'] = raw_html_data_mapping
            table_data['newTableHeader'] = new_table_header
            table_data['popupHeader'] = popup_header
            ret['tableData'] = table_data
            return ret


        except Exception, err:
            logger.error("Error in breach_alarm_based_stat_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def breach_alarms_info(self, request):
        try:
            print "Inside breach_alarms_info function", request.GET
            ret = {}
            table_data = {}
            severity_mapping = {
                'critical': '6',
                'major': '5',
                'minor': '4,3',
                'normal': '2,1',
            }

            count = None
            if isinstance(request.GET.get('count',None), unicode):
                count = json.loads(request.GET.get('count',None))

            popup_header = False
            if count >= 100:
                popup_header = True

            limit = 'limit 100'
            if request.GET.has_key('from_download'):
                limit = ''

            params = request.GET.get('params', {})
            if params:
                if isinstance(params, unicode) or isinstance(params, str):
                    params = json.loads(params)
                params = params.get('downloadParams', {})

            if request:
                if not request.GET._mutable:
                    request.GET._mutable = True
                request.GET.update(params)

            severity = severity_mapping.get(str(request.GET.get('severity',[])),'')
            filters = request.GET.get('filters',[])
            node_id_list, res_id_list, node_stat_list, node_query, resource_query = self.basedatasource.get_filter_info(
                request, filters=filters)
            query_string_for_severity = ''
            if severity:
                query_string_for_severity = 'and severity in (' + severity + ') '
            sql_query_for_alarms_in_popup = database_query_instance.get("Q_DASHBOARD_0000097") % (query_string_for_severity,resource_query,limit)
            # print "sql_query_for_alarms_in_popup==>>",sql_query_for_alarms_in_popup
            logger.info(
                "sql_query_for_alarms_in_popup, breach_alarms_info, Dashboard Controller:: %s" % sql_query_for_alarms_in_popup)
            dataset_for_alarms_popup = utility.execute_raw_query(sql_query_for_alarms_in_popup)

            for data in dataset_for_alarms_popup:
                data.update({'time': time.ctime(data.get('time',None))})
                if data.get('severity',None) == 6:
                    data['severity'] = 'color-red'
                    data['status'] = 'Critical'
                elif data.get('severity',None) == 5:
                    data['severity'] = 'color-orange'
                    data['status'] = 'Major'
                elif data.get('severity',None) in [4,3]:
                    data['severity'] = 'color-yellow'
                    data['status'] = 'Minor'
                else:
                    data['severity'] = 'color-green'
                    data['status'] = 'Normal'

            table_data['data'] = dataset_for_alarms_popup
            table_data['popupHeader'] = popup_header
            ret['tableData'] = table_data
            return ret


        except Exception, err:
            logger.error("Error in breach_alarms_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def breach_events_info(self, request):
        try:
            # print "Inside breach_events_info function", request.GET.keys()
            ret = {}
            table_data = {}
            severity_mapping = {
                'critical': '6',
                'major': '5',
                'minor': '4,3',
                'normal': '2,1',
            }

            count = None
            if isinstance(request.GET.get('count',None), unicode):
                count = json.loads(request.GET.get('count',None))

            popup_header = False
            if count >= 100:
                popup_header = True

            limit = 'limit 100'
            if request.GET.has_key('from_download'):
                limit = ''

            params = request.GET.get('params', {})
            if params:
                if isinstance(params, unicode) or isinstance(params, str):
                    params = json.loads(params)
                params = params.get('downloadParams', {})

            if request:
                if not request.GET._mutable:
                    request.GET._mutable = True
                request.GET.update(params)
            severity = severity_mapping.get(request.GET.get('severity',[]),'')
            filters = request.GET.get('filters',[])
            timescale_int_0 = request.GET.get('timescaleInt_0',[])
            timescale_int_1 = request.GET.get('timescaleInt_1',[])
            timescale_str_0 = request.GET.get('timescaleStr_0',[])
            timescale_str_1 = request.GET.get('timescaleStr_1',[])
            node_id_list, res_id_list, node_stat_list, node_query, resource_query = self.basedatasource.get_filter_info(
                request, filters=filters)
            query_string_for_severity = ''
            if severity not in ['',-1,'-1','None',None]:
                query_string_for_severity = 'and severity in (' + severity + ') '

            query_tables = []
            if timescale_str_0 not in [(), "()", "", None] and timescale_str_1 not in [(), "()", "", None]:
                query_tables = utility.getTables('tblevents', timescale_str_0, timescale_str_1, 4)

            # print "query_tables==>",query_tables

            sub_query_str_list = [
                database_query_instance.get("Q001024") % (query_str, timescale_int_0, timescale_int_1
                                                          ) for query_str in query_tables]
            # print "sub_query_str_list==>",sub_query_str_list
            union_query_for_timescale = ''
            for query_str in sub_query_str_list:
                union_query_for_timescale = union_query_for_timescale + query_str + ' union all '

            union_query_for_timescale = '(' + str(union_query_for_timescale[:-11]) + ')'
            events_tables = []
            events_tables.insert(0, str(union_query_for_timescale))
            sql_query_for_events_in_popup = database_query_instance.get("Q_DASHBOARD_0000099") % \
                                           (events_tables[0],resource_query,query_string_for_severity, limit)
            # print "sql_query_for_events_in_popup==>",sql_query_for_events_in_popup
            logger.info("sql_query_for_events_in_popup, breach_events_info, Dashboard Controller:: %s" % sql_query_for_events_in_popup)
            dataset_for_events_popup = utility.execute_raw_query(sql_query_for_events_in_popup)

            for data in dataset_for_events_popup:
                data.update({'time': time.ctime(data.get('time',None))})
                if data.get('severity',None) == 6:
                    data['severity'] = 'color-red'
                    data['status'] = 'Critical'
                elif data.get('severity',None) == 5:
                    data['severity'] = 'color-orange'
                    data['status'] = 'Major'
                elif data.get('severity',None) in [4,3]:
                    data['severity'] = 'color-yellow'
                    data['status'] = 'Minor'
                else:
                    data['severity'] = 'color-green'
                    data['status'] = 'Normal'

            table_data['data'] = dataset_for_events_popup
            table_data['popupHeader'] = popup_header
            ret['tableData'] = table_data

            return ret


        except Exception, err:
            logger.error("Error in breach_events_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            print_traceback()
            return []

    def gauge_chart_info(self, request):
        try:
            print "Inside gauge_chart_info function", request.GET
            ret = {}
            table_data = {}
            unit = ''
            some_condition = ''
            name_value_mapping = {}
            new_table_header = []
            raw_html_data_mapping = {}
            dataset_for_stat = []
            filters = request.GET.get('filters',[])
            timescale = int(request.GET.get('timescale',[]))
            stat = "'" + request.GET.get('stat',[]) + "'"
            node_id_list, res_id_list, node_stat_list, node_query, resource_query = self.basedatasource.get_filter_info(
                request, filters=filters)

            if stat:
                sql_query_for_stat = database_query_instance.get("Q_DASHBOARD_0000046") % (stat)
                dataset_for_stat = utility.execute_raw_query(sql_query_for_stat)

            for data in dataset_for_stat:
                stat_id = data.get('statid',None)
                name_value_mapping.update({data.get('name',''):'avg'})
                new_table_header.append(data.get('name',''))
                raw_html_data_mapping.update({data.get('name',''):''})
                unit = data.get('unit','')

            if timescale == -1:
                current_time = safe_int(time.time())
                start_time = current_time - 3600
                end_time = current_time
                query_tables = getTables('tblraw', start_time, end_time)

                start_timestamp = current_time - 1800
                end_timestamp = current_time
                sub_query_str_list = [database_query_instance.get("Q001024") % (query_str ,start_timestamp, end_timestamp
                                                                            ) for query_str in query_tables]

            else:
                timescale_resolution_str = utility.TIME_SCALES_MAP.get(timescale)[3]
                if timescale_resolution_str not in ["", None]:
                    timescale_resolution_str = str(timescale_resolution_str)
                table_name = "tbl" + timescale_resolution_str

                timescale_str, timescale_int = self.basedatasource.get_timescale_info(timescale)

                query_tables = []
                if timescale_str not in [(), "()", "", None] and timescale_str not in [(), "()", "", None]:
                    interval_type = self.basedatasource.timescale_interval_type_map.get(timescale_resolution_str, 1)
                    query_tables = utility.getTables(table_name, timescale_str[0], timescale_str[1], interval_type)

                sub_query_str_list = [database_query_instance.get("Q001024") % (query_str ,timescale_int[0], timescale_int[1]
                                                                            ) for query_str in query_tables]
            union_query_for_timescale = ''
            for query_str in sub_query_str_list:
                union_query_for_timescale = union_query_for_timescale + query_str + ' union all '

            union_query_for_timescale = '(' + str(union_query_for_timescale[:-11]) + ')'
            raw_tables = []
            raw_tables.insert(0, str(union_query_for_timescale))

            sql_query_for_gauge_chart_data = database_query_instance.get("Q_DASHBOARD_0000088") % \
                                           (raw_tables[0],stat_id,resource_query,some_condition)
            dataset_for_gauge_chart = utility.execute_raw_query(sql_query_for_gauge_chart_data)

            for data in dataset_for_gauge_chart:
                data.update({'avg':round(data.get('avg',None), 2)})
                data.update({'avg':formatValue(data.get('avg',None), unit)})

            table_data['data'] = dataset_for_gauge_chart
            table_data['nameValueMapping'] = name_value_mapping
            table_data['rawHtmlDataMapping'] = raw_html_data_mapping
            table_data['newTableHeader'] = new_table_header
            ret['tableData'] = table_data

            return ret


        except Exception, err:
            logger.error("Error in gauge_chart_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            print_traceback()
            return []

    def get_link_inventory_info(self, request):
        """
        Description: Function is used to fetch the column names from tblnodeschema for the multiselect dropdown for Node Status Summary Widget.
        :param None.
        :return: Returning fetched data on to the UI using list.
        """
        try:
            # print "Inside get_link_inventory_info"
            sql_query_for_tblresconfig = database_query_instance.get("Q_DASHBOARD_0000040")
            objs_tblresconfig = execute_raw_query(sql_query_for_tblresconfig)
            # print "objs==>",objs
            sql_query_for_tblextraresinfo = database_query_instance.get("Q_DASHBOARD_0000041")
            objs_tblextraresinfo = execute_raw_query(sql_query_for_tblextraresinfo)
            obj = objs_tblresconfig + objs_tblextraresinfo
            return obj

        except Exception, err:
            logger.error("Error in get_link_inventory_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_link_inventory_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_drill_down_level_info(self, request):
        """
        Description: Function is used to fetch the level names from tblimsconfig for the dropdown menu for Link Drill Down Widget and Device Drill Down Widget.
        :param None.
        :return: Returning fetched data on to the UI using list.
        """
        try:
            # print "Inside get_drill_down_level_info"
            levels_sql_query = database_query_instance.get("Q_DASHBOARD_0000032")
            levels_objs = execute_raw_query(levels_sql_query)
            # print "levels_objs==>",levels_objs
            for data in levels_objs:
                if isinstance(data.get('value', ''), unicode):
                    data = data.get('value', '').encode('utf8')
                if type(data) == str:
                    levels = json.loads(data)
            query_string_for_mapping  = ''
            query_string_for_ordering = ''
            for index, value in enumerate(levels):
                query_string_for_mapping = query_string_for_mapping + "'" + str(value) + "'"
                query_string_for_ordering = query_string_for_ordering + " attr = " + "'" + str(value) + "'" + " desc"
                if index < len(levels) - 1:
                    query_string_for_mapping = query_string_for_mapping + ', '
                    query_string_for_ordering = query_string_for_ordering + ', '
            # print "query_string_for_ordering==>",query_string_for_ordering
            # print "query_string_for_mapping==>",query_string_for_mapping
            name_value_sql_query = database_query_instance.get("Q_DASHBOARD_0000039")%(query_string_for_mapping,query_string_for_ordering)
            # print "name_value_sql_query==>",name_value_sql_query
            name_value_objs = execute_raw_query(name_value_sql_query)
            # print "name_value_objs==>",name_value_objs
            return name_value_objs

        except Exception, err:
            # print_traceback()
            logger.error("Error in get_drill_down_level_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_drill_down_level_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_availability_info(self, request):
        try:
            function_start_time = time.time()
            logger.debug("Enter into get_availability_info function of DashboardController.")
            availability_type_info = AVAIL_STATS
            logger.debug("Overall time taken by get_availability_info function to complete: %f" % (time.time() - function_start_time))
            logger.debug("Exiting get_availability_info function of DashboardController.")
            return availability_type_info
        except Exception, err:
            logger.error("Error in get_availability_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_stat_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_stat_info(self, request):
        try:
            function_start_time = time.time()
            logger.debug("Enter into get_stat_info function of DashboardController.")
            # print("Enter into get_stat_info function of DashboardController.")
            stat_info_data = dict(
                aggregate=AGGREGATE_STAT_INFO_LIST,
                nonAggregate=NON_AGGREGATE_STAT_INFO_LIST,
                all=STAT_INFO_LIST,
                graphDataType=GRAPH_TYPE_STAT_INFO,
                thresholdStatInfo=AGGREGATE_STAT_THRESHOLD_INFO,
                statRawdnNameMap=STAT_RAW_DN_NAME_INFO_MAP,
                availability_type_info=AVAIL_STATS
            )
            # print("Overall time taken by get_stat_info function to complete: %f" % (time.time() - function_start_time))
            logger.debug("Overall time taken by get_stat_info function to complete: %f" % (time.time() - function_start_time))
            logger.debug("Exiting get_stat_info function of DashboardController.")
            return stat_info_data
        except Exception, err:
            logger.error("Error in get_stat_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_stat_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return {}

    def get_topology_list(self, request):
        try:
            function_start_time = time.time()
            logger.debug("Enter into get_topology_list function of DashboardController.")
            # print("Enter into get_topology_list function of DashboardController.")
            topo_list_qry = 'select rel_type as value, rel_name as name from tbltoporelationmap;'
            topo_list_objs = execute_raw_query(topo_list_qry)
            # print("Overall time taken by get_topology_list function to complete: %f" % (time.time() - function_start_time))
            logger.debug("Overall time taken by get_topology_list function to complete: %f" % (time.time() - function_start_time))
            logger.debug("Exiting get_topology_list function of DashboardController.")
            return topo_list_objs
        except Exception, err:
            logger.error("Error in get_topology_list function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_stat_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_service_filter_option_data(self, request):
        try:
            function_start_time = time.time()
            logger.debug("Enter into get_service_filter_option_data function of DashboardController.")
            service_filter_dict = {}
            service_filter_info_qry = "select nodeid1, nodeid2, customer_name, service_vlanid, bit_rate, service_profile from tblservices;"
            service_filter_info_objs = execute_raw_query(service_filter_info_qry)
            nodeid_list = []
            cust_name_list = []
            poll_addr_list = []
            vlanid_list = []
            bitrate_list = []
            service_profile_list = []
            for obj in service_filter_info_objs:
                temp_dict = {}
                nodeid_list.append(obj.get('nodeid1', None))
                nodeid_list.append(obj.get('nodeid1', None))
                temp_dict.update({'name': obj.get('customer_name', ''), 'value': obj.get('customer_name', '')})
                cust_name_list.append(temp_dict.copy())
                temp_dict.update({'name': obj.get('service_vlanid', ''), 'value': obj.get('service_vlanid', '')})
                vlanid_list.append(temp_dict.copy())
                temp_dict.update({'name': obj.get('bit_rate', ''), 'value': obj.get('bit_rate', '')})
                bitrate_list.append(temp_dict.copy())
                temp_dict.update({'name': obj.get('service_profile', ''), 'value': obj.get('service_profile', '')})
                service_profile_list.append(temp_dict.copy())
            nodeid_list = list(set(nodeid_list))
            nodeid_list_str = str(nodeid_list)[1:-1]
            poll_addr_qry = "select poll_addr from tblnodeinfo where nodeid in (%s);" % nodeid_list_str
            poll_addr_objs = execute_raw_query(poll_addr_qry)
            for val in poll_addr_objs:
                temp_dict = {}
                temp_dict.update({'name': val.get('poll_addr', ''), 'value': val.get('poll_addr', '')})
                poll_addr_list.append(temp_dict.copy())
            service_filter_dict['customer'] = [dict(t) for t in {tuple(d.items()) for d in cust_name_list}]
            service_filter_dict['pollAddr'] = [dict(t) for t in {tuple(d.items()) for d in poll_addr_list}]
            service_filter_dict['serviceVlanId'] = [dict(t) for t in {tuple(d.items()) for d in vlanid_list}]
            service_filter_dict['bitRate'] = [dict(t) for t in {tuple(d.items()) for d in bitrate_list}]
            service_filter_dict['serviceProfile'] = [dict(t) for t in {tuple(d.items()) for d in service_profile_list}]
            logger.debug("Overall time taken by get_service_filter_option_data function to complete: %f" % (time.time() - function_start_time))
            logger.debug("Exiting get_service_filter_option_data function of DashboardController.")
            return service_filter_dict
        except Exception, err:
            logger.error("Error in get_service_filter_option_data function of DashboardController:%s (%s)" % (err.message, type(err)))
            print_traceback()
            # print("Error in get_stat_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return {}

    def get_sd_integration_data(self, request):
        try:
            function_start_time = time.time()
            logger.debug("Enter into get_sd_integration_data function of DashboardController.")
            options_url = "/inci/incidentinfo/options"
            options_res = self.service_mngr_info.app_get_request(options_url)
            catalogue_url = "/catalogue/catalogue/cataloguetree/"
            catalogue_res = self.service_mngr_info.app_get_request(catalogue_url)

            inci_severity = []
            priority = []
            status = []
            state = []
            id_catg_map = {}

            categories = catalogue_res.json()['catagories']

            for catg_keys in categories:
                id_catg_map.update({catg_keys.get('id',None):catg_keys.get('name','')})

            servicetree = catalogue_res.json()['servicetree']
            serv_dict = {}
            classified_objs_serv = classify_objs(servicetree, lambda x: x.get('parent'))
            for serv_keys in classified_objs_serv.keys():
                temp_list = []
                data = classified_objs_serv.get(serv_keys,[])
                for val in data:
                    temp_list.append(val.get('name',''))
                serv_dict.update({id_catg_map.get(serv_keys,''):temp_list})
            del serv_dict['']

            res_priority = options_res.json()['priority']
            res_severity = options_res.json()['severity']
            res_state = options_res.json()['state']
            res_status = options_res.json()['status']

            for val in res_priority:
                value = "{filterItem: {name:'Priority',value:'priority__name'}, filterValue:'%s'}" % val.get('name','')
                dict_pri = {}
                dict_pri.update({'name':val.get('name',''), 'value': value})
                priority.append(dict_pri)

            for val in res_severity:
                value = "{filterItem: {name:'Severity',value:'severity__name'}, filterValue:'%s'}" % val.get('name','')
                dict_sev = {}
                dict_sev.update({'name':val.get('name',''), 'value': value})
                inci_severity.append(dict_sev)

            for val in res_state:
                value = "{filterItem: {name:'State',value:'state__name'}, filterValue:'%s'}" % val.get('name','')
                dict_state = {}
                dict_state.update({'name':val.get('name',''), 'value': value})
                state.append(dict_state)

            for val in res_status:
                value = "{filterItem: {name:'Status',value:'status__name'}, filterValue:'%s'}" % val.get('name','')
                dict_status = {}
                dict_status.update({'name':val.get('name',''), 'value': value})
                status.append(dict_status)

            logger.debug("Overall time taken by get_sd_integration_data function to complete: %f" % (time.time() - function_start_time))
            logger.debug("Exiting get_sd_integration_data function of DashboardController.")
            return dict(priority=priority, inciSeverity=inci_severity, state=state, status=status, catalogue=serv_dict)

        except Exception, err:
            logger.error("Error in get_sd_integration_data function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_stat_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return {}

    def get_group_by_info(self, request):
        try:
            function_start_time = time.time()
            logger.debug("Enter into get_group_by_info function of DashboardController.")
            group_by_info = [
                {"name": "Time Scale", "value": "timestamp"},
                {"name": "Resource", "value": "t_resid"},
                {"name": "Statistics", "value": "t_statid"},
                {"name": "Country", "value": "country"},
                {"name": "Host Name", "value": "hostname"},
                {"name": "IP Address", "value": "host_addr"}
            ]
            levels_sql_query = database_query_instance.get("Q_DASHBOARD_0000032")
            levels_obj = utility.execute_raw_query(levels_sql_query)
            # print "levels_obj: ", levels_obj
            if levels_obj:
                level_list = levels_obj[0].get("value", [])
                if isinstance(level_list, unicode):
                    level_list = level_list.encode('utf8')
                if isinstance(level_list, str):
                    level_list = json.loads(level_list)
                # print "level_list: ", level_list, type(level_list)
                level_list = ['%s' % str(x) for x in level_list]

                if level_list:
                    level_display_name_sql_query = "select attr as value, name_to_display as display_name from " \
                                                   "(SELECT *, CASE WHEN coalesce(TRIM(display_name), '') = '' " \
                                                   "THEN actual_name ELSE display_name END as name_to_display FROM " \
                                                   "tblNodeSchema) as tb1 where attr in (%s)" % str(level_list)[1:-1]
                    # print "level_display_name_sql_query: ", level_display_name_sql_query
                    levels_info_obj = utility.execute_raw_query(level_display_name_sql_query)
                    # print "levels_info_obj: ", levels_info_obj
                    if levels_info_obj:
                        for level_info in levels_info_obj:
                            group_by_info.append(dict(name=str(level_info.get("display_name", "")),
                                                      value=str(level_info.get("value", ""))))
            # print "group_by_info: ", group_by_info
            logger.debug("Overall time taken by get_group_by_info function to complete: %f" % (time.time() - function_start_time))
            logger.debug("Exiting get_group_by_info function of DashboardController.")
            # print "group_by_info==>",group_by_info
            return group_by_info
        except Exception, err:
            logger.error("Error in get_group_by_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_group_by_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def get_res_status_drilldown_popup(self, request):
        try:
            # print "\nInside get_res_status_drill_down_info of ResourceDataSource.\n", request.GET
            data_source = request.GET.get('datasource', {})
            data_options = request.GET.get('dataOptions', {})
            params = request.GET.get('params',{})

            if data_source:
                if isinstance(data_source, unicode) or isinstance(data_source, str):
                    data_source = json.loads(data_source)
                # data_source = data_source.get('downloadParams', {})

            if data_options:
                if isinstance(data_options, unicode) or isinstance(data_options, str):
                    data_options = json.loads(data_options)
                # data_options = data_options.get('downloadParams', {})

            if params:
                if isinstance(params, unicode) or isinstance(params, str):
                    params = json.loads(params)
                params = params.get('downloadParams', {})
                data_source = params.get('datasource', {})
                data_options = params.get('dataOptions', {})

            ret = {}
            table_data = {}
            header_mapping_fwd = {}
            avail_rawdn = data_options.get('availType', '')
            avail_rawdn_query_str = "'" + avail_rawdn + "'"
            status_type = str(data_source.get('param', {}).get('type',''))
            filters = data_options.get('filters', {})
            type_query_str = ''
            if not status_type or status_type == 'total':
                type_query_str = ''
            if status_type == 'up':
                type_query_str = ' and avg = 100 '
            if status_type == 'down':
                type_query_str = ' and avg = 0 '

            avail_rawdn_query = database_query_instance.get("Q_DASHBOARD_0000046") % avail_rawdn_query_str
            objs_for_avail_rawdn = utility.execute_raw_query(avail_rawdn_query)

            avail_stat = 0
            for data in objs_for_avail_rawdn:
                avail_stat = data.get('statid', None)

            node_list, resource_list, node_stat_list, node_query, resource_info_query = self.basedatasource.get_filter_info(
                request, filters=filters, show_only_interfaces=False)

            current_time = safe_int(time.time())
            start_time = current_time - 3600
            end_time = current_time
            query_tables = getTables('tblraw', start_time, end_time)

            start_timestamp = current_time - 1800
            end_timestamp = current_time
            sub_query_str_list = [
                database_query_instance.get("Q001024") % (query_str, start_timestamp, end_timestamp
                                                          ) for query_str in query_tables]
            union_query_for_timescale = ''
            for query_str in sub_query_str_list:
                union_query_for_timescale = union_query_for_timescale + query_str + ' union all '

            union_query_for_timescale = '(' + str(union_query_for_timescale[:-11]) + ')'
            raw_tables = []
            raw_tables.insert(0, str(union_query_for_timescale))

            levels_sql_query = database_query_instance.get("Q_DASHBOARD_0000032")
            levels_objs = utility.execute_raw_query(levels_sql_query)
            for data in levels_objs:
                if isinstance(data.get('value', ''), unicode):
                    data = data.get('value', '').encode('utf8')
                if type(data) == str:
                    levels = json.loads(data)
            levels.append('hostname')
            parent_level = data_options.get('levelInfo', '')
            if parent_level not in ["", "None", "-1", None, -1]:
                parent_index = levels.index(parent_level)
            else:
                parent_index = 0
            levels = levels[parent_index:]
            parent_child_relation_map, header_mapping = self.basedatasource.form_parent_child_info(parent_level)

            for level_name in levels:
                header_mapping_fwd[
                    parent_child_relation_map.get(level_name, {}).get('display_name', '')] = level_name

            parent_level_name = header_mapping_fwd.get(data_source.get('param', {}).get('parentLevelName', ''), '')
            parent_level_value = data_source.get('param', {}).get('parentLevelValue', '')
            query_string = "where %s = '%s' and " % (parent_level_name, parent_level_value)
            for data in data_source.get('param', {}).get('parentLevelInfo', ''):
                query_string = query_string + "%s = '%s'" % (
                header_mapping_fwd.get(data.get('parent_node_display_name', ''), ''),
                data.get('previous_level_value', '')) + ' and '
            query_string = query_string[:-5]

            head_for_popup = header_mapping_fwd.get(data_source.get('param', {}).get('head', ''), '')
            value_for_popup = data_source.get('param', {}).get('value', '')
            popup_qry_str = " where %s = '%s' " % (head_for_popup, value_for_popup)

            if parent_level_name == '' and parent_level_value == '':
                sql_query_for_popup_data = database_query_instance.get("Q_DASHBOARD_0000110") % (
                    resource_info_query, raw_tables[0], avail_stat, popup_qry_str, type_query_str)
                logger.info(
                    "sql_query_for_popup_data for get_res_status_drill_down_info function, ResourceDataSource :: %s" % sql_query_for_popup_data)
                objs_for_popup = utility.execute_raw_query(sql_query_for_popup_data)
                for obj in objs_for_popup:
                    if obj.get('avg', None) == 100:
                        obj['severity'] = 'color-green'
                        obj['status'] = 'Up'
                    else:
                        obj['severity'] = 'color-red'
                        obj['status'] = 'Down'
                table_data['popUpData'] = objs_for_popup
                table_data['head'] = data_source.get('param', {}).get('head', '')
                table_data['value'] = value_for_popup

                ret['tableData'] = table_data

            else:
                sql_query_for_popup_data = database_query_instance.get("Q_DASHBOARD_0000111") % (
                    resource_info_query, raw_tables[0], avail_stat, query_string, popup_qry_str, type_query_str)
                logger.info(
                    "sql_query_for_popup_data for get_res_status_drill_down_info function, ResourceDataSource :: %s" % sql_query_for_popup_data)
                objs_for_popup = utility.execute_raw_query(sql_query_for_popup_data)
                for obj in objs_for_popup:
                    if obj.get('avg', None) == 100:
                        obj['severity'] = 'color-green'
                        obj['status'] = 'Up'
                    else:
                        obj['severity'] = 'color-red'
                        obj['status'] = 'Down'
                table_data['popUpData'] = objs_for_popup
                table_data['head'] = data_source.get('param', {}).get('head', '')
                table_data['value'] = value_for_popup
                ret['tableData'] = table_data
            no_data = False
            if len(objs_for_popup) is 0:
                no_data = True
            ret['noData'] = no_data
            return ret

        except Exception, err:
            print_traceback()
            logger.error("Error in get_res_status_drill_down_info function of ResourceDataSource:%s (%s)" % (
            err.message, type(err)))
            return {}

    def get_node_status_drilldown_popup(self, request):
        try:
            data_source = request.GET.get('datasource', {})
            data_options = request.GET.get('dataOptions', {})
            params = request.GET.get('params',{})

            if data_source:
                if isinstance(data_source, unicode) or isinstance(data_source, str):
                    data_source = json.loads(data_source)

            if data_options:
                if isinstance(data_options, unicode) or isinstance(data_options, str):
                    data_options = json.loads(data_options)

            if params:
                if isinstance(params, unicode) or isinstance(params, str):
                    params = json.loads(params)
                params = params.get('downloadParams', {})
                data_source = params.get('datasource', {})
                data_options = params.get('dataOptions', {})

            ret = {}
            table_data = {}
            header_mapping_fwd = {}
            status_type = str(data_source.get('param', {}).get('type',''))
            filters = data_options.get('filters', {})
            type_query_str = ''
            if not status_type or status_type == 'total':
                type_query_str = ''
            if status_type == 'up':
                type_query_str = ' a.isdeleted = 1 and '
            if status_type == 'down':
                type_query_str = ' a.isdeleted = 0 and '

            node_list, resource_list, node_stat_list, node_query, resource_info_query = self.basedatasource.get_filter_info(
                request, filters=filters, show_only_interfaces=False)

            levels_sql_query = database_query_instance.get("Q_DASHBOARD_0000032")
            levels_objs = utility.execute_raw_query(levels_sql_query)
            for data in levels_objs:
                if isinstance(data.get('value', ''), unicode):
                    data = data.get('value', '').encode('utf8')
                if type(data) == str:
                    levels = json.loads(data)
            levels.append('hostname')
            parent_level = data_options.get('levelInfo', '')
            if parent_level not in ["", "None", "-1", None, -1]:
                parent_index = levels.index(parent_level)
            else:
                parent_index = 0
            levels = levels[parent_index:]
            parent_child_relation_map, header_mapping = self.basedatasource.form_parent_child_info(parent_level)

            for level_name in levels:
                header_mapping_fwd[
                    parent_child_relation_map.get(level_name, {}).get('display_name', '')] = level_name

            parent_level_name = header_mapping_fwd.get(data_source.get('param', {}).get('parentLevelName', ''), '')
            parent_level_value = data_source.get('param', {}).get('parentLevelValue', '')
            query_string = "where %s = '%s' and " % (parent_level_name, parent_level_value)
            for data in data_source.get('param', {}).get('parentLevelInfo', ''):
                query_string = query_string + "%s = '%s'" % (
                header_mapping_fwd.get(data.get('parent_node_display_name', ''), ''),
                data.get('previous_level_value', '')) + ' and '
            query_string = query_string[:-5]

            head_for_popup = header_mapping_fwd.get(data_source.get('param', {}).get('head', ''), '')
            value_for_popup = data_source.get('param', {}).get('value', '')

            if parent_level_name == '' and parent_level_value == '':
                sql_query_for_popup_data = database_query_instance.get("Q_DASHBOARD_0000045") % (
                type_query_str, node_query, head_for_popup, value_for_popup)
                objs_for_popup = utility.execute_raw_query(sql_query_for_popup_data)
                for data in objs_for_popup:
                    if data.get('status', None) == 1:
                        data['severity'] = 'color-green'
                        data['status'] = 'Up'
                    elif data.get('status', None) == 0:
                        data['severity'] = 'color-red'
                        data['status'] = 'Down'
                    else:
                        data['severity'] = 'color-grey'
                        data['status'] = 'Disabled'
                table_data['popUpData'] = objs_for_popup
                table_data['head'] = data_source.get('param', {}).get('head', '')
                table_data['value'] = value_for_popup

                ret['tableData'] = table_data

            else:
                sql_query_for_popup_data = database_query_instance.get("Q_DASHBOARD_0000054") % (query_string,type_query_str,
                node_query, head_for_popup, value_for_popup)
                objs_for_popup = utility.execute_raw_query(sql_query_for_popup_data)
                for data in objs_for_popup:
                    if data.get('status', None) == 1:
                        data['severity'] = 'color-green'
                        data['status'] = 'Up'
                    elif data.get('status', None) == 0:
                        data['severity'] = 'color-red'
                        data['status'] = 'Down'
                    else:
                        data['severity'] = 'color-grey'
                        data['status'] = 'Disabled'
                table_data['popUpData'] = objs_for_popup
                table_data['head'] = data_source.get('param', {}).get('head', '')
                table_data['value'] = value_for_popup
                ret['tableData'] = table_data
            no_data = False
            if len(objs_for_popup) is 0:
                no_data = True
            ret['noData'] = no_data
            return ret

        except Exception, err:
            print_traceback()
            logger.error("Error in get_res_status_drill_down_info function of ResourceDataSource:%s (%s)" % (
            err.message, type(err)))
            return {}

    def get_link_drilldown_popup(self, request):
        try:
            data_source = request.GET.get('datasource', {})
            data_options = request.GET.get('dataOptions', {})
            params = request.GET.get('params',{})

            if data_source:
                if isinstance(data_source, unicode) or isinstance(data_source, str):
                    data_source = json.loads(data_source)

            if data_options:
                if isinstance(data_options, unicode) or isinstance(data_options, str):
                    data_options = json.loads(data_options)

            if params:
                if isinstance(params, unicode) or isinstance(params, str):
                    params = json.loads(params)
                params = params.get('downloadParams', {})
                data_source = params.get('datasource', {})
                data_options = params.get('dataOptions', {})

            ret = {}
            profiles = str(INTERFACE_CFGS)[1:-1]
            table_data = {}
            header_mapping_fwd = {}
            rawdn_list = []
            new_table_header = []
            rawdn_thres_mapping = {}
            statid_rawdn = 0
            statid_rawdn_name = ''
            name_value_mapping_stats = {}
            new_table_header_stats = []
            raw_html_data_mapping_stats = {}
            is_stat = data_source.get('isStat',False)
            filters = data_options.get('filters', {})
            stat_info = data_options.get('statInfo', [])
            stat_rawdn = data_source.get('param', {}).get('stat_raw_dn','')
            query_str_stat_rawdn = "'" + stat_rawdn + "'"

            if query_str_stat_rawdn:
                sql_query_for_stat_rawdn = database_query_instance.get("Q_DASHBOARD_0000046")%query_str_stat_rawdn
                objs_for_stat_rawdn = utility.execute_raw_query(sql_query_for_stat_rawdn)

            for data in objs_for_stat_rawdn:
                statid_rawdn = data.get('statid',None)
                statid_rawdn_name = data.get('name','')
                name_value_mapping_stats.update({data.get('name',''):'avg'})
                new_table_header_stats.append(data.get('name',''))
                raw_html_data_mapping_stats.update({data.get('name',''):''})
                unit = data.get('unit','')

            for data in stat_info:
                new_table_header.append(data.get('name',''))

            node_list, resource_list, node_stat_list, node_query, resource_info_query = self.basedatasource.get_filter_info(request, filters=filters, show_only_interfaces=False)
            for val in stat_info:
                rawdn_list.append(val.get('raw_dn',''))
                rawdn_thres_dict = {}
                rawdn_thres_dict.update({val.get('raw_dn',''):val.get('threshold', {})})
                if rawdn_thres_dict.get(val.get('raw_dn',''),{}) != {}:
                    threshold_data = rawdn_thres_dict.get(val.get('raw_dn',''),{})
                    threshold_range = self.basedatasource.get_threshold_range_info(threshold_data)
                    rawdn_thres_mapping.update({val.get('raw_dn',''):threshold_range})

            current_time = safe_int(time.time())
            start_time = current_time - 3600
            end_time = current_time
            query_tables = getTables('tblraw', start_time, end_time)

            start_timestamp = current_time - 1800
            end_timestamp = current_time
            sub_query_str_list = [database_query_instance.get("Q001024") % (query_str, start_timestamp, end_timestamp
                                                                            ) for query_str in query_tables]
            union_query_for_timescale = ''
            for query_str in sub_query_str_list:
                union_query_for_timescale = union_query_for_timescale + query_str + ' union all '

            union_query_for_timescale = '(' + str(union_query_for_timescale[:-11]) + ')'
            raw_tables = []
            raw_tables.insert(0, str(union_query_for_timescale))

            levels_sql_query = database_query_instance.get("Q_DASHBOARD_0000032")
            levels_objs = utility.execute_raw_query(levels_sql_query)
            levels = []
            for data in levels_objs:
                if isinstance(data.get('value', ''), unicode):
                    data = data.get('value', '').encode('utf8')
                if type(data) == str:
                    levels = json.loads(data)
            levels.append('hostname')
            parent_level = data_options.get('levelInfo', '')
            if parent_level not in ["", "None", "-1", None, -1]:
                parent_index = levels.index(parent_level)
            else:
                parent_index = 0
            levels = levels[parent_index:]
            parent_child_relation_map, header_mapping = self.basedatasource.form_parent_child_info(parent_level)

            for level_name in levels:
                header_mapping_fwd[parent_child_relation_map.get(level_name,{}).get('display_name','')] = level_name

            reverse_header_mapping = {v: k for k, v in header_mapping.iteritems()}
            parent_level_name = header_mapping_fwd.get(data_source.get('param', {}).get('parentLevelName', ''),'')
            parent_level_value = data_source.get('param', {}).get('parentLevelValue', '')
            parent_level_stat_name = data_source.get('param', {}).get('head', '')
            parent_level_stat_value = data_source.get('param', {}).get('value', '')
            query_string = "where %s = '%s' and " % (parent_level_name, parent_level_value)
            query_string_for_stat_popup = " and %s = '%s'" % (reverse_header_mapping.get(parent_level_stat_name,''), parent_level_stat_value)
            for data in data_source.get('param', {}).get('parentLevelInfo', ''):
                query_string = query_string + "%s = '%s'" % (header_mapping_fwd.get(data.get('parent_node_display_name',''),''),data.get('previous_level_value','')) + ' and '
            query_string = query_string[:-5]

            head_for_popup = header_mapping_fwd.get(data_source.get('param', {}).get('head', ''),'')
            value_for_popup = data_source.get('param', {}).get('value', '')

            if parent_level_name == '' and parent_level_value == '':
                sql_query_for_popup_data = database_query_instance.get("Q_DASHBOARD_0000052") % (profiles, resource_info_query, head_for_popup, value_for_popup)
                logger.info("sql_query_for_popup_data for get_link_drill_down_info function, ResourceDataSource :: %s" % sql_query_for_popup_data)
                objs_for_popup = utility.execute_raw_query(sql_query_for_popup_data)
                for obj in objs_for_popup:
                    obj.update({'bw_configured':formatValue(obj.get('bw_configured', None), 'bps')})
                    if obj.get('status', None) == 1:
                        obj['severity'] = 'color-green'
                        obj['status'] = 'Up'
                    elif obj.get('status', None) == 0:
                        obj['severity'] = 'color-red'
                        obj['status'] = 'Down'
                    else:
                        obj['severity'] = 'color-grey'
                        obj['status'] = 'Disabled'
                table_data['popUpData'] = objs_for_popup
                table_data['head'] = data_source.get('param', {}).get('head', '')
                table_data['value'] = value_for_popup
                ret['tableData'] = table_data

                if is_stat:
                    sql_query_for_popup_stats_data = database_query_instance.get("Q_DASHBOARD_0000100") % (
                    raw_tables[0], statid_rawdn, resource_info_query, head_for_popup, value_for_popup)
                    logger.info("sql_query_for_popup_stats_data for get_link_drill_down_info function, ResourceDataSource :: %s" % sql_query_for_popup_stats_data)
                    objs_for_stats_popup = utility.execute_raw_query(sql_query_for_popup_stats_data)

                    for data in objs_for_stats_popup:
                        data.update({'avg': round(data.get('avg', None), 2)})
                        data.update({'avg': formatValue(data.get('avg', None), unit)})

                    table_data['popUpDataStats'] = objs_for_stats_popup
                    table_data['head'] = data_source.get('param', {}).get('head', '')
                    table_data['value'] = value_for_popup
                    table_data['statName'] = statid_rawdn_name
                    table_data['nameValueMappingStats'] = name_value_mapping_stats
                    table_data['rawHtmlDataMappingStats'] = raw_html_data_mapping_stats
                    table_data['newTableHeaderStats'] = new_table_header_stats
                    ret['tableData'] = table_data

            else:
                sql_query_for_popup_data = database_query_instance.get("Q_DASHBOARD_0000044") % (profiles, resource_info_query, query_string, head_for_popup, value_for_popup)
                logger.info("sql_query_for_popup_data for get_link_drill_down_info function, ResourceDataSource :: %s" % sql_query_for_popup_data)
                objs_for_popup = utility.execute_raw_query(sql_query_for_popup_data)
                for obj in objs_for_popup:
                    obj.update({'bw_configured':formatValue(obj.get('bw_configured', None), 'bps')})
                    if obj.get('status', None) == 1:
                        obj['severity'] = 'color-green'
                        obj['status'] = 'Up'
                    elif obj.get('status', None) == 0:
                        obj['severity'] = 'color-red'
                        obj['status'] = 'Down'
                    else:
                        obj['severity'] = 'color-grey'
                        obj['status'] = 'Disabled'
                table_data['popUpData'] = objs_for_popup
                table_data['head'] = data_source.get('param', {}).get('head', '')
                table_data['value'] = value_for_popup
                ret['tableData'] = table_data

                if is_stat:
                    sql_query_for_popup_stats_data = database_query_instance.get("Q_DASHBOARD_0000101") % (
                    raw_tables[0], statid_rawdn, resource_info_query, head_for_popup, value_for_popup, query_string_for_stat_popup)
                    logger.info("sql_query_for_popup_stats_data for get_link_drill_down_info function, ResourceDataSource :: %s" % sql_query_for_popup_stats_data)
                    objs_for_stats_popup = utility.execute_raw_query(sql_query_for_popup_stats_data)

                    for data in objs_for_stats_popup:
                        data.update({'avg': round(data.get('avg', None), 2)})
                        data.update({'avg': formatValue(data.get('avg', None), unit)})

                    table_data['popUpDataStats'] = objs_for_stats_popup
                    table_data['head'] = data_source.get('param', {}).get('head', '')
                    table_data['value'] = value_for_popup
                    table_data['statName'] = statid_rawdn_name
                    table_data['nameValueMappingStats'] = name_value_mapping_stats
                    table_data['rawHtmlDataMappingStats'] = raw_html_data_mapping_stats
                    table_data['newTableHeaderStats'] = new_table_header_stats
                    ret['tableData'] = table_data

            return ret

        except Exception, err:
            print_traceback()
            logger.error("Error in get_res_status_drill_down_info function of ResourceDataSource:%s (%s)" % (
            err.message, type(err)))
            return {}

    def get_node_drilldown_popup(self, request):
        try:
            data_source = request.GET.get('datasource', {})
            data_options = request.GET.get('dataOptions', {})
            params = request.GET.get('params',{})

            if data_source:
                if isinstance(data_source, unicode) or isinstance(data_source, str):
                    data_source = json.loads(data_source)

            if data_options:
                if isinstance(data_options, unicode) or isinstance(data_options, str):
                    data_options = json.loads(data_options)

            if params:
                if isinstance(params, unicode) or isinstance(params, str):
                    params = json.loads(params)
                params = params.get('downloadParams', {})
                data_source = params.get('datasource', {})
                data_options = params.get('dataOptions', {})

            ret = {}
            table_data = {}
            header_mapping_fwd = {}
            rawdn_list = []
            new_table_header = []
            rawdn_thres_mapping = {}
            statid_rawdn = 0
            statid_rawdn_name = ''
            name_value_mapping_stats = {}
            new_table_header_stats = []
            raw_html_data_mapping_stats = {}
            is_stat = data_source.get('isStat', False)
            filters = data_options.get('filters', {})
            stat_info = data_options.get('statInfo', [])
            stat_rawdn = data_source.get('param', {}).get('stat_raw_dn','')
            query_str_stat_rawdn = "'" + stat_rawdn + "'"

            if query_str_stat_rawdn:
                sql_query_for_stat_rawdn = database_query_instance.get("Q_DASHBOARD_0000046")%query_str_stat_rawdn
                objs_for_stat_rawdn = utility.execute_raw_query(sql_query_for_stat_rawdn)

            for data in objs_for_stat_rawdn:
                statid_rawdn = data.get('statid',None)
                statid_rawdn_name = data.get('name','')
                name_value_mapping_stats.update({data.get('name',''):'avg'})
                new_table_header_stats.append(data.get('name',''))
                raw_html_data_mapping_stats.update({data.get('name',''):''})
                unit = data.get('unit','')

            for data in stat_info:
                new_table_header.append(data.get('name',''))

            node_list, resource_list, node_stat_list, node_query, resource_info_query = self.basedatasource.get_filter_info(request, filters=filters, show_only_interfaces=False)
            for val in stat_info:
                rawdn_list.append(val.get('raw_dn',''))
                rawdn_thres_dict = {}
                rawdn_thres_dict.update({val.get('raw_dn',''):val.get('threshold', {})})
                if rawdn_thres_dict.get(val.get('raw_dn',''),{}) != {}:
                    threshold_data = rawdn_thres_dict.get(val.get('raw_dn',''),{})
                    threshold_range = self.basedatasource.get_threshold_range_info(threshold_data)
                    rawdn_thres_mapping.update({val.get('raw_dn',''):threshold_range})

            current_time = safe_int(time.time())
            start_time = current_time - 3600
            end_time = current_time
            query_tables = getTables('tblraw', start_time, end_time)

            start_timestamp = current_time - 1800
            end_timestamp = current_time
            sub_query_str_list = [database_query_instance.get("Q001024") % (query_str, start_timestamp, end_timestamp
                                                                            ) for query_str in query_tables]
            union_query_for_timescale = ''
            for query_str in sub_query_str_list:
                union_query_for_timescale = union_query_for_timescale + query_str + ' union all '

            union_query_for_timescale = '(' + str(union_query_for_timescale[:-11]) + ')'
            raw_tables = []
            raw_tables.insert(0, str(union_query_for_timescale))

            levels_sql_query = database_query_instance.get("Q_DASHBOARD_0000032")
            levels_objs = utility.execute_raw_query(levels_sql_query)
            levels = []
            for data in levels_objs:
                if isinstance(data.get('value', ''), unicode):
                    data = data.get('value', '').encode('utf8')
                if type(data) == str:
                    levels = json.loads(data)
            levels.append('hostname')
            parent_level = data_options.get('levelInfo', '')
            if parent_level not in ["", "None", "-1", None, -1]:
                parent_index = levels.index(parent_level)
            else:
                parent_index = 0
            levels = levels[parent_index:]
            parent_child_relation_map, header_mapping = self.basedatasource.form_parent_child_info(parent_level)

            for level_name in levels:
                header_mapping_fwd[parent_child_relation_map.get(level_name,{}).get('display_name','')] = level_name

            reverse_header_mapping = {v: k for k, v in header_mapping.iteritems()}
            parent_level_name = header_mapping_fwd.get(data_source.get('param', {}).get('parentLevelName', ''),'')
            parent_level_value = data_source.get('param', {}).get('parentLevelValue', '')
            parent_level_stat_name = data_source.get('param', {}).get('head', '')
            parent_level_stat_value = data_source.get('param', {}).get('value', '')
            query_string = "where %s = '%s' and " % (parent_level_name, parent_level_value)
            query_string_for_stat_popup = " and %s = '%s'" % (reverse_header_mapping.get(parent_level_stat_name,''), parent_level_stat_value)
            for data in data_source.get('param', {}).get('parentLevelInfo', ''):
                query_string = query_string + "%s = '%s'" % (header_mapping_fwd.get(data.get('parent_node_display_name',''),''),data.get('previous_level_value','')) + ' and '
            query_string = query_string[:-5]

            head_for_popup = header_mapping_fwd.get(data_source.get('param', {}).get('head', ''),'')
            value_for_popup = data_source.get('param', {}).get('value', '')

            if parent_level_name == '' and parent_level_value == '':
                sql_query_for_popup_data = database_query_instance.get("Q_DASHBOARD_0000045") % (
                '',node_query, head_for_popup, value_for_popup)
                # print "sql_query_for_popup_data==>",sql_query_for_popup_data
                objs_for_popup = utility.execute_raw_query(sql_query_for_popup_data)
                for data in objs_for_popup:
                    if data.get('status', None) == 1:
                        data['severity'] = 'color-green'
                        data['status'] = 'Up'
                    elif data.get('status', None) == 0:
                        data['severity'] = 'color-red'
                        data['status'] = 'Down'
                    else:
                        data['severity'] = 'color-grey'
                        data['status'] = 'Disabled'
                table_data['popUpData'] = objs_for_popup
                table_data['head'] = data_source.get('param', {}).get('head', '')
                table_data['value'] = value_for_popup
                ret['tableData'] = table_data

                if is_stat:
                    sql_query_for_popup_stats_data = database_query_instance.get("Q_DASHBOARD_0000100") % (
                    raw_tables[0], statid_rawdn, resource_info_query, head_for_popup, value_for_popup)
                    # print "sql_query_for_popup_stats_data==>",sql_query_for_popup_stats_data
                    objs_for_stats_popup = utility.execute_raw_query(sql_query_for_popup_stats_data)

                    for data in objs_for_stats_popup:
                        data.update({'avg': round(data.get('avg', None), 2)})
                        data.update({'avg': formatValue(data.get('avg', None), unit)})

                    table_data['popUpDataStats'] = objs_for_stats_popup
                    table_data['head'] = data_source.get('param', {}).get('head', '')
                    table_data['value'] = value_for_popup
                    table_data['statName'] = statid_rawdn_name
                    table_data['nameValueMappingStats'] = name_value_mapping_stats
                    table_data['rawHtmlDataMappingStats'] = raw_html_data_mapping_stats
                    table_data['newTableHeaderStats'] = new_table_header_stats
                    ret['tableData'] = table_data

            else:
                sql_query_for_popup_data = database_query_instance.get("Q_DASHBOARD_0000054") % (query_string,'',
                node_query, head_for_popup, value_for_popup)
                # print "sql_query_for_popup_data==>",sql_query_for_popup_data
                objs_for_popup = utility.execute_raw_query(sql_query_for_popup_data)
                for data in objs_for_popup:
                    if data.get('status', None) == 1:
                        data['severity'] = 'color-green'
                        data['status'] = 'Up'
                    elif data.get('status', None) == 0:
                        data['severity'] = 'color-red'
                        data['status'] = 'Down'
                    else:
                        data['severity'] = 'color-grey'
                        data['status'] = 'Disabled'
                table_data['popUpData'] = objs_for_popup
                table_data['head'] = data_source.get('param', {}).get('head', '')
                table_data['value'] = value_for_popup
                ret['tableData'] = table_data

                if is_stat:
                    sql_query_for_popup_stats_data = database_query_instance.get("Q_DASHBOARD_0000101") % (
                    raw_tables[0], statid_rawdn, resource_info_query, head_for_popup, value_for_popup, query_string_for_stat_popup)
                    objs_for_stats_popup = utility.execute_raw_query(sql_query_for_popup_stats_data)

                    for data in objs_for_stats_popup:
                        data.update({'avg': round(data.get('avg', None), 2)})
                        data.update({'avg': formatValue(data.get('avg', None), unit)})

                    table_data['popUpDataStats'] = objs_for_stats_popup
                    table_data['head'] = data_source.get('param', {}).get('head', '')
                    table_data['value'] = value_for_popup
                    table_data['statName'] = statid_rawdn_name
                    table_data['nameValueMappingStats'] = name_value_mapping_stats
                    table_data['rawHtmlDataMappingStats'] = raw_html_data_mapping_stats
                    table_data['newTableHeaderStats'] = new_table_header_stats
                    ret['tableData'] = table_data

            return ret

        except Exception, err:
            print_traceback()
            logger.error("Error in get_res_status_drill_down_info function of ResourceDataSource:%s (%s)" % (
            err.message, type(err)))
            return {}

    def get_configured_dashboard(self, request, username):
        try:
            function_start_time = time.time()
            logger.info("Enter into get_configured_dashboard function of UserController.")

            # Filtering dashboard configured for the user or group
            filtered_dashboard = []
            filtered_dashboard_name_id_info = []
            result_data = Dashboard.objects.filter(is_deleted=False).all()
            # print "result_data: ", result_data
            serializer = DashboardListSerializer(result_data, many=True)
            all_dashboard_obj = serializer.data
            everest_user_name = ""
            everest_group_name = ""
            # print "all_dashboard_obj: ", all_dashboard_obj
            # User Filter
            # print "username: ", username
            try:
                everest_user_obj = Accounts.objects.get(name=username, isdeleted=False)
            except:
                logger.error("Error in getting everest user information")
                # print("Error in getting everest user information")
                everest_user_obj = None

            # print "everest_user_obj: ", everest_user_obj, everest_user_obj.accountid
            if everest_user_obj not in [None, "", [], "None"]:
                # print "222222222"
                # everest_user_id = everest_user_obj.accountid
                everest_user_name = everest_user_obj.name
                # print "everest_user_name: ", everest_user_name
                # print "all_dashboard_obj: ", all_dashboard_obj
                for dashboard_obj in all_dashboard_obj:
                    # print "dashboard_obj: ", dashboard_obj, dashboard_obj.get("users", "uuu")
                    dashboard_users = dashboard_obj.get("users", "").split(",")
                    dashboard_users_list = [str(u.strip()) for u in dashboard_users]
                    # print "dashboard_users_list: ", dashboard_users_list
                    if everest_user_name in dashboard_users_list and everest_user_name != 'administrator':
                        filtered_dashboard.append(dashboard_obj)
                        dashboard_id = dashboard_obj.get("id", "")
                        dashboard_name = dashboard_obj.get("name", "")
                        filtered_dashboard_name_id_info.append(dict(identity=dashboard_id, name=dashboard_name))

                    if everest_user_name == 'administrator':
                        filtered_dashboard.append(dashboard_obj)
                        dashboard_id = dashboard_obj.get("id", "")
                        dashboard_name = dashboard_obj.get("name", "")
                        filtered_dashboard_name_id_info.append(dict(identity=dashboard_id, name=dashboard_name))
            # print "filtered_dashboard: ", filtered_dashboard

            # Group Filter
            if everest_user_obj not in [None, "", [], "None"]:
                group_id = everest_user_obj.groupid
                # print "group_id: ", group_id
                try:
                    everest_group_obj = Groups.objects.get(groupid=group_id, isdeleted=False)
                except:
                    logger.error("Error in getting everest group information")
                    # print("Error in getting everest group information")
                    everest_group_obj = None
                # print "everest_group_obj: ", everest_group_obj
                if everest_group_obj:
                    everest_group_name = everest_group_obj.name
                    # print "everest_group_name: ", everest_group_name
                    for dashboard_obj in all_dashboard_obj:
                        # print "dashboard_obj: ", dashboard_obj, dashboard_obj.get("groups", "uuu")
                        dashboard_group = dashboard_obj.get("groups", "").split(",")
                        dashboard_group_list = [str(u.strip()) for u in dashboard_group]
                        # print "dashboard_group_list: ", dashboard_group_list
                        if everest_group_name in dashboard_group_list:
                            # Check if dashboard is already in the list. If dashboard is not in list then only add it.
                            if dashboard_obj not in filtered_dashboard:
                                filtered_dashboard.append(dashboard_obj)
                                dashboard_id = dashboard_obj.get("id", "")
                                dashboard_name = dashboard_obj.get("name", "")
                                filtered_dashboard_name_id_info.append(dict(identity=dashboard_id, name=dashboard_name))
            # print "filtered_dashboard: ", filtered_dashboard

            # print("Overall time taken by get_configured_dashboard function to complete: %f" %
            #       (time.time() - function_start_time))
            logger.debug("Overall time taken by get_configured_dashboard function to complete: %f" %
                         (time.time() - function_start_time))
            logger.info("Exiting get_configured_dashboard function of UserController.")
            return filtered_dashboard, filtered_dashboard_name_id_info, everest_user_name, everest_group_name
        except Exception, err:
            logger.error("Error in get_configured_dashboard function of UserController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_configured_dashboard function of UserController:%s (%s)" % (err.message, type(err)))
            return [], "", ""

    def get_user_configured_dashboards(self, request, user_name):
        try:
            function_start_time = time.time()
            logger.debug("Enter into get_user_configured_dashboards function of DashboardController.")
            # print "user_name: ", user_name

            filtered_dashboard, filtered_dashboard_name_id_info, everest_user_name, everest_group_name = \
                self.get_configured_dashboard(request, user_name)

            # print "filtered_dashboard: ", filtered_dashboard
            # print "filtered_dashboard_name_id_info: ", filtered_dashboard_name_id_info
            # print "everest_user_name: ", everest_user_name
            # print "everest_group_name: ", everest_group_name

            logger.debug("Overall time taken by get_user_configured_dashboards function to complete: %f" %
                         (time.time() - function_start_time))
            logger.debug("Exiting get_user_configured_dashboards function of DashboardController.")
            return filtered_dashboard_name_id_info
        except Exception, err:
            logger.error("Error in get_user_configured_dashboards function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_user_configured_dashboards function of DashboardController:%s (%s)" % (err.message, type(err)))
            return []

    def save_upload_image(self, request):
        """
        Function to saves upload image
        :param request: object received on web server.
        :return: status of action.
        """
        try:
            function_start_time = time.time()
            logger.debug("Enter into save_upload_image function of DashboardController.")
            # print "request in save_upload_image_data of dashboard: ", request
            # print "request in save_upload_image_data of dashboard: ", request.POST
            # files = request.POST.get("file", [])
            # print "files: ", type(files), files
            #
            data = self.get_post_data(request)
            # print "data: ", data

            upload_file_info = data.get("files", {})
            file_name = upload_file_info.get("name", "")
            file_binary = upload_file_info.get("binaryData", "")

            if file_binary != self.noneList:
                upload_image_encoded_string = file_binary.split('base64,')[1]
                profile_path = settings.MEDIA_PATH + os.sep + "apps" + os.sep + "components" + os.sep + "dashboard" + \
                               os.sep + "images" + os.sep + "uploads"
                # Checking if the path exists, if not then create the folder required.
                if not os.path.isdir(profile_path):
                    os.makedirs(profile_path)
                file_path = profile_path + os.sep + file_name
                file_ptr = open(file_path, "wb")
                file_ptr.write(upload_image_encoded_string.decode('base64'))
                file_ptr.close()

            logger.debug("Overall time taken by save_upload_image function to complete: %f" %
                         (time.time() - function_start_time))
            logger.debug("Exiting save_upload_image function of DashboardController.")
            return self.get_return_object("success", data, "success", "id")
        except Exception, err:
            logger.error("Error in save_upload_image function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in save_upload_image function of DashboardController:%s (%s)" % (err.message, type(err)))
            return {}

    def get_upload_image(self, request):
        """
        Function to get upload image
        :param request: object received on web server.
        :return: status of action.
        """
        try:
            function_start_time = time.time()
            logger.debug("Enter into get_upload_image function of DashboardController.")
            # print "request in get_upload_image of dashboard: ", request
            # print "request in save_upload_image_data of dashboard: ", request.POST
            # files = request.POST.get("file", [])
            # print "files: ", type(files), files
            profile_path = settings.MEDIA_PATH + os.sep + "apps" + os.sep + "components" + os.sep + "dashboard" + \
                           os.sep + "images" + os.sep + "uploads"
            html_path = "/media/apps/components/dashboard/images/uploads/"
            files_list = []
            for root, dirs, files in os.walk(profile_path):
                for f in files:
                    files_list.append((html_path + f))
            # print "files_list: ", files_list

            logger.debug("Overall time taken by get_upload_image function to complete: %f" %
                         (time.time() - function_start_time))
            logger.debug("Exiting get_upload_image function of DashboardController.")
            return dict(files=files_list)
        except Exception, err:
            logger.error("Error in get_upload_image function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in get_upload_image function of DashboardController:%s (%s)" % (err.message, type(err)))
            return {}

    def check_for_existing_dashboard_info(self, request, dashboard_name):
        """
        Function to check if the dashboard name is already used
        :param request: object received on web server.
        :return: status of action.
        """
        try:
            function_start_time = time.time()
            logger.debug("Enter into check_for_existing_dashboard_info function of DashboardController.")
            # print "dashboard_name: ", dashboard_name
            name_exist = False
            try:
                dashboard_obj_query = database_query_instance.get("Q_DASHBOARD_0000114") % dashboard_name
                dashboard_obj = utility.execute_raw_query(dashboard_obj_query)
                if len(dashboard_obj) == 0:
                    name_exist = False
                else:
                    name_exist = True
                # dashboard_obj = Dashboard.objects.get(name=dashboard_name, isdeleted=False)
            except:
                logger.error("Error in getting dashboard information")
                # print("Error in getting everest group information")
                dashboard_obj = None
            logger.debug("Overall time taken by check_for_existing_dashboard_info function to complete: %f" %
                         (time.time() - function_start_time))
            logger.debug("Exiting check_for_existing_dashboard_info function of DashboardController.")
            return dict(nameExist=name_exist)
        except Exception, err:
            logger.error("Error in check_for_existing_dashboard_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            # print("Error in check_for_existing_dashboard_info function of DashboardController:%s (%s)" % (err.message, type(err)))
            return {}


    # def get_stat_data_info(self, request):
    #     try:
    #         print "request in get_stat_data_info", request
    #
    #         stat_name = "avail"  # ""v_latency"
    #
    #         # Code for getting the statid
    #         sql_stmt_stat = "select statid from tblStatMap where rawdn='%s';" % stat_name
    #         print("sql_stmt_stat: %s" % sql_stmt_stat)
    #         sql_stmt_stat_data = execute_raw_query(sql_stmt_stat)
    #         if sql_stmt_stat_data:
    #             stat_id = sql_stmt_stat_data[0].get("statid", None)
    #         print("stat_id : %s" % stat_id)
    #
    #         # Getting the time information from timescale
    #         timescale = 1
    #         resolution = TIME_SCALES_MAP.get(timescale)[3]
    #         print("resolution : %s" % resolution)
    #         lower_resolution = TIME_SCALES_MAP.get(timescale)[2]
    #         print("lower_resolution : %s" % lower_resolution)
    #
    #         timescale_str = TIME_SCALES_MAP.get(timescale)[1]()     # Call function to fetch time in string.
    #         print("timescale_str :", timescale_str)
    #         # print("111")
    #         timescale_int = ()
    #         if timescale_str:       # To get the time in integer format.
    #             start_time_int = time_str_to_int(timescale_str[0])
    #             end_time_int = time_str_to_int(timescale_str[1])
    #             timescale_int = (start_time_int, end_time_int)
    #
    #         print("timescale_int : ", timescale_int)
    #         print("timescale_str : ", timescale_str)
    #
    #         # Getting the table names from
    #         timescale_interval_type_map = dict(raw=1, hour=2, day=4, month=5, year=6)
    #         time_series_tables = []
    #         table_name = "tbl" + resolution     # Form the table name to be fetched.
    #         print("table_name: ", table_name)
    #         start_time = timescale_int[0]
    #         end_time = timescale_int[1]
    #         interval_type = timescale_interval_type_map.get(resolution, 1)
    #         # Fetch the tables based on the start time, end time and table name.
    #         time_series_tables = getTables(table_name, start_time, end_time, interval_type)
    #         print "time_series_tables: ", time_series_tables
    #         # Just harcading and taking the first table
    #         table_name = ""
    #         if time_series_tables:
    #             table_name = time_series_tables[0]
    #
    #         # Lets check the generic query now
    #         print "111"
    #         sql_stmt_generic = "select * from %s where statid=%s;" % (table_name, stat_id)
    #         print "sql_stmt_generic: ", sql_stmt_generic
    #
    #         # get all the data of the time series table
    #         time_series_tables_union_sql_query_list = []
    #         for tables in time_series_tables:
    #             time_series_sql_query = "select resid as t_resid, statid as t_statid, timestamp, avg from %s " \
    #                                     "where statid in (%s)" % (tables, stat_id)
    #             time_series_tables_union_sql_query_list.append(time_series_sql_query)
    #
    #         print "time_series_tables_union_sql_query_list: ", time_series_tables_union_sql_query_list
    #
    #         time_series_tables_union_sql_query = ""
    #         if time_series_tables_union_sql_query_list:
    #             time_series_tables_union_sql_query = " union ".join(time_series_tables_union_sql_query_list)
    #
    #         print "time_series_tables_union_sql_query: ", time_series_tables_union_sql_query
    #
    #         # get time series table data joined with ResConfig and NodeInfo
    #         time_series_res_node_sql_query = "select * from (%s) as pt left join tblResConfig as r on " \
    #                                          "pt.t_resid=r.resid and r.isdeleted=0 left join tblNodeInfo as n on" \
    #                                          " r.nodeid=n.nodeid and n.isdeleted=0" % time_series_tables_union_sql_query
    #
    #         print "time_series_res_node_sql_query: ", time_series_res_node_sql_query
    #
    #         # Group by implementations
    #         # 1st Implementation for resid
    #         group_by_sql_stmt = "select t_resid as resid, avg(avg) from (%s) as gt group by " \
    #                             "t_resid, t_statid order by t_resid;" % time_series_res_node_sql_query
    #
    #         # 2nd Implementation for timestamp
    #         group_by_sql_stmt = "select timestamp, avg(avg) from (%s) as gt group by " \
    #                             "timestamp, t_statid order by timestamp;" % time_series_res_node_sql_query
    #
    #         # 3rd Implementation for avg
    #         group_by_sql_stmt = "select count(t_resid) as count, avg(avg) from (%s) as gt group by " \
    #                             "avg, t_statid order by avg;" % time_series_res_node_sql_query
    #         print "group_by_sql_stmt: ", group_by_sql_stmt
    #
    #         return []
    #     except Exception, err:
    #         print("Error in get_stat_data_info function of DashboardController:%s (%s)" % (err.message, type(err)))
    #         return []
