"""

    File 		    : 	postgresql_queries_mapper
    App / Module    : 	
    Description     : 	
    Project Name    :   EverestIMSPortal
    Created by Roopesh on 10/18/2017
    Copyright (c) 2017 Everest IMS. All rights reserved.

"""
# Python file imports
# Django file imports
# Third party library file imports
# Module file imports

__author__ = 'Roopesh'

sql = dict(

    # Naming Standard: Q_<App Name in all Capitals separated by underscore>_<7 Digit number starting with 0000001>

    # *************************************************************************
    # Reserved Q000001 to Q001000 for Topology Queries
    # *************************************************************************

    Q000001="SELECT RC.resid, RC.nodeid, RC.pathid, RC.poller_id, RC.name, RC.poll_addr, RC.alias, RC.res_type, "
            "RC.description, RC.bw_configured, RC.mtu, RC.port_no, RC.params, RPI.alarm_count, RPI.severity FROM tblResconfig "
            "AS RC LEFT JOIN (select a.resid, max(t.severity) as severity, count(a.resid) as alarm_count from "
            "tblAlarms as a join tblThresholds as t on a.thresid=t.thresid and a.isdeleted=0 group by a.resid) "
            "AS RPI ON RC.resid=RPI.resid AND RC.resid in (%s) AND RC.isdeleted=0;",

    # Q000001="SELECT RC.resid, RC.nodeid, RC.pathid, RC.poller_id, RC.name, RC.poll_addr, RC.alias, RC.res_type, "
    #         "RC.description, RC.bw_configured, RC.mtu, RC.port_no, RPI.alarm_count, RPI.severity FROM tblResconfig "
    #         "AS RC JOIN tblRootPathInfo AS RPI ON RC.resid=RPI.resid AND RC.resid in (%s) AND RC.isdeleted=0;",

    Q000002="select t.*, nxy.x rx, nxy.y ry from (select distinct n.nodeid nd_id, n.*, r.poll_state, "
            "a.stat_dn, a.isdeleted as has_no_alarm from (select * from tblNodeInfo where isdeleted=0 "
            "and nodeid in (%s)) as n left join tblResConfig as r on r.resid=n.resid and n.isdeleted=0 "
            "left join tblAlarms as a on a.resid=n.resid and a.statid=n.statid) t left join "
            "tbltoponodexy nxy on t.nd_id = nxy.nodeid %s",


    # Q000002="select distinct n.nodeid, n.*, r.poll_state, a.stat_dn, a.isdeleted as has_no_alarm from "
    #        "(select * from tblNodeInfo where isdeleted=0 and nodeid in (%s)) as n left join tblResConfig as r "
    #        "on r.resid=n.resid and n.isdeleted=0 left join tblAlarms as a on a.resid=n.resid and a.statid=n.statid;",

    Q000004="SELECT restopid, nodeid1, nodeid2, resid1, resid2 FROM tblResTopology WHERE "
            "resid1 IN (%s) AND resid2 IN (%s) AND nodeid1!=nodeid2 and show_on_flatview=1 and isdeleted=0 and rel_type = %s;",

    Q000005="SELECT * FROM tblNodeInfo AS NI JOIN tblExtraNodeInfo AS ENI ON "
            "NI.nodeid=ENI.ex_nodeid AND NI.nodeid=%s AND NI.isdeleted=0;",

    Q000006="SELECT DISTINCT ON (rw.statid) rw.statid, rw.resid, rw.timestamp, avg FROM (%s) AS rw "
            "ORDER BY rw.statid, rw.resid, rw.timestamp DESC;",

    # Q000006="SELECT DISTINCT ON (rw.statid) rw.statid, rw.resid, rw.timestamp, avg FROM (%s) AS rw "
    #         "WHERE rw.statid IN (SELECT statid FROM tblStatMap WHERE rawdn IN (%s)) AND resid IN "
    #         "(SELECT resid FROM tblResConfig WHERE profile IN (%s) AND nodeid=%s) "
    #         "ORDER BY rw.statid, rw.resid, rw.timestamp DESC;",

    Q000007="SELECT resid1, resid2, nodeid1, nodeid2, distance FROM tblResTopology WHERE restopid=%s;",

    Q000008="SELECT r.resid, r.nodeid, r.pathid, r.name, r.poller_id, r.poll_addr, r.bw_configured, r.params, n.hostname "
            "FROM tblResConfig as r join tblNodeInfo as n on r.resid in (%s) and r.nodeid=n.nodeid;",

    Q000009="SELECT * FROM ((SELECT DISTINCT ON (rw.statid) rw.statid, rw.resid, rw.timestamp, avg FROM (%s) "
            "AS rw WHERE resid=%s AND statid IN (SELECT statid FROM tblStatMap WHERE rawdn IN (%s)) ORDER BY "
            "rw.statid, rw.timestamp DESC) UNION (SELECT DISTINCT ON (rw.statid) rw.statid, rw.resid, rw.timestamp, "
            "avg FROM (%s) AS rw WHERE resid=%s AND statid IN (SELECT statid FROM tblStatMap WHERE rawdn IN (%s)) "
            "ORDER BY rw.statid, rw.timestamp DESC)) AS st ORDER BY resid;",

    Q000010="SELECT DISTINCT ON (rw.statid) rw.statid, rw.resid, rw.timestamp, avg FROM (%s) AS rw "
            "ORDER BY rw.statid, rw.resid, rw.timestamp DESC;",

    # Q000010="SELECT DISTINCT ON (rw.statid) rw.statid, rw.resid, rw.timestamp, avg FROM (%s) AS rw "
    #         "WHERE resid IN (%s) AND statid IN (SELECT statid FROM tblStatMap WHERE rawdn IN (%s)) "
    #         "ORDER BY rw.statid, rw.resid, rw.timestamp DESC;",

    Q000011="select d.*, r.nodeid from "
            "(SELECT DISTINCT ON (rw.statid, rw.resid) rw.statid, rw.resid , rw.timestamp, avg FROM "
            "(%s) as rw ORDER BY rw.statid, rw.resid, rw.timestamp DESC) as d join tblResconfig as r on "
            "d.resid=r.resid order by d.resid, d.statid;",

    # Q000011="select d.*, r.nodeid from "
    #         "(SELECT DISTINCT ON (rw.statid, rw.resid) rw.statid, rw.resid , rw.timestamp, avg FROM "
    #         "(%s) as rw where rw.resid in "
    #         "(select resid from tblResConfig where nodeid in (%s) and name in (%s)) and rw.statid in "
    #         "(select statid from tblStatMap where rawdn in (%s) order by rawdn) "
    #         "ORDER BY rw.statid, rw.resid, rw.timestamp DESC) as d join tblResconfig as r on "
    #         "d.resid=r.resid order by d.resid, d.statid;",

    Q_Topology_0000012="select distinct ni.nodeid as nodeid from "
                       "(select n.nodeid from (select ni.*, nt.tag as nodetag from tblNodeInfo ni left join "
                       "tblnodetags as nt on ni.nodeid=nt.nodeid and ni.isdeleted=0) as n join tblExtraNodeInfo "
                       "as exn on n.nodeid=exn.ex_nodeid and n.isdeleted=0 join tblResConfig as r on r.nodeid=n.nodeid "
                       "and r.isdeleted=0 and r.profile not in ('syslog.cfg') %s %s ) as ni",   # Don't put semicolon at the end as it will be used as subquery

    Q_Topology_0000013="select distinct ni.resid as resid from "
                       "(select r.resid from (select ni.*, nt.tag as nodetag from tblNodeInfo ni left join "
                       "tblnodetags as nt on ni.nodeid=nt.nodeid and ni.isdeleted=0) as n join tblExtraNodeInfo "
                       "as exn on n.nodeid=exn.ex_nodeid and n.isdeleted=0 join tblResConfig as r on r.nodeid=n.nodeid "
                       "and r.isdeleted=0 and r.profile not in ('syslog.cfg') %s %s ) as ni",   # Don't put semicolon at the end as it will be used as subquery

    # *************************************************************************
    # Reserved Q001001 to Q101000 for Dashboard Queries
    # *************************************************************************
    # Q001001 to Q001010 reserved for specific dashboard related operations
    Q_DASHBOARD_0000001="SELECT * FROM tblStatMap WHERE rawdn IN (%s);",

    Q_DASHBOARD_0000002="select filterconfigs from tblfilter_config where name in (%s);",


    Q001007="SELECT DISTINCT ON (rw.resid) rw.resid, rw.statid, rw.timestamp, avg FROM (%s) AS rw WHERE statid=%s "
            "ORDER BY rw.resid, rw.statid, rw.timestamp DESC",  # Don't put semicolon at the end as it will be subquery.

    Q001008="select avg(avg) as avg, count(resid) as count from (select resid, statid, avg(avg) as avg from (%s) "
            "as rwt group by resid, statid) as raw_table where resid in (%s) group by statid;",

    Q001009="select avg, count(resid) as count from (%s) as raw_table where resid in (%s) group by avg;",

    Q001010="(select * from %s where statid=%s and timestamp between %s and %s)",

    Q001011="(select * from %s where statid in (%s) and timestamp between %s and %s)",

    Q001012="SELECT DISTINCT ON (rw.resid) rw.resid, rw.statid, rw.timestamp, avg FROM (%s) AS rw WHERE statid in (%s) "
            "ORDER BY rw.resid, rw.statid, rw.timestamp DESC",  # Don't put semicolon at the end as it will be subquery.

    Q001013="select avg(avg) as avg, count(nodeid) as count from (select ni.nodeid, raw_table.statid, raw_table.avg "
            "from tblNodeInfo as ni join (select resid, statid, avg(avg) as avg from (%s) as rwt group by resid, "
            "statid) as raw_table on ni.resid=raw_table.resid and ni.statid=raw_table.statid and ni.isdeleted=0 "
            "and nodeid in (%s) order by ni.nodeid) as agr;",

    Q001014="select res.resid, res.pathid, res.alias, res.nodeid, res.name, res.bw_configured, raw.statid, raw.avg "
            "from tblResConfig as res join (select resid, statid, avg(avg) as avg from (%s) as p group "
            "by resid, statid) as raw on res.resid=raw.resid and res.resid in (%s) %s;",

    # Q001015="select distinct r.resid as resid from tblnodeinfo as n join tblResconfig as r on n.isdeleted=0 "
    #         "and r.isdeleted=0 and n.nodeid=r.nodeid "
    #         "and r.profile in (SELECT unnest(string_to_array(profiles, ',')) "
    #         " as profile FROM tblstatprofilemap  where stat_name in ('Network "
    #         " Availability')) %s %s order by r.resid",

    Q001016="select nodeid, statid, resid from tblNodeInfo where isdeleted=0 order by nodeid;",

    Q001017="select avg(avg) as avg, count(nodeid) as count from (select ni.nodeid, raw_table.statid, raw_table.avg "
            "from tblNodeInfo as ni join (select resid, statid, avg(avg) as avg from (%s) as rwt group by resid, "
            "statid) as raw_table on ni.resid=raw_table.resid and ni.statid=raw_table.statid and ni.isdeleted=0 "
            "and nodeid in (%s) order by ni.nodeid) as agr group by avg;",

    Q001018="select avg(avg) as avg, timestamp from (%s) as dt where resid in (%s) group by timestamp;",

    # Q001019="select distinct r.resid as resid from tblnodeinfo as n join tblResconfig as r on n.isdeleted=0 "
    #         "and r.isdeleted=0 and n.nodeid=r.nodeid %s %s order by r.resid",

    Q001020="(select r.resid, n.state, n.city, n.location, n.hostname, rw.avg from %s "
            "as rw join tblResconfig as r on rw.resid=r.resid and rw.avg!=0.0 and rw.statid=%s "
            "and rw.timestamp between %s and %s and r.isdeleted=0 and "
            "r.profile in (SELECT unnest(string_to_array(profiles, ',')) as profile FROM " 
            " tblstatprofilemap where stat_name in ('Network Availability')) and r.resid in (%s) "
            "join tblNodeInfo as n on r.nodeid=n.nodeid order by rw.resid)",

    Q001021="select case when coalesce(trim(state),'') = ''then 'Other' else state end as state, "
            "sum(avg)/(60 * 60) as total_outage, count(resid) as count from "
            "(select sum(avg) as avg, resid, state from (%s) as tp group by resid, state) as t "
            "group by state order by total_outage desc limit %s;",

    Q001022="(select r.resid, hr.statid, hr.avg, hr.timestamp, n.nodeid, n.state, n.city, n.location, n.hostname "
            "from %s as hr join tblResconfig as r on  hr.resid=r.resid and hr.resid in (%s) and hr.timestamp "
            "between %s and %s and hr.avg !=100 join tblNodeInfo as n on r.nodeid=n.nodeid and "
            "hr.statid=n.statid order by resid)",

    Q001023="select case when coalesce(trim(state),'') = ''then 'Other' else state end as state, "
            "count(nodeid) as node_count, sum(sum_avg) as total_avg, sum(hour_count) as total_hrs, "
            "(sum(hour_count) * ((100 - (sum(sum_avg) / sum(hour_count))) / 100)) as total_min_down from "
            "(select nodeid, state, sum(avg) as sum_avg, count(nodeid) as hour_count from (%s) as t "
            "group by nodeid, state) as k group by state order by total_min_down desc limit %s;",

    Q001024="select * from %s where timestamp between %s and %s",

    Q_DASHBOARD_0000024="select count(case when poll_state = 0 then 1 end) as disabled, count(case when "
                        "a.isdeleted = 0 and poll_state = 1 then 1 end) as down_count from tblnodeinfo n,  "
                        "tblresconfig r, tblalarms a where n.nodeid =  a.nodeid and r.resid = a.resid and r.resid in "
                        "(%s)  and a.statid = %s and r.profile in (SELECT unnest(string_to_array(profiles, ',')) as "
                        "profile FROM tblstatprofilemap where stat_name in ('Network Availability'));",

    # Q_DASHBOARD_0000024="select count(thresid) as down_count from tblAlarms where resid in "
    #                     "(select resid from tblResConfig where resid in (%s) and poll_state=1 and isdeleted=0) "
    #                     "and statid=%s and isdeleted=0;",
    #
    Q_DASHBOARD_0000025="select count(*) as down_count from (select * from (select n.nodeid as nd_id, "
                        "n.resid as res_id, n.statid from tblnodeinfo n left join tblresconfig r on "
                        "r.resid=n.resid and r.poll_state!=0 and r.isdeleted =0 where n.isdeleted =0) "
                        "t1 left join (select distinct nodeid, isdeleted as status, statid from "
                        "tblalarms where thresid in (select thresid from tblthresholds) and isdeleted "
                        "= 0) as t2 on t2.nodeid=t1.nd_id and t1.statid=t2.statid where t1.nd_id in "
                        "(%s) order by t1.nd_id) ft where status = 0;",

    # Q_DASHBOARD_0000025="select count(thresid) as down_count from tblAlarms as a join tblNodeInfo as n on "
    #                     "a.nodeid=n.nodeid and a.resid=n.resid and a.statid=n.statid and n.isdeleted=0 and "
    #                     "a.isdeleted=0 join tblResConfig as r on n.resid=r.resid and r.poll_state=1 and "
    #                     "n.nodeid in (%s);",
    #
    Q_DASHBOARD_0000026="select distinct n.nodeid as nodeIdentity from tblnodeinfo as n, "
                        "tblResconfig as r, tblextranodeinfo exn %s and n.nodeid=r.nodeid and "
                        "n.nodeid=exn.ex_nodeid and n.nodeid in (select distinct n.nodeid as nodeIdentity "
                        "from tblnodeinfo as n, tblResconfig as r, tblextranodeinfo exn where %s and "
                        "n.nodeid=r.nodeid and n.nodeid=exn.ex_nodeid) order by n.nodeid",

    Q_DASHBOARD_0000027="select distinct n.nodeid as nodeIdentity, n.nodeid, n.statid from tblnodeinfo as n, "
                        "tblResconfig as r, tblextranodeinfo exn %s and n.nodeid=r.nodeid and "
                        "n.nodeid=exn.ex_nodeid and n.nodeid in (select distinct n.nodeid as nodeIdentity "
                        "from tblnodeinfo as n, tblResconfig as r, tblextranodeinfo exn where %s and "
                        "n.nodeid=r.nodeid and n.nodeid=exn.ex_nodeid) order by n.nodeid",

    Q_DASHBOARD_0000028="select distinct r.resid as resid from tblnodeinfo as n, tblResconfig as r, tblextranodeinfo exn "
                        "%s and n.nodeid=r.nodeid and n.nodeid=exn.ex_nodeid and r.resid in "
                        "(select distinct r.resid as resid from tblnodeinfo as n, tblResconfig as r, "
                        "tblextranodeinfo exn where %s and n.nodeid=r.nodeid and n.nodeid=exn.ex_nodeid)"
                        "and r.profile in (SELECT unnest(string_to_array(profiles, ',')) as profile " 
                        " FROM tblstatprofilemap  where stat_name in ('Network Availability')) order by r.resid",

    Q_DASHBOARD_0000029="select distinct r.resid as resid from tblnodeinfo as n, tblResconfig as r, tblextranodeinfo exn %s "
                        "and n.nodeid=r.nodeid and n.nodeid=exn.ex_nodeid and r.resid in "
                        "(select distinct r.resid as resid from tblnodeinfo as n, tblResconfig as r, "
                        "tblextranodeinfo exn where %s and n.nodeid=r.nodeid and n.nodeid=exn.ex_nodeid) "
                        "order by r.resid",
    # Taking disabled nodes as down nodes
    # Q_DASHBOARD_0000030 = "select %s as name, count(%s) as total_devices, count(CASE WHEN is_device_up = 0 THEN  1 END) as total_device_down, count(CASE WHEN poll_state = 0 THEN  1 END) as total_device_disabled from (select n.nodeid, n.resid, n.technology, n.customer,  n.region, n.state, n.city, n.location, a.isdeleted as is_device_up, r.poll_state as poll_state from tblNodeInfo n, tblAlarms a, tblresconfig r where r.resid=n.resid and a.nodeid=n.nodeid and a.resid=n.resid and a.statid=n.statid and n.isdeleted=0 and n.nodeid in (%s)) as t group by %s",

    Q_DASHBOARD_0000030="select %s as name, count(%s) as total_devices, count(CASE WHEN is_device_up  = 0 THEN  1 END) " 
                        " as total_device_down from (select n.alias, n.nodeid, n.resid,  n.technology, n.customer,  n.region, " 
                        " n.state, n.city, n.location, a.isdeleted  as is_device_up from tblNodeInfo n, tblAlarms a, " 
                        " tblresconfig r where r.poll_state = 1 and r.resid=n.resid and a.nodeid=n.nodeid and " 
                        " a.resid=n.resid  and a.statid=n.statid and n.isdeleted=0 and n.nodeid in (%s)) as t group " 
                        " by %s order by %s",

    Q_DASHBOARD_0000031="select %s as name, count(%s) as total_devices, count(CASE WHEN is_device_up = 0 THEN"
                        " 1 END) as total_device_down %s from (select n.nodeid, n.resid, n.technology, n.customer, " 
                        " n.region, n.alias, n.state, n.city, n.location, case when coalesce(trim(n.hostname), '') = "
                        "  '' then n.poll_addr else n.hostname " 
                        " end as hostname, a.isdeleted as is_device_up from tblNodeInfo " 
                        " n, tblAlarms a, tblresconfig r where r.poll_state=1 and r.resid=n.resid and a.nodeid=n.nodeid and a.resid=n.resid and " 
                        " a.statid=n.statid and n.isdeleted=0 and n.nodeid in (%s)) as t %s group by %s %s order by %s",

    Q_DASHBOARD_0000032="select value from tblimsconfig where key = 'NAVIGATION_TREE_LEVELS';",

    Q_DASHBOARD_0000033=" select * from (SELECT *, CASE WHEN coalesce(TRIM(display_name), " 
                        " '') = '' THEN actual_name ELSE display_name END as name_to_display FROM " 
                        " tblNodeSchema) as tbl1 where attr in (%s)",

    Q_DASHBOARD_0000034="select %s as name, count(%s) as total_links, count(CASE WHEN is_link_up = 0 " 
                        " THEN 1 END) as total_link_down from (select n.*, " 
                        " t1.is_link_up from " 
                        " tblnodeinfo n,(select r.poll_state,a.isdeleted as  is_link_up, r.nodeid, " 
                        " r.resid from tblResconfig r, tblAlarms a where r.resid=a.resid  and a.statid " 
                        " in (select statid from tblStatMap where rawdn='n_avail') and r.isdeleted=0  and " 
                        " r.profile in (%s) and r.resid in (%s) order by r.resid) t1 where " 
                        " t1.poll_state=1 and n.nodeid=t1.nodeid) t2 group by %s order by %s",

    Q_DASHBOARD_0000035="select %s as name, count(%s) as total_links, count(CASE WHEN is_link_up = 0 " 
                        " THEN 1 END) as total_link_down %s from (select " 
                        " n.nodeid, n.alias, n.make, n.model, n.device_type, n.country, n.region, n.state, "
                        "n.city, n.location, n.technology, n.customer, case when coalesce(trim(n.hostname), '') " 
                        " = '' then n.poll_addr else n.hostname " 
                         " end as hostname, t1.is_link_up from tblnodeinfo n, (select " 
                        " r.poll_state, a.isdeleted as  is_link_up, r.nodeid, r.resid from tblResconfig r, " 
                        " tblAlarms a where r.resid=a.resid and a.statid in (select statid from tblStatMap " 
                        " where rawdn='n_avail') and  r.isdeleted = 0 and r.profile in (%s) and r.resid " 
                        " in (%s) order by r.resid) t1 where t1.poll_state=1 and n.nodeid=t1.nodeid) t2 " 
                        " %s group by %s %s order by %s",

    Q_DASHBOARD_0000036= "select %s case when coalesce(trim(n.hostname), '') = '' then n.poll_addr else n.hostname " 
                         " end as name, case when coalesce(poll_state) = 0 then -1 else a.isdeleted end as " 
                         " is_device_up, n.alias, n.nodeid from tblNodeInfo n, tblAlarms a, tblextranodeinfo en, tblresconfig r "
                         " where r.resid=n.resid and a.nodeid=n.nodeid and a.nodeid=en.ex_nodeid " 
                         " and  a.resid=n.resid and a.statid=n.statid and n.isdeleted=0 and n.nodeid in (%s) order by name",

    Q_DASHBOARD_0000037="select attr as value, name_to_display as display_name from (SELECT *, CASE WHEN coalesce(TRIM(display_name), " 
                        " '') = '' THEN actual_name ELSE display_name END as name_to_display FROM " 
                        " tblNodeSchema) as tb1 where table_name in ('tblextranodeinfo','tblnodeinfo') " 
                        " and attr not in ('hostname','alias') order by attr",

    Q_DASHBOARD_0000038 = "select attr as value, name_to_display as display_name, type from (SELECT *, CASE WHEN " 
                          " coalesce(TRIM(display_name), '') = '' THEN actual_name ELSE display_name END as " 
                          " name_to_display FROM tblNodeSchema) as tb1 where table_name in ('tblextranodeinfo'," 
                          " 'tblnodeinfo') and attr in (%s) order by attr",

    Q_DASHBOARD_0000039 = "select attr as value, name_to_display as display_name from (SELECT *, CASE WHEN " 
                          " coalesce(TRIM(display_name), '') = '' THEN actual_name ELSE display_name END as " 
                          " name_to_display FROM tblNodeSchema) as tb1 where attr in (%s) order by %s ",

    Q_DASHBOARD_0000040 = "select attr as value, name_to_display as display_name from (SELECT *, CASE WHEN coalesce(TRIM(display_name), " 
                          " '') = '' THEN actual_name ELSE display_name END as name_to_display FROM " 
                          " tblNodeSchema) as tb1 where attr in ('res_type','bw_configured','ip_addr','alias')" 
                          " and table_name = 'tblresconfig';",

    Q_DASHBOARD_0000041 = " select attr as value, name_to_display as display_name from (SELECT *, CASE WHEN coalesce(TRIM(display_name), "
                          "  '') = '' THEN actual_name ELSE display_name END as name_to_display FROM "
                          " tblNodeSchema) as tb1 where table_name = 'tblextraresinfo' ",

    Q_DASHBOARD_0000042 = "select %s r.name as name ,case when coalesce(poll_state) = 0 then -1 else a.isdeleted end as is_link_up, r.resid from tblResconfig r, "
                          " tblAlarms a, tblextraresinfo er where er.ex_resid=a.resid and r.resid=a.resid  and a.statid  in (select statid from tblStatMap where rawdn='n_avail') " 
                          " and r.isdeleted=0  and  r.profile in (%s) and r.resid in (%s) order by r.resid",

    Q_DASHBOARD_0000043 = " select attr as value, name_to_display as display_name, type from (SELECT *, CASE WHEN " 
                          " coalesce(TRIM(display_name), '') = '' THEN actual_name ELSE display_name END as "
                          " name_to_display FROM tblNodeSchema) as tb1 where table_name in ('tblextraresinfo', "
                          " 'tblresconfig') and attr in (%s) order by attr ",

    Q_DASHBOARD_0000044=" select t1.*, n.alias, n.hostname from tblnodeinfo n,(select a.isdeleted as status, r.*, r.nodeid res_nodeid from tblResconfig r, " 
                        " tblAlarms a where r.poll_state!=0 and r.resid=a.resid  and a.statid " 
                        " in (select statid from tblStatMap where rawdn='n_avail') and r.isdeleted=0 and r.profile " 
                        " in (%s) and r.resid in (%s) order by r.resid) t1 %s and n.nodeid=t1.res_nodeid and %s = '%s' " 
                        " order by status;",

    Q_DASHBOARD_0000045=" select a.isdeleted as status, n.alias, n.* from tblNodeInfo  n, tblAlarms a, tblresconfig r where %s " 
                        " r.poll_state!=0 and r.resid=n.resid and a.nodeid=n.nodeid and " 
                        " a.resid=n.resid and  a.statid=n.statid and n.isdeleted=0 and n.nodeid in (%s) and " 
                        " %s = '%s' order by status;",

    Q_DASHBOARD_0000046 = "select statid, rawdn, name, unit from tblstatmap where rawdn in (%s);",

    Q_DASHBOARD_0000047 = "select r.resid from tblResconfig r, tblAlarms a where r.resid=a.resid and a.statid " 
                          " in (select statid from tblStatMap where rawdn='n_avail') and r.isdeleted=0 and " 
                          " r.profile in (SELECT unnest(string_to_array(profiles, ',')) as profile FROM " 
                          " tblstatprofilemap  where stat_name in ('Network Availability')) " 
                          " and r.nodeid in (%s) order by r.resid ",

    Q_DASHBOARD_0000048 = "select * from (select %s r.resid as resconfig_resid, r.name as name ,case when coalesce(poll_state) = 0 " 
                          " then -1 else a.isdeleted end as is_link_up, r.resid from tblResconfig r, tblAlarms a, tblextraresinfo "
                          " er where er.ex_resid=a.resid and r.resid=a.resid  and a.statid  in (select statid from " 
                          " tblStatMap where rawdn='n_avail')  and r.isdeleted=0  and  r.profile in (%s)  and r.resid in " 
                          " (%s) order by r.resid) as t1 left join (SELECT DISTINCT ON (rw.resid, rw.statid) rw.resid, " 
                          " rw.statid, rw.timestamp, avg FROM %s AS rw WHERE statid in (%s) ORDER BY rw.resid, rw.statid, " 
                          " rw.timestamp DESC) as t2 on t1.resconfig_resid=t2.resid;",

    # Q_DASHBOARD_0000049 = "select rawdn, name, statid, unit from tblstatmap where rawdn in (%s)",

    Q_DASHBOARD_0000050 = "select device_type_inventory, count(device_type_inventory) no_of_devices from (select *, " 
                          " case when coalesce(trim(device_type), '') = '' then 'Unknown' else device_type end " 
                          " as device_type_inventory from tblnodeinfo) n where n.nodeid in (%s) group " 
                          " by device_type_inventory order by device_type_inventory",

    Q_DASHBOARD_0000051 = "select * from (select a.isdeleted as status, case when coalesce(trim(n.device_type), '') " 
                          " = '' then 'Unknown' else n.device_type end as device_type_inventory, n.* from tblNodeInfo " 
                          " n, tblAlarms a, tblresconfig r where r.poll_state!=0 and r.resid=n.resid and " 
                          " a.nodeid=n.nodeid and  a.resid=n.resid and  a.statid=n.statid and n.isdeleted=0 " 
                          " and n.nodeid in (%s) order by status) t where  %s = '%s';",

    Q_DASHBOARD_0000052=" select t1.*, n.alias, n.hostname from tblnodeinfo n,(select a.isdeleted as status, r.*, r.nodeid res_nodeid from tblResconfig r, " 
                        " tblAlarms a where r.poll_state!=0 and r.resid=a.resid  and a.statid " 
                        " in (select statid from tblStatMap where rawdn='n_avail') and r.isdeleted=0 and r.profile " 
                        " in (%s) and r.resid in (%s) order by r.resid) t1 where n.nodeid=t1.res_nodeid and %s = '%s' " 
                        " order by status;",

    Q_DASHBOARD_0000053 = "select make_inventory, count(make_inventory) no_of_devices from (select *, case when " 
                          " coalesce(trim(make), '') = '' then 'Unknown' else make end as make_inventory from " 
                          " tblnodeinfo) n where n.nodeid in (%s) group by make_inventory",

    Q_DASHBOARD_0000054=" select a.isdeleted as status, n.alias, n.* from tblNodeInfo  n, tblAlarms a, tblresconfig r %s and %s"
                        " r.poll_state!=0 and r.resid=n.resid and a.nodeid=n.nodeid and "
                        " a.resid=n.resid and  a.statid=n.statid and n.isdeleted=0 and n.nodeid in (%s) and "
                        " %s = '%s' order by status;",

    Q_DASHBOARD_0000055=" select %s r.name, n.hostname, r.alias, n.device_type, n.location, a.timestamp downtime, n.nodeid, r.resid from tblResconfig r, "
                        " tblAlarms a, tblextraresinfo er, tblextranodeinfo en, tblnodeinfo n where a.isdeleted = 0 and" 
                        " n.nodeid=r.nodeid and en.ex_nodeid=r.nodeid and er.ex_resid=a.resid and r.resid=a.resid " 
                        " and a.statid in (select statid from tblStatMap where rawdn='n_avail') and r.isdeleted=0 " 
                        " and r.profile in (%s)  and r.resid in (%s) order by a.timestamp %s %s",

    Q_DASHBOARD_0000056="select attr as value, name_to_display as display_name, type from (SELECT *, CASE WHEN "
                        " coalesce(TRIM(display_name), '') = '' THEN actual_name ELSE display_name END as "
                        " name_to_display FROM tblNodeSchema) as tb1 where type not in ('nodetag',"
                        " 'devicegroup') and attr in (%s) order by attr",

    Q_DASHBOARD_0000057="select attr as value, name_to_display as display_name from (SELECT *, CASE WHEN coalesce(TRIM(display_name), "
                        " '') = '' THEN actual_name ELSE display_name END as name_to_display FROM "
                        " tblNodeSchema) as tb1 where type not in ('devicegroup','nodetag') "
                        " and attr not in ('hostname','name','devicetype','location','alias') order by attr",

    Q_DASHBOARD_0000058="select * from (select a.isdeleted as status, case when coalesce(trim(n.make), '') " 
                          " = '' then 'Unknown' else n.make end as make_inventory, n.* from tblNodeInfo " 
                          " n, tblAlarms a, tblresconfig r where r.poll_state!=0 and r.resid=n.resid and " 
                          " a.nodeid=n.nodeid and  a.resid=n.resid and  a.statid=n.statid and n.isdeleted=0 " 
                          " and n.nodeid in (%s) order by status) t where  %s = '%s';",

    Q_DASHBOARD_0000059=" select t1.%s as name, t2.statid, avg(t2.avg) %s from (select r.resid as resconfig_resid, " 
                        " n.nodeid, n.alias, n.resid, n.technology, n.customer,  n.region, n.state, n.city, n.location, " 
                        " case when coalesce(trim(n.hostname), '') =   '' then n.poll_addr else n.hostname  " 
                        " end as hostname " 
                        " from tblResconfig r, tblAlarms a, tblextraresinfo er, tblnodeinfo n, tblextranodeinfo " 
                        " en where n.nodeid=a.nodeid and en.ex_nodeid = a.nodeid and er.ex_resid=a.resid and " 
                        " r.resid=a.resid " 
                        " and r.isdeleted=0 and r.resid in (%s) order by r.resid) as t1 " 
                        " join (SELECT DISTINCT ON (rw.resid, rw.statid) rw.resid, rw.statid, rw.timestamp, " 
                        " avg FROM %s AS rw WHERE statid in (%s) ORDER BY rw.resid, rw.statid, rw.timestamp DESC) " 
                        " as t2 on t1.resconfig_resid=t2.resid %s group by t1.%s ,t2.statid %s order by t1.%s;",

    Q_DASHBOARD_0000060=" select t1.device_type_inventory, t2.statid, avg(t2.avg) from (select r.resid as " 
                        " resconfig_resid, n.alias, n.*, case when coalesce(trim(n.device_type), '') = '' then 'Unknown' " 
                        " else n.device_type end as device_type_inventory from tblResconfig r, tblAlarms a, " 
                        " tblextraresinfo er, tblnodeinfo n, tblextranodeinfo en where n.nodeid=a.nodeid and " 
                        " en.ex_nodeid = a.nodeid and er.ex_resid=a.resid and r.resid=a.resid and " 
                        " r.isdeleted=0 " 
                        " and r.resid in (%s) order by r.resid) as t1 join (SELECT DISTINCT ON (rw.resid, " 
                        " rw.statid) rw.resid, rw.statid, rw.timestamp, avg FROM %s AS rw WHERE statid in (%s) " 
                        " ORDER BY rw.resid, rw.statid, rw.timestamp DESC) as t2 on t1.resconfig_resid=t2.resid " 
                        " group by t1.device_type_inventory ,t2.statid order by t1.device_type_inventory;",

    Q_DASHBOARD_0000061=" select t1.make_inventory, t2.statid, avg(t2.avg) from (select r.resid as " 
                        " resconfig_resid, n.alias, n.*, case when coalesce(trim(n.make), '') = '' then 'Unknown' " 
                        " else n.make end as make_inventory from tblResconfig r, tblAlarms a, " 
                        " tblextraresinfo er, tblnodeinfo n, tblextranodeinfo en where n.nodeid=a.nodeid and " 
                        " en.ex_nodeid = a.nodeid and er.ex_resid=a.resid and r.resid=a.resid " 
                        " and r.isdeleted=0 " 
                        " and r.resid in (%s) order by r.resid) as t1 join (SELECT DISTINCT ON (rw.resid, " 
                        " rw.statid) rw.resid, rw.statid, rw.timestamp, avg FROM %s AS rw WHERE statid in (%s) " 
                        " ORDER BY rw.resid, rw.statid, rw.timestamp DESC) as t2 on t1.resconfig_resid=t2.resid " 
                        " group by t1.make_inventory ,t2.statid order by t1.make_inventory;",

    Q_DASHBOARD_0000062=" select t1.nodeid as nodeid, case when coalesce(trim(t1.hostname), '') = '' " 
                        " then t1.poll_addr else t1.hostname " 
                        " end as name, t2.statid, avg(t2.avg) from (select r.resid as resconfig_resid, n.alias, n.* from " 
                        " tblResconfig r, tblextraresinfo er, tblnodeinfo n, tblextranodeinfo en " 
                        " where n.nodeid=r.nodeid and en.ex_nodeid = n.nodeid and er.ex_resid=r.resid" 
                        " and r.isdeleted=0 and r.resid in (%s) order by r.resid) as t1 " 
                        " join (SELECT DISTINCT ON (rw.resid, rw.statid) rw.resid, rw.statid, rw.timestamp, avg " 
                        " FROM %s AS rw WHERE statid in (%s) ORDER BY rw.resid, rw.statid, rw.timestamp DESC) " 
                        " as t2 on t1.resconfig_resid=t2.resid where nodeid in (%s) group by name, nodeid, " 
                        " t2.statid order by name; ",

    Q_DASHBOARD_0000063=" select t1.%s as name, t2.statid, avg(t2.avg) %s from (select r.resid as resconfig_resid, n.alias, " 
                        " n.nodeid, n.alias, n.make, n.model, n.device_type, n.country, n.region, n.state, "
                        "n.city, n.location, n.technology, n.customer, " 
                        " case when coalesce(trim(n.hostname), '') =   '' then n.poll_addr else n.hostname  " 
                        " end as hostname "
                        " from tblResconfig r, tblAlarms a, tblextraresinfo er, tblnodeinfo n, tblextranodeinfo "
                        " en where n.nodeid=a.nodeid and en.ex_nodeid = a.nodeid and er.ex_resid=a.resid and "
                        " r.resid=a.resid  and a.statid  in (select statid from tblstatmap where rawdn = 'n_avail')"
                        " and r.isdeleted=0 and r.profile in (%s) and r.resid in (%s) order by r.resid) as t1 "
                        " join (SELECT DISTINCT ON (rw.resid, rw.statid) rw.resid, rw.statid, rw.timestamp, "
                        " avg FROM %s AS rw WHERE statid in (%s) ORDER BY rw.resid, rw.statid, rw.timestamp DESC) "
                        " as t2 on t1.resconfig_resid=t2.resid %s group by t1.%s ,t2.statid %s order by t1.%s;",

    Q_DASHBOARD_0000064="select attr as value, name_to_display as display_name, type from (SELECT *, CASE WHEN "
                        " coalesce(TRIM(display_name), '') = '' THEN actual_name ELSE display_name END as "
                        " name_to_display FROM tblNodeSchema) as tb1 where type not in ('nodetag',"
                        " 'devicegroup')",

    Q_DASHBOARD_0000065="select %s n.hostname, n.alias, n.poll_addr, n.device_type, n.location, a.timestamp downtime, n.nodeid, "
                        "r.resid from tblResconfig r, tblAlarms a, tblextraresinfo er, tblextranodeinfo en, "
                        "tblnodeinfo n where  n.nodeid=r.nodeid and n.resid=r.resid and en.ex_nodeid=r.nodeid "
                        "and er.ex_resid=a.resid and n.resid=a.resid and n.statid=a.statid and r.isdeleted=0 and "
                        "a.isdeleted=0 and r.nodeid in (%s) order by a.timestamp %s %s",

    # Q_DASHBOARD_0000070="select count(n.nodeid), a.isdeleted from (select nodeid, resid, statid, isdeleted from "
    #                     "tblNodeInfo where isdeleted=0 and nodeid in (%s)) as n left join tblAlarms as a on "
    #                     "n.resid=a.resid and n.statid=a.statid group by a.isdeleted;",

    Q_DASHBOARD_0000070=" select count(*) total_devices, count(CASE WHEN status = 0 THEN  1 END) as "
                        " total_device_down, count(CASE WHEN poll_state = 0 THEN  1 END) disabled_nodes "
                        " from (select * from (select n.nodeid as nd_id, n.resid as res_id, "
                        " case when r.poll_state IS NULL then 0 else r.poll_state end poll_state, n.statid from tblnodeinfo n left join tblresconfig r on "
                        " r.resid=n.resid and r.poll_state!=0 and r.isdeleted =0 where n.isdeleted =0) "
                        " t1 left join (select distinct nodeid, isdeleted as status, statid from "
                        " tblalarms where thresid in (select thresid from tblthresholds) and isdeleted = 0) "
                        " as t2 on t2.nodeid=t1.nd_id and t1.statid =t2.statid where t1.nd_id in (%s) order "
                        " by t1.nd_id) ft;",

    Q_DASHBOARD_0000071="select count(a.thresid), t.severity from tblAlarms as a join tblThresholds as t on "
                        "a.thresid=t.thresid and a.isdeleted=0 and a.resid in (%s) group by t.severity;",

    Q_DASHBOARD_0000072="select count(resid) from tblResConfig where poll_state=0 and resid in (%s) and isdeleted=0;",

    Q_DASHBOARD_0000073="select count(*) from tblNodeInfo as n join tblResConfig as r on n.resid=r.resid and "
                        "n.isdeleted=0 and r.poll_state=0 and n.nodeid in (%s);",

    Q_DASHBOARD_0000074="select count(a.resid) from (%s) as a where a.avg > %s;",

    Q_DASHBOARD_0000075="select * from (select * from (SELECT DISTINCT ON (rw.resid, rw.statid) rw.resid, rw.statid, "
                        "rw.timestamp, avg FROM %s AS rw WHERE statid in (%s) ORDER BY rw.resid, rw.statid, "
                        "rw.timestamp DESC) as t where resid in (%s)) as a join (select %s n.hostname as hostname, n.nodeid, r.resid, "
                        "r.name, r.poll_state from tblResConfig r, tblExtraResInfo exr, tblnodeinfo n where r.resid=exr.ex_resid and "
                        "r.isdeleted=0 and n.nodeid=r.nodeid and r.profile in (%s)) as b on a.resid=b.resid order by Avg %s nulls last %s;",

    Q_DASHBOARD_0000076="select * from (SELECT DISTINCT ON (rw.resid, rw.statid) rw.resid, rw.statid, rw.timestamp, "
                        "avg FROM %s AS rw  WHERE statid in (%s) ORDER BY rw.resid, rw.statid, "
                        "rw.timestamp DESC) as t where resid in (%s);",

    Q_DASHBOARD_0000077=" select %s n.nodeid, t.statid, t.avg, t.name from (select nodeid as rw_nodeid, statid, " 
                        " avg(avg), name from (select * from (SELECT DISTINCT ON (rw.resid, rw.statid) " 
                        " rw.resid, rw.statid, rw.timestamp, avg FROM %s AS rw WHERE statid in (%s) ORDER BY rw.resid, " 
                        " rw.statid, rw.timestamp DESC) as t where resid in (%s)) as a join (select r.resid, r.nodeid, " 
                        " n.hostname as name from tblResConfig as r join tblNodeInfo as n on r.nodeid=n.nodeid and " 
                        " r.isdeleted=0 join tblextraNodeInfo as en on n.nodeid=en.ex_nodeid) as b on a.resid=b.resid " 
                        " group by rw_nodeid, statid, name) t, tblnodeinfo n, tblextranodeinfo en where " 
                        " t.rw_nodeid=n.nodeid and t.rw_nodeid=en.ex_nodeid order by Avg %s nulls last %s;",

    Q_DASHBOARD_0000078="select %s n.hostname as hostname, r.name as name ,case when coalesce(poll_state) = 0 then null else a.isdeleted end as n_avail_val, " 
                        "r.resid, n.nodeid from tblResconfig r,  tblAlarms a, tblextraresinfo er, tblnodeinfo n where er.ex_resid=a.resid " 
                        "and r.resid=a.resid and n.nodeid=r.nodeid and a.statid  in (select statid from tblStatMap where rawdn='n_avail') " 
                        " and r.isdeleted=0  and  r.profile in (%s) and r.resid in (%s) order by n_avail_val %s nulls last %s ;",

    Q_DASHBOARD_0000079="select %s n.hostname as hostname, n.alias, r.name as name ,case when coalesce(poll_state) = 0 then null else a.isdeleted end as avg " 
                        ", r.resid from tblResconfig r, tblAlarms a, tblextraresinfo er, tblnodeinfo n where er.ex_resid=a.resid and " 
                        " r.resid=a.resid and n.nodeid=r.nodeid and a.statid in (select statid from tblStatMap where rawdn='n_avail') and " 
                        " r.isdeleted=0 and r.profile in (%s) and r.resid in (%s) and r.resid in (%s); ",

    Q_DASHBOARD_0000080=" select %s case when coalesce(trim(n.hostname), '') = '' then n.poll_addr else n.hostname end as " 
                        " name, n.alias, case when coalesce(poll_state) = 0 then null else a.isdeleted end as avail_val, " 
                        " n.nodeid from tblNodeInfo n, tblAlarms a, tblextranodeinfo en, tblresconfig r  where " 
                        " r.resid=n.resid and a.nodeid=n.nodeid and a.nodeid=en.ex_nodeid  and  a.resid=n.resid and " 
                        " a.statid=n.statid and n.isdeleted=0 and n.nodeid in (%s) order by avail_val %s nulls last %s;",

    Q_DASHBOARD_0000081="select %s n.hostname, r.name as name, r.resid, n.nodeid from tblResconfig r, tblAlarms a, tblextraresinfo " 
                        "er, tblnodeinfo n where n.nodeid=r.nodeid and er.ex_resid=a.resid and r.resid=a.resid " 
                        " and a.statid in (select statid from tblStatMap where rawdn='n_avail') and r.isdeleted=0 " 
                        " and r.profile in (%s) and r.resid in (%s) %s;",

    Q_DASHBOARD_0000082="select * from (select %s case when coalesce(trim(n.hostname), '') = '' then n.poll_addr else n.hostname " 
                        " end as name, n.alias, case when coalesce(poll_state) = 0 then null else a.isdeleted end as " 
                        " avg, n.nodeid from tblNodeInfo n, tblAlarms a, tblextranodeinfo en, tblresconfig " 
                        " r where r.resid=n.resid and a.nodeid=n.nodeid and a.nodeid=en.ex_nodeid and " 
                        " a.resid=n.resid and a.statid=n.statid and n.isdeleted=0 and n.nodeid in (%s)) " 
                        " t where nodeid in (%s);",
    Q_DASHBOARD_0000083="select %s case when coalesce(trim(n.hostname), '') = '' then n.poll_addr else n.hostname end as  " 
                        " name, n.alias, n.nodeid from tblNodeInfo n, tblAlarms a, tblextranodeinfo en, tblresconfig r  where  " 
                        " r.resid=n.resid and a.nodeid=n.nodeid and a.nodeid=en.ex_nodeid  and  a.resid=n.resid and  " 
                        " a.statid=n.statid and n.isdeleted=0 and n.nodeid in (%s) %s;",

    Q_DASHBOARD_0000084="select * from tblstatmap;",

    Q_DASHBOARD_0000085="select %s n.hostname, r.name as name, r.resid, n.nodeid from tblResconfig r, tblAlarms a, tblextraresinfo " 
                        "er, tblnodeinfo n where n.nodeid=r.nodeid and er.ex_resid=a.resid and r.resid=a.resid " 
                        " and r.isdeleted=0 and r.resid in (%s) %s;",

    Q_DASHBOARD_0000086="select %s n.hostname as hostname, r.name as name, case when coalesce(poll_state) = 0 then null else a.isdeleted end as av_val, "
                        "r.resid, n.nodeid from tblResconfig r,  tblAlarms a, tblextraresinfo er, tblnodeinfo n where %s er.ex_resid=a.resid "
                        "and r.resid=a.resid and n.nodeid=r.nodeid and r.isdeleted=0 and r.resid in (%s) order by " 
                        " av_val %s nulls last %s ;",

    Q_DASHBOARD_0000087="select * from (select * from (SELECT DISTINCT ON (rw.resid, rw.statid) rw.resid, rw.statid, "
                        "rw.timestamp, avg FROM %s AS rw WHERE statid in (%s) ORDER BY rw.resid, rw.statid, "
                        "rw.timestamp DESC) as t where resid in (%s)) as a join (select %s n.hostname as hostname, r.resid, n.nodeid, "
                        "r.name, n.alias, r.poll_state from tblResConfig r, tblExtraResInfo exr, tblnodeinfo n where r.resid=exr.ex_resid and "
                        "r.isdeleted=0 and n.nodeid=r.nodeid) as b on a.resid=b.resid order by Avg %s nulls last %s;",

    Q_DASHBOARD_0000088="select * from (select * from (SELECT DISTINCT ON (rw.resid, rw.statid) rw.resid, " 
                        " rw.statid, rw.timestamp, avg FROM %s AS rw WHERE statid in (%s) ORDER BY " 
                        " rw.resid, rw.statid, rw.timestamp DESC) as t where resid in (%s)) as a join " 
                        " (select r.name, r.res_type, n.hostname as hostname, n.poll_addr as " 
                        " poll_addr, r.resid as r_resid, r.alias, r.name, n.nodeid," 
                        " r.poll_state from tblResConfig r, tblExtraResInfo exr, tblnodeinfo n where " 
                        " r.resid=exr.ex_resid and r.isdeleted=0 and n.nodeid=r.nodeid) as b on " 
                        " a.resid=b.r_resid %s order by Avg Desc nulls last %s;",

    Q_DASHBOARD_0000089="select sum(count) from (select count(*) from (select * from (SELECT DISTINCT ON (rw.resid, rw.statid) rw.resid, " 
                        " rw.statid, rw.timestamp, avg FROM %s AS rw WHERE statid in (%s) ORDER BY " 
                        " rw.resid, rw.statid, rw.timestamp DESC) as t where resid in (%s)) as a join " 
                        " (select r.name, r.res_type, n.hostname as hostname, n.alias, n.poll_addr as poll_addr, r.resid, r.name, " 
                        " r.poll_state from tblResConfig r, tblExtraResInfo exr, tblnodeinfo n where " 
                        " r.resid=exr.ex_resid and r.isdeleted=0 and n.nodeid=r.nodeid) as b on " 
                        " a.resid=b.resid %s group by avg order by Avg Desc nulls last) as ft;",

    Q_DASHBOARD_0000090="select * from (select * from (SELECT rw.resid, rw.statid, "
                        "avg(avg) FROM %s AS rw WHERE statid in (%s) group BY rw.resid, rw.statid ORDER BY rw.resid, rw.statid "
                        "DESC) as t where resid in (%s)) as a join (select %s n.hostname as hostname, n.alias, r.resid, n.nodeid, "
                        "r.name, n.alias, r.poll_state from tblResConfig r, tblExtraResInfo exr, tblnodeinfo n where r.resid=exr.ex_resid and "
                        "r.isdeleted=0 and n.nodeid=r.nodeid) as b on a.resid=b.resid order by Avg %s nulls last %s;",

    Q_DASHBOARD_0000091="select * from (SELECT rw.resid, rw.statid, "
                        "avg(avg) FROM %s AS rw  WHERE statid in (%s) group BY rw.resid, rw.statid ORDER BY rw.resid, rw.statid "
                        "DESC) as t where resid in (%s);",

    Q_DASHBOARD_0000092="select * from (select * from (SELECT rw.resid, rw.statid, "
                        " avg(avg) FROM %s AS rw WHERE statid in (%s) group BY rw.resid, rw.statid ORDER BY rw.resid, rw.statid "
                        " DESC) as t where resid in (%s)) as a join (select %s n.hostname as hostname, n.alias, r.resid, n.nodeid, "
                        "r.name, r.poll_state from tblResConfig r, tblExtraResInfo exr, tblnodeinfo n where r.resid=exr.ex_resid and "
                        "r.isdeleted=0 and n.nodeid=r.nodeid and r.profile in (%s)) as b on a.resid=b.resid order by Avg %s nulls last %s;",

    Q_DASHBOARD_0000093=" select t1.nodeid as nodeid, case when coalesce(trim(t1.hostname), '') = '' " 
                        " then t1.poll_addr else t1.hostname " 
                        " end as name, t2.statid, avg(t2.avg) from (select r.resid as resconfig_resid, n.alias, n.* from " 
                        " tblResconfig r, tblextraresinfo er, tblnodeinfo n, tblextranodeinfo en " 
                        " where n.nodeid=r.nodeid and en.ex_nodeid = n.nodeid and er.ex_resid=r.resid" 
                        " and r.isdeleted=0 and r.resid in (%s) order by r.resid) as t1 " 
                        " join (SELECT rw.resid, rw.statid, avg(avg) " 
                        " FROM %s AS rw WHERE statid in (%s) group BY rw.resid, rw.statid ORDER BY rw.resid, rw.statid DESC) " 
                        " as t2 on t1.resconfig_resid=t2.resid where nodeid in (%s) group by name, nodeid, " 
                        " t2.statid order by name; ",

    Q_DASHBOARD_0000094=" select %s n.nodeid, t.statid, t.avg, t.name from (select nodeid as rw_nodeid, statid, " 
                        " avg(avg), name from (select * from (SELECT " 
                        " rw.resid, rw.statid, avg(avg) FROM %s AS rw WHERE statid in (%s) group by rw.resid, " 
                        " rw.statid ORDER BY rw.resid, " 
                        " rw.statid DESC) as t where resid in (%s)) as a join (select r.resid, n.alias, r.nodeid, " 
                        " n.hostname as name from tblResConfig as r join tblNodeInfo as n on r.nodeid=n.nodeid and " 
                        " r.isdeleted=0 join tblextraNodeInfo as en on n.nodeid=en.ex_nodeid) as b on a.resid=b.resid " 
                        " group by rw_nodeid, statid, name) t, tblnodeinfo n, tblextranodeinfo en where " 
                        " t.rw_nodeid=n.nodeid and t.rw_nodeid=en.ex_nodeid order by Avg %s nulls last %s;",

    Q_DASHBOARD_0000095=" select count(*) from tblresconfig where resid in (%s) and profile in (SELECT " 
                        " unnest(string_to_array(profiles, ',')) as profile FROM tblstatprofilemap " 
                        " where stat_name in (%s));",

    Q_DASHBOARD_0000096=" select count(*) from tblthresholds where thresid in (select thresid from " 
                        " tblalarms where isdeleted = 0 order by thresid) and resid in (%s) %s;",

    Q_DASHBOARD_0000097=" select severity, n.nodeid, n.alias, r.resid, r.name, timestamp as time, n.poll_addr as poll_addr, case when " 
                        " coalesce(trim(n.hostname), '') = '' then n.poll_addr else n.hostname " 
                        " end as hostname, n.alias, setmsg from tblthresholds th, tblresconfig " 
                        " r, tblnodeinfo n, tblalarms a where th.nodeid=n.nodeid and th.resid=r.resid " 
                        " and th.thresid=a.thresid and th.thresid in (select thresid as al_thresid " 
                        " from tblalarms where isdeleted = 0 order by thresid) %s " 
                        " and r.resid in (%s) order by timestamp desc %s;",

    Q_DASHBOARD_0000098=" select count(*) from %s as t where resid in (%s) %s",

    Q_DASHBOARD_0000099=" select severity, n.nodeid, r.resid, r.name, timestamp as time, n.poll_addr as poll_addr, " 
                        " case when  coalesce(trim(n.hostname), '') = '' then " 
                        " n.poll_addr else n.hostname  end as hostname, msg, n.alias from %s et, tblnodeinfo " 
                        " n, tblresconfig r where et.resid=r.resid and et.nodeid=n.nodeid and " 
                        " et.resid in (select distinct r.resid as resid from tblnodeinfo as n, " 
                        " tblResconfig as r, tblextranodeinfo exn where n.isdeleted=0 and " 
                        " r.isdeleted=0 and n.nodeid=r.nodeid and n.nodeid=exn.ex_nodeid and " 
                        " r.resid in (%s)) %s order by time desc %s;",

    Q_DASHBOARD_0000100=" select * from (SELECT DISTINCT ON (rw.resid) rw.resid, rw.statid, rw.timestamp, avg, " 
                        " r.res_type, r.name, n.nodeid, n.alias, n.poll_addr, case when " 
                        " coalesce(trim(n.hostname), '') = '' then n.poll_addr else n.hostname end " 
                        " as hostname FROM %s rw, tblnodeinfo n, tblresconfig r WHERE r.resid=rw.resid " 
                        " and n.nodeid=r.nodeid and rw.statid in (%s) and r.resid in (%s) " 
                        " and %s = '%s' ORDER BY rw.resid) as ft order by avg desc;",

    Q_DASHBOARD_0000101=" select * from (SELECT DISTINCT ON (rw.resid) rw.resid, rw.statid, rw.timestamp, avg, " 
                        " r.res_type, n.alias, r.name, n.nodeid, n.poll_addr, case when " 
                        " coalesce(trim(n.hostname), '') = '' then n.poll_addr else n.hostname end " 
                        " as hostname FROM %s rw, tblnodeinfo n, tblresconfig r WHERE r.resid=rw.resid " 
                        " and n.nodeid=r.nodeid and rw.statid in (%s) and r.resid in (%s) " 
                        " and %s = '%s' %s ORDER BY rw.resid) as ft order by avg desc;",

    Q_DASHBOARD_0000102="select ts as timestamp, count(ts) events_count, severity from (select timestamp " 
                        " ts, * from %s t where resid in (%s) %s order by ts) ft where severity != 0 group by ts, severity order" 
                        " by ts, severity;",

    Q_DASHBOARD_0000103=" select timescale as timestamp, count(timescale) events_count, severity from (select " 
                        " *, to_timestamp(timestamp) ts, case %s from %s t where resid in (%s) " 
                        " %s order by ts) ft where severity != 0 group by timescale, severity order by timescale, severity;",

    Q_DASHBOARD_0000104=" select ts as timestamp, count(ts) alarms_count, severity from (select " 
                        " timestamp ts, * from tblthresholds th, %s a where a.thresid=th.thresid and " 
                        " th.thresid in (select thresid from tblalarms where isdeleted = 0 order by " 
                        " thresid) and th.resid in (%s) %s ) ft group by ts, severity order by ts;",

    Q_DASHBOARD_0000105=" select timescale as timestamp, count(timescale) alarms_count, severity from (select " 
                        " *, timestamp ts, case %s from tblthresholds th, %s a where a.thresid=th.thresid and " 
                        " th.thresid in (select thresid from tblalarms where isdeleted = 0 order by " 
                        " thresid) and th.resid in (%s) %s ) ft group by timescale, severity order by " 
                        " timescale, severity;",

    Q_DASHBOARD_0000106="select %s as name, count(%s) as total_devices, count(CASE WHEN is_device_up  = 0 THEN  1 END) "
                        " as total_device_down, count(CASE WHEN is_device_up  = 1 THEN  1 END)  as total_device_up, " 
                        " count(CASE WHEN is_disabled  = 0 THEN  1 END) as total_disabled from (select n.nodeid, " 
                        " n.resid,  n.technology, n.customer, n.alias,  n.region, r.poll_state as is_disabled, "
                        " n.state, n.city, n.location, a.isdeleted  as is_device_up from tblNodeInfo n, tblAlarms a, "
                        " tblresconfig r where r.poll_state = 1 and r.resid=n.resid and a.nodeid=n.nodeid and "
                        " a.resid=n.resid  and a.statid=n.statid and n.isdeleted=0 and n.nodeid in (%s)) as t group "
                        " by %s order by %s",

    Q_DASHBOARD_0000107="select %s as name, count(%s) as total_devices, count(CASE WHEN is_device_up = 0 THEN"
                        " 1 END) as total_device_down, count(CASE WHEN is_device_up  = 1 THEN  1 END)  as "
                        "total_device_up, " 
                        " count(CASE WHEN is_disabled  = 0 THEN  1 END) as total_disabled %s from (select " 
                        " n.nodeid, n.resid, n.technology, n.customer, r.poll_state as is_disabled, "
                        " n.region, n.alias, n.state, n.city, n.location, case when coalesce(trim(n.hostname), '') = "
                        "  '' then n.poll_addr else n.hostname "
                        " end as hostname, a.isdeleted as is_device_up from tblNodeInfo "
                        " n, tblAlarms a, tblresconfig r where r.poll_state=1 and r.resid=n.resid and "
                        "a.nodeid=n.nodeid and a.resid=n.resid and "
                        " a.statid=n.statid and n.isdeleted=0 and n.nodeid in (%s)) as t %s group by %s %s order by %s",

    Q_DASHBOARD_0000108=" select %s as name, count(CASE WHEN avg = 100 THEN  1 END) as res_up, " 
                        " count(CASE WHEN avg = 0 THEN  1 END) as res_down, count(statid) as " 
                        " total_res from (select distinct on (resconfig_resid) resconfig_resid " 
                        " as t_resid, *  from (select r.resid as resconfig_resid,  n.nodeid, " 
                        " n.resid, n.alias, n.technology, n.customer, n.region, n.state, n.city, n.location, " 
                        " case when coalesce(trim(n.hostname), '') = '' then n.poll_addr else " 
                        " n.hostname end as hostname from tblResconfig r, tblAlarms a, tblextraresinfo " 
                        " er, tblnodeinfo n, tblextranodeinfo  en where n.nodeid=a.nodeid and " 
                        " en.ex_nodeid = a.nodeid and er.ex_resid=a.resid and  r.resid=a.resid " 
                        " and r.isdeleted=0 and r.resid in (%s) order by r.resid) as t1  join (SELECT " 
                        " DISTINCT ON (rw.resid, rw.statid) rw.resid, rw.statid, rw.timestamp,  " 
                        " avg FROM %s AS rw WHERE statid in (%s) ORDER BY rw.resid, rw.statid, " 
                        " rw.timestamp DESC)  as t2 on t1.resconfig_resid=t2.resid order by " 
                        " resconfig_resid) as ft group by %s ,statid  order by %s;",

    Q_DASHBOARD_0000109=" select %s as name, count(CASE WHEN avg = 100 THEN  1 END) as res_up, " 
                        " count(CASE WHEN avg = 0 THEN  1 END) as res_down, count(%s) as " 
                        " total_res %s from (select distinct on (resconfig_resid) resconfig_resid as " 
                        " t_resid, *  from (select r.resid as resconfig_resid,  n.nodeid, n.resid, " 
                        " n.technology, n.alias, n.customer, n.region, n.state, n.city, n.location,  case when " 
                        " coalesce(trim(n.hostname), '') =   '' then n.poll_addr else n.hostname end as " 
                        " hostname from tblResconfig r, tblAlarms a, tblextraresinfo er, tblnodeinfo n, " 
                        " tblextranodeinfo  en where n.nodeid=a.nodeid and en.ex_nodeid = a.nodeid and " 
                        " er.ex_resid=a.resid and  r.resid=a.resid and r.isdeleted=0 and r.resid in (%s) " 
                        " order by r.resid) as t1  join (SELECT DISTINCT ON (rw.resid, rw.statid) rw.resid, " 
                        " rw.statid, rw.timestamp,  avg FROM %s AS rw WHERE statid in (%s) ORDER BY rw.resid, " 
                        " rw.statid, rw.timestamp DESC)  as t2 on t1.resconfig_resid=t2.resid order by " 
                        " resconfig_resid) as ft %s group by %s %s order by %s;",

    Q_DASHBOARD_0000110="select * from (select distinct on (resconfig_resid) resconfig_resid as t_resid, " 
                        " *  from (select r.resid as resconfig_resid,  n.nodeid, n.resid, n.technology, " 
                        " n.customer, n.alias, n.region, n.state, n.city, n.location, n.poll_addr, r.name, case when " 
                        " coalesce(trim(n.hostname), '') = '' then n.poll_addr else n.hostname end as " 
                        " hostname, r.res_type from tblResconfig r, tblAlarms a, tblextraresinfo er, tblnodeinfo n, " 
                        " tblextranodeinfo  en where n.nodeid=a.nodeid and en.ex_nodeid = a.nodeid and " 
                        " er.ex_resid=a.resid and r.resid=a.resid  and r.isdeleted=0 and r.resid in (%s) " 
                        " order by r.resid) as t1  join (SELECT DISTINCT ON (rw.resid, rw.statid) rw.resid, " 
                        " rw.statid, rw.timestamp,  avg FROM %s AS rw WHERE statid in (%s) ORDER BY rw.resid, " 
                        " rw.statid, rw.timestamp DESC)  as t2 on t1.resconfig_resid=t2.resid order by " 
                        " resconfig_resid) as ft %s %s order by avg;",

    Q_DASHBOARD_0000111="select * from (select distinct on (resconfig_resid) resconfig_resid as t_resid, " 
                        " * from (select r.resid as resconfig_resid, n.nodeid, n.poll_addr, r.name, " 
                        " r.res_type, n.alias, n.technology, n.customer, n.region, n.state, n.city, n.location, " 
                        " case when coalesce(trim(n.hostname), '') =  '' then n.poll_addr else n.hostname " 
                        " end as hostname from tblResconfig r, tblAlarms a, tblextraresinfo er, tblnodeinfo " 
                        " n, tblextranodeinfo en where n.nodeid=a.nodeid and en.ex_nodeid = a.nodeid and " 
                        " er.ex_resid=a.resid and r.resid=a.resid and r.isdeleted=0 and r.resid in (%s) order " 
                        " by r.resid) as t1 join (SELECT DISTINCT ON (rw.resid, rw.statid) rw.resid, rw.statid, " 
                        " rw.timestamp, avg FROM %s AS rw WHERE statid in (%s) ORDER BY rw.resid, rw.statid, " 
                        " rw.timestamp DESC) as t2 on t1.resconfig_resid=t2.resid %s order by resconfig_resid) as ft " 
                        " %s %s order by avg;",

    Q_DASHBOARD_0000112="select name as sw_name, count(*) as sw_count from tblsoftwareinventory where nodeid in (%s) group by sw_name;",

    Q_DASHBOARD_0000113=" select * from (select n.nodeid, n.alias, n.poll_addr, case when coalesce(trim(n.hostname), '') " 
                        " =  '' then n.poll_addr else n.hostname end as hostname, sw.name as sw_name, sw.version, " 
                        " sw.release, sw.vendor as sw_vendor, sw.sw_arch, sw.installed_date, sw.license from " 
                        " tblnodeinfo n, tblsoftwareinventory sw where n.nodeid = sw.nodeid and " 
                        " n.nodeid in (%s)) t where %s = '%s';",

    Q_DASHBOARD_0000114=" select name from tbldashboard where name = '%s' and isdeleted = 'f';",

    Q_DASHBOARD_0000115=" select * from (select case when coalesce(trim(n.hostname), '') =  '' then  n.poll_addr "
                        "else n.hostname end as hostname_node, n.alias, a.timestamp downtime, a.isdeleted as link_status, * "
                        "from tblnodeinfo n,  tblresconfig r, tblalarms a where n.nodeid =  a.nodeid "
                        "and r.resid = a.resid and r.poll_state = 1 and r.resid "
                        "in (%s) and a.statid = %s and r.profile in (SELECT unnest(string_to_array(profiles, ',')) as "
                        "profile FROM tblstatprofilemap where stat_name in ('Network Availability')) "
                        "order by downtime desc) ft %s %s;",

    Q_DASHBOARD_0000116=" select %s n.nodeid, r.resid, sr_id, n.alias, th.severity, a.last_event as timestamp, "
                        "th.setmsg, case when coalesce(trim(n.hostname), '') = '' then n.poll_addr "
                        "else n.hostname end as hostname, n.poll_addr, r.name, type from tblalarm_tracker a, "
                        "tblthresholds th, tblnodeinfo n, tblresconfig r where r.resid in (%s) and "
                        "th.thresid=a.thresid and a.nodeid=n.nodeid and r.resid=a.resid and "
                        "a.isdeleted = 0 %s %s %s order by timestamp desc %s; ",

    Q_DASHBOARD_0000117=" select %s, count(%s) alarms_count, severity from %s a, tblthresholds th, "
                        "tblnodeinfo n, tblresconfig r where a.isdeleted = 0 and th.thresid=a.thresid and "
                        "r.resid=a.resid and a.nodeid=n.nodeid and a.resid in (%s) %s group by %s, "
                        "severity order by %s;",
    #
    # Q_DASHBOARD_0000117=" select %s, count(%s) alarms_count, severity from %s a, tblthresholdsall th, "
    #                     "tblnodeinfo n, tblresconfig r where a.isdeleted = 0 and th.thresid=a.thresid and "
    #                     "r.resid=a.resid and a.nodeid=n.nodeid and a.resid in (%s) %s group by %s, "
    #                     "severity order by %s;",

    Q_DASHBOARD_0000118=" select attr, actual_name, type from tblnodeschema where type in ('node','resource');",

    Q_DASHBOARD_0000119=" select ts as timestamp, count(ts) callstatus_count, call_status from "
                        " (select starttime-starttime%%300 as ts, * from (select * from tblvoipcallconfigs where "
                        " starttime between %s and %s) t %s order by ts) ft group by ts, "
                        " call_status order by ts, call_status; ",

    Q_DASHBOARD_0000120=" select ts as timestamp, count(ts) callstatus_count, call_status from "
                        " (select starttime-starttime%%300 as ts, *, case %s from (select * from tblvoipcallconfigs "
                        " where starttime between %s and %s) t %s order by ts) ft group by ts, "
                        " call_status order by ts, call_status; ",

    Q_DASHBOARD_0000121=" select count(CASE WHEN call_status = -1 THEN  1 END) as failed, "
                        " count(CASE WHEN call_status = 0 THEN  1 END) as success, "
                        " count(CASE WHEN call_status = 1 THEN  1 END) as active from (select "
                        " * from tblvoipcallconfigs where starttime between %s and %s) t; ",

    Q_DASHBOARD_0000122=" select %s srcip, destip, starttime, endtime, src_nodeid, dest_nodeid from (select * from "
                        " tblvoipcallconfigs where starttime between %s and %s and call_status = 0) t order by %s "
                        " %s %s; ",

    Q_DASHBOARD_0000123=" select distinct setmsg as name, setmsg as value from tblthresholds where thresid in (select thresid from tblalarms) and setmsg != '' order by name;",

    Q_DASHBOARD_0000124=" select distinct incidentid as name, incidentid as value from tblalarms where thresid in (select thresid from tblalarms where isdeleted = 0) and incidentid != '' order by name;",

    Q_DASHBOARD_0000125=" select * from tblemsdiscoveryprofile where isdeleted = 0 %s %s order by ems_name %s;",

    Q_DASHBOARD_0000126=" select distinct ems_name as name, ems_name as value from tblemsdiscoveryprofile where isdeleted = 0 and ems_name != '' order by ems_name;",

    Q_DASHBOARD_0000127=" select distinct vendor as name, vendor as value from tblemsdiscoveryprofile where isdeleted = 0 and vendor != '' order by vendor;",

    Q_DASHBOARD_0000128=" select * from (select case when poll_state = 0 then -1 else poll_state " 
                        " end if_disabled, CASE WHEN status is NULL THEN 1 else status END as "
                        " nd_status, * from (select case when r.poll_state IS NULL then 0 else " 
                        " r.poll_state end poll_state, n.nodeid as nd_id, n.resid as res_id, n.statid, "
                        " n.hostname,n.poll_addr,n.alias,n.device_type,n.state,n.make,n.model from "
                        " tblnodeinfo n left join tblresconfig r on r.resid=n.resid "
                        " and r.isdeleted =0 where n.isdeleted =0) t1 left join (select distinct nodeid, "
                        " statid, isdeleted as status from tblalarms where thresid in (select thresid "
                        " from tblthresholds) and isdeleted = 0) as t2 on t2.nodeid=t1.nd_id and "
                        " t1.statid = t2.statid where t1.nd_id in (%s) order by t1.nd_id) ft %s order by "
                        " nd_status, if_disabled desc %s;",

    Q_DASHBOARD_0000129=" select %s, count(%s) events_count, severity from %s e, tblnodeinfo n, "
                        "tblresconfig r where r.resid=e.resid and e.nodeid=n.nodeid and e.resid in (%s) "
                        "%s group by %s, severity order by %s;",

    Q_DASHBOARD_0000130=" select avg(avg) from (SELECT DISTINCT ON (rw.resid, rw.statid) rw.resid,  rw.statid, "
                        "rw.timestamp, avg FROM %s AS rw WHERE statid in (%s) ORDER BY  rw.resid, rw.statid, "
                        "rw.timestamp DESC) as t where resid in (%s) order by avg nulls last;",

    Q_DASHBOARD_0000131=" select %s n.nodeid, r.resid, sr_id, n.alias, th.severity, a.last_event, "
                        "th.setmsg, case when coalesce(trim(n.hostname), '') = '' then n.poll_addr "
                        "else n.hostname end as hostname, n.poll_addr, r.name, type from tblalarm_tracker a, "
                        "tblthresholds th, tblnodeinfo n, tblresconfig r where r.resid in (%s) and "
                        "th.thresid=a.thresid and a.nodeid=n.nodeid and r.resid=a.resid and "
                        "a.isdeleted = 0 %s %s %s order by last_event desc %s; ",

    Q_DASHBOARD_0000132=" select count(*) from tblalarms a, tblthresholds th, tblnodeinfo n, "
                        "tblresconfig r where a.isdeleted = 0 and th.thresid = a.thresid and a.resid "
                        "= r.resid and a.nodeid = n.nodeid and r.resid in (%s) and setmsg = '%s';",

    Q_DASHBOARD_0000133=" select n.nodeid, n.resid, a.statid, n.hostname, n.poll_addr, r.alias, "
                        "r.name, r.res_type, a.stat_value as avg from tblalarms a, tblthresholds th, "
                        "tblnodeinfo n, tblresconfig r where a.isdeleted = 0 and th.thresid = "
                        "a.thresid and a.resid = r.resid and a.nodeid = n.nodeid and r.resid in "
                        "(%s) and setmsg = '%s' order by n.hostname %s;",
    Q_DASHBOARD_0000134="select poll_period from tblresconfig where resid='1' ",

    Q_DASHBOARD_0000135="select sum(avg) from (select distinct on (resid, statid) nt.resid, nt.statid, timestamp, avg, r.name "
                        "from (select * from (%s) "
                        "rt join (select statid as st_statid from tblstatmap where rawdn = 'aws_charges') st on "
                        "st.st_statid = rt.statid) nt, tblresconfig r where nt.resid = r.resid and r.isdeleted = 0 and r.resid "
                        "in (select resid from tblresconfig where res_type in ('service_bill') and isdeleted = 0 order by resid) "
                        "order by resid, statid, timestamp, avg desc) ft ",

    Q_DASHBOARD_0000136="select distinct on (resid, statid) nt.resid, nt.statid, timestamp, avg, "
                        "r.name from (select * from %s rt join (select statid as st_statid from "
                        "tblstatmap where rawdn = 'aws_charges') st on st.st_statid = rt.statid) "
                        "nt, tblresconfig r where nt.resid = r.resid and r.isdeleted = 0 and r.resid "
                        "in (select resid from tblresconfig where res_type = '%s' and isdeleted = 0 "
                        "order by resid) order by resid, statid, timestamp, avg desc;",

    Q_DASHBOARD_0000137="select count(*) from tblalarms a right join tblthresholds th on a.thresid = th.thresid "
                        "where setmsg = '%s' and a.resid in (%s);",

    # Reserved for Reports Queries
    # *************************************************************************

    Q_REPORT_0000001="select distinct(profile_dn) from tblbusinesshr order by profile_dn",
    Q_REPORT_0000002="select name,statid from tblstatmap order by name",
    Q_REPORT_0000003="select name from tblfilter_config order by name",
    Q_REPORT_0000004="select name from tblaccounts where isdeleted=0 order by name",
    Q_REPORT_0000005="select reportid ,name from tblreportconfig where  module!='NCM' and private_opt = 0 or user_list like '%%%s,%%' or user_list like '%s' order by name",
    Q_REPORT_0000006="select attr, name_to_display,type from (SELECT *, CASE WHEN coalesce(TRIM(display_name), '')"
                     " = '' THEN actual_name ELSE display_name END as name_to_display FROM tblNodeSchema) as tbl1 "
                     "%s order by name_to_display",
    Q_REPORT_0000007="select reportid ,link_to from tblreportconfig",
    Q_REPORT_0000008="select reportid ,name from tblreportconfig where reportid in (%s) order by name",
    Q_REPORT_0000009= "select attr, name_to_display, table_name , show_on_filters, type from (SELECT *, CASE WHEN coalesce(TRIM(display_name), '')"
                     " = '' THEN actual_name ELSE display_name END as name_to_display FROM tblNodeSchema where show_on_filters = 1) as tbl1 order"
                     " by name_to_display",
    Q_REPORT_0000010 = "select distinct %s from tblextranodeinfo as tbl1 join tblextraresinfo as tbl2 on tbl1.ex_nodeid = tbl2.ex_nodeid where %s!= ''",
    Q_REPORT_0000011 = "select * from tblnodeschema where actual_name in (%s) and type in ('node','nodeextra','nodetag');",
    Q_REPORT_0000012 = "select %s from tblNodeInfo n,tblExtraNodeInfo exn where exn.ex_nodeid = n.nodeid %s %s;",
    Q_REPORT_0000013 = "select * from tblnodeschema where actual_name in (%s) and type in ('node','resource','nodeextra','resourceextra');",
    Q_REPORT_0000014 = "select %s from tblResConfig r, tblNodeInfo n,tblExtraNodeInfo exn,tblExtraResInfo "
                       "exr WHERE r.isDeleted = 0 AND r.nodeid = n.nodeid and exr.ex_resid = r.resid and "
                       "exn.ex_nodeid = n.nodeid %s %s;",
    Q_REPORT_0000015 = "select distinct setmsg, resetmsg from tblthresholds where isdeleted = 0 order by setmsg asc",
    # *************************************************************************
    # Reserved for Openstreetmap Queries
    # *************************************************************************

    Q_OMS_0000001="select distinct n.nodeid, hostname,n.poll_addr,device_type,n.alias,os_name,n.latitude,n.longitude,hostname as "
            "label from tblnodeinfo n, tblresconfig r,tblextranodeinfo exn where n.nodeid = r.nodeid and n.nodeid = "
            "exn.ex_nodeid and n.latitude between -90 and 90 and n.longitude between -180 and 180 and n.isdeleted=0 %s %s",

    Q_OMS_0000002="select n.resid ,n.nodeid,t.statid,a.isdeleted from tblalarms a,tblnodeinfo n,tblthresholds t where "
            "a.thresid = t.thresid  and a.isdeleted = 0 and n.statid = t.statid and a.resid = n.resid %s order by nodeid",

    # *************************************************************************
    # Reserved for Openstreetmap Queries
    # *************************************************************************

    Q_FILTER_OPTIONS_0000001 = "select * from (SELECT *, CASE WHEN coalesce(TRIM(display_name), '') = '' THEN actual_name ELSE display_name END as name_to_display FROM tblNodeSchema where show_on_filters = 1 order by %s %s) as tb1 %s",

    Q_FILTER_OPTIONS_0000002 = "Select * from tblnodeschema where show_on_filters = 1 order by attr",

    Q_FILTER_OPTIONS_0000003 = "select db_column from tblcustomlabel where display=1;",

    Q_FILTER_OPTIONS_0000004 = "select %s from tblextranodeinfo as tbl1 join tblextraresinfo as tbl2 on tbl1.ex_nodeid = tbl2.ex_nodeid where %s ilike '%%%s%%'",

    Q_FILTER_OPTIONS_0000005 = "select ex_nodeid from tblextranodeinfo where %s",


    # *************************************************************************
    # Reserved for Node Queries
    # *************************************************************************

    Q_Node_0000001="select nodeid1, nodeid2, resid1, resid2, name from tblResTopology where nodeid1!=nodeid2 "
                   "and isdeleted=0 and show_on_flatview=1 and (nodeid1=%s or nodeid2=%s);",

    Q_Node_0000002="select n.nodeid, n.poll_addr, n.hostname, n.alias, n.device_type, a.isdeleted as is_device_up,"
                   "poll_state from tblNodeInfo as n join tblAlarms as a on n.resid=a.resid and n.statid=a.statid "
                   "and n.isdeleted=0 and n.nodeid in (%s)  join tblResconfig r on r.resid = n.resid;",

    Q_Node_0000003="select * from (select r.resid, r.nodeid, r.name, r.profile, a.stat_dn, "
                   "a.isdeleted as is_interface_up,poll_state from tblResconfig as r left join tblAlarms as a on "
                   "r.resid=a.resid and r.isdeleted=0 %s order by nodeid, name) as t where t.profile in "
                   "(SELECT unnest(string_to_array(profiles, ',')) as profile FROM tblstatprofilemap  " 
                   " where stat_name in ('Network Availability')) and t.nodeid in (%s) and " 
                   " t.stat_dn like '%%__n_avail';",

    Q_Node_0000004 = "select * from tblcustomlabel where module = 'Node' and display = 1;",

    Q_Node_0000005 = " select %s from tblextranodeinfo where ex_nodeid = %s;",
)

